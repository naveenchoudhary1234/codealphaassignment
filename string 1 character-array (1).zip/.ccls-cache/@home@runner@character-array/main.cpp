#include <iostream>
#include<string.h>
#include<cstring>
#include<algorithm>
using namespace std;

/// char array-faster and memory efficient than string

//// int main() {
//   // input lene k liye loop chlane ki jarurt nhii hai
//  char ch[10];
// cin>>ch;
// cout<<ch;
// }

////ham index vise chla ke dekhnge
// int main(){
// char ch[8];
//   cin>>ch;
//   for(int i=0;i<8;i++){
//     cout<<"index at"<<i<<"value is"<<ch[i]<<endl;
//   }
//   /// null character ki value check kar rahe hai
//   int temp=ch[6];
//   int value=(int)temp;
//   cout<<value;
  
// }


// jab ham input le rhe hai aur bich m space krdia to eg nav legha it only print nav
// int main(){
//   char ch[100];
//   cin>>ch;
//   cout<<ch;
// }

/// solution of above problem
// int main(){
//   char ch[100];
//   cin.getline(ch,100);
//   cout<<ch;
// }


// length of string
// int findlength(char ch[],int size){
//   int length=0;
//   for(int i=0;i<size;i++){
//     if(ch[i]=='\0'){
//       break;
      
//     }
//     else{
//       length++;
//     }
//   }return length;
// }


// int main(){
// char ch[100];
//   cin.getline(ch,100);
//   int length=findlength(ch,100);
//   cout<<length;
//   // direct function to calculate length
//   cout<<strlen(ch)<<endl;
  
// }


// reverse of a string
// void reverse(char ch[],int size){
//   int left=0;
//   int right=size-1;
//   while(left<=right){
//     swap(ch[left],ch[right]);
//     left++;
//     right--;
//   }
//   for(int i=0;i<size;i++){
//     cout<<ch[i];
//   }
// }


// int main(){
//   char ch[7];
//   cin>>ch;
//    reverse(ch,7);
//   reverse(ch,ch+7);  // inbuilt function to reverse an string
//   for(int i=0;i<7;i++){
//     cout<<ch[i];
//   }
// }



// convert to uppercase
// void uppercase(char ch[],int n){
//   int i=0;
//   while(ch[i]!='\0'){
//     char current_character=ch[i];
//     if(current_character>='a' && current_character<='z'){
//       ch[i]=current_character-'a'+'A';
      
//     }
//     i++;
//   }
//   cout<<ch;
// }
// int main(){
//   char ch[100];
//   cin.getline(ch,100);
//   uppercase(ch,100);
  
// }

// replace @ with space
// int main(){
//   char ch[6];
//   cin.getline(ch,6);
//   for(int i=0;i<6;i++){
//     if(ch[i]=='@'){
//       ch[i]=' ';
//     }
//   }
//   cout<<ch;
// }

//check palindrome
// bool check(char ch[],int n){
//   // n-length of string
//   int i=0;
//   int j=n-1;
//   while(i<=j){
//     if(ch[i]==ch[j]){
//       i++;
//       j--;
//     }
//     else{
//       return false;
//     }
//   }
//   return true;
// }

// int main(){
//   char ch[100];
//   cin.getline(ch,100);
//   int length=strlen(ch);
//   bool ans=check(ch,length);
//   if(ans) cout<<"valid palindrome";
//   else cout<<"invalid palindrome";
// }

/////* strings -collection of character
// declaration 

// int main(){
// string name;
//   // cin>>name;
//   getline(cin,name);
//   cout<<name<<endl;
//   cout<<name[0];

// }

// basic function of string
// int main(){
//   string str;
//   cin>>str;
//   string temp=" ";
//   cout<<"length of string"<<str.length()<<endl;
//   cout<<"string empty or not:"<<temp.empty()<<endl;
//   cout<<str.at(0)<<endl;
//   cout<<str.front()<<endl;
//   cout<<str.back()<<endl;
  
  
// }

// int main(){
//   // string str1="name:";
//   // string str2="naveen";
//   // // append
//   // str1.append(str2);
//   // cout<<str1;
//   // string str3="naveenchoudhary";
//   // str3.erase(4,3);
//   // cout<<str3;

//   // insert
//   string str4="name:choudhary";
//   string str5="Naveen";
//   str4.insert(5,str5);
//   cout<<str4;
  
  
// }

// int main(){
// string str6="navee";
//   // push back
//   str6.push_back('n');
//   cout<<str6<<endl;
//   // pop back
//   str6.pop_back();
//   cout<<str6;
//   // finding any thing
//   string str7="Naveen choudhary";
//   string str8="jaat";
//   if(str7.find(str8)==string::npos)
//   // not found
//     cout<<"not found"<<endl;
//   else cout<<"found";
  
// }

// int main(){
// // compare string 0 aaya to equal h 
//   string str9="naveen";
//   string str10="abcdef";
//   if(str9.compare(str10)==0){
//     cout<<"matching";
//   }
//   else{
//     cout<<"no matching";
//   }
  
// }

// int main(){
// // str substr
//   // hme 4 word ka text bhar nikalna hai to isse use krenge
//   string str11="bjcfhvjrgfvcrhgvchrbhtfhv";
//   cout<<str11.substr(7,5);
  
  
  
// }
// bool palindrome(char ch[],int length){
//   int left=0;
//   int right=length-1;
//   while(left<=right){
//     if(ch[left]==ch[right]) {
//       left++; right--;}
//     else {
//       return false;}
//   }return true;
// }



// int main(){
//   char ch[100];
//   cin>>ch;
//   int length=strlen(ch);
//   bool check=palindrome(ch,length);
//   cout<<check;
// }

#include <iostream>
#include<algorithm>
using namespace std;

int lengths(char arr[]) {

    int index=0;
    while(arr[index]!='\0'){
        index++;
    }
    return index;
}
// string reverse(char arr[],int length){
//     int left=0;
//     int right=length-1;
//     while(left<=right){
//         swap(arr[left],arr[right]);
//         left++;
//         right--;
//     }return arr;
// }

// string convert(char arr[],int length){
//     for(int i=0;i<length;i++){
//         if(arr[i]>='a' && arr[i]<='z'){
//         arr[i]=arr[i]-'a'+'A';}
//         else{
//             arr[i]=arr[i]-'A'+'a';
//         }
//     }return arr;
// }

// bool checkpalindrome(char arr[],int length){
//     int left=0;
//     int right=length-1;
//     while(left<=right){
//         if(arr[left]==arr[right]){
//             left++;
//             right--;
//         }
//         else{
//             return false;
//         }
//     }return true;
// }


// int main(){
//     char arr[]="naveen";
//     int length=lengths(arr);
//     // string ans=convert(arr,length);
//     // cout<<ans;
//     bool ansa=checkpalindrome(arr,length);
//     if(ansa) cout<<"wow it is palindrome";
//     else cout<<"noooo plz try agaian";
// }