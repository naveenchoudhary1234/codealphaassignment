#include<iostream>
using namespace std;
/// 1 Minimum Bracket Reversal
// isme hme bracket ko chnagr krke usko proper bnana hai aur count krne hai
// eg (( ye hi to hm dusri vali ko chane kr skte h to count 1 aayega
// eg ((( odd h to hm -1 return krdenge
int countRev (string s)
{
    stack<char>st;
    int count=0;
    if(s.size()&1) return -1;
    for(int i=0;i<s.length();i++){
        char ch=s[i];
        if(ch=='{'){
            st.push(ch);
        }
        else{
           if(!st.empty() &&st.top()=='{'){
               st.pop();
           }
           else{
               st.push(ch);
           }
        }
    }
        // if stack is still not empty 
        while(!st.empty()){
            char a=st.top(); st.pop();
            char b=st.top();st.pop();
            if(a==b) count+=1;
            else count+=2;
        }


    return count;
}


/// 2 remove all adjacent dublicate in string
string removeDuplicates(string s) {
  stack<char>st;
  for(int i=0;i<s.length();i++){
      char ch=s[i];
       if(!st.empty() && st.top()==ch){
         st.pop();
       }
       else{
          st.push(ch);
       }
  }

string ans;
while(!st.empty()){
ans+=st.top();
st.pop();
}
reverse(ans.begin(),ans.end());
return ans;

}

///  Celebrity ptoblem -usko sab jante par  vo kisi ko nhi janta
// m[0][1] ith person knows jth person
// conditon of celebrity
// all rows are zero
// all column are 1 

// condition 2
// put all person in stack
// staco s 2 person uthyenge
// ham dekhenge a b ko janta hai to a celebrity to nhii hai so b ko stack m daldo
// if(m[a][b]) a remove b push
int celebrity(vector<vector<int> >& M, int n) 
{
    stack<int>st;
    for(int i=0;i<n;i++){
        st.push(i);
    }

    // step 2
    while(st.size()!=1){
        int a=st.top();st.pop();
        int b=st.top();st.pop();

        if(M[a][b]){
            // mtlb a b ko janta hai
            st.push(b);
        }
        else{
           // b ko a janta hai
           st.push(a);

        }
    }
    // step 3 single person is actal celeberity
    // row vale sare element 0 hone chaiye
    int mightbecelebrity=st.top();

    for(int i=0;i<n;i++){
        if(M[mightbecelebrity][i]!=0){
            return -1;
        }

    }

    // everyone knows celebrity
    // col vale sare elemnt 1 hone chaiye except diagonal
    for(int i=0;i<n;i++){
      if(M[i][mightbecelebrity]==0 && i!=mightbecelebrity){
          return -1;
      }  
    }
    return mightbecelebrity;
}



/// next gretaer elemen in linklist
  void reverse1(ListNode*& head) {
    ListNode* prev = NULL;
    ListNode* curr = head;
    while (curr != NULL) {
        ListNode* newnode = curr->next;
        curr->next = prev;
        prev = curr;
        curr = newnode;
    }
    head = prev;
}

vector<int> nextLargerNodes(ListNode* head) {
    reverse1(head);
    ListNode* temp = head;
    vector<int> ans;
    stack<int> st;
    while (temp) {
        int d = temp->val;
        while (!st.empty() && st.top() <= d) {
            st.pop();
        }
        if (st.empty()) {
            ans.push_back(0); 
        } else {
            ans.push_back(st.top());
        }
        st.push(d);
        temp = temp->next; 
    }
    reverse(ans.begin(),ans.end());
    return ans;
}



//// Nstacks in array
// we nees two additional array
// 1 top-stores index of top element of ith stack soize equal to n
// 2 next array-it can point to next element after top element
// it can point to next free space size equal to s main array jitna
// push emthid
// 1 find index int index=freespot
// 2 update free spit freespot=nex[freeindex]
// insert in array a[index]=x;
// class NStack(){
// int *a,*top,*next;
//     int n;
//     int size;
//     int freespot;
//     pub;ic:
//     NStack(int_n,int _s):n(_n),size(_s){
//         freespot=0;
//         a=new int[size];
//         top=new int[n];
//         next=new int[size];

//         for(int i=0;i<n;i++){
//            top[i]=-1; 
//         }
//         for(int i=0;i<size;i++){
//             next[i]=i+1;
//         }
//         next[size-1]=-1;
//     }

//     bool push(int x,int m){
//         if(freespot==-1){
//             return false;  //stack overglw
//         }

//         /// find index;
//         int index=freespot;

//         // update
//         freespot=next[index];

//         // insert
//         a[index]=x;

//         // 4 update
//         next[index]=top[m-1];

//         // 5 update top
//         top[m-1]=index;

//         return true;
//     }
    
// }


/// online stock span
// first m value store kr rhe hai
// dusre m span
stack<pair<int,int>>st;
StockSpanner() {

}

int next(int price) {
   int span=1;
   while(!st.empty() &&st.top().first<=price){
      span+=st.top().second;
      st.pop();
   } 
      st.push({price, span});
  return span;
}

 
