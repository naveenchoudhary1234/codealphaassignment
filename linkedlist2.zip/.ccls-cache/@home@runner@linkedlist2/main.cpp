#include <iostream>
using namespace std;

// Doubly Linked list
// 1 division -prev
// 2-data
// 3 next

class Node{
public:
int data;
Node*prev;
Node*next;

Node(){
  this->prev=NULL;
  this->next=NULL;
}
Node(int data){
this->data=data;
this->prev=NULL;
this->next=NULL;
  
}
};
void printall(Node*head){
  Node*temp=head;
  while(temp!=NULL){
    cout<<temp->data<<" ";
    temp=temp->next;
  }
}


int findlength(Node*head){
  int count=0;
  Node*temp=head;
  while(temp!=NULL){
    count++;
    temp=temp->next;
  }
  return count;
}


void insertathead(Node*&head,Node*&tail,int data){
if(head==NULL){
  Node*newnode=new Node(data);
  head=newnode;
  tail=newnode;
}
  else{
    Node*newnode=new Node(data);
    head->prev=newnode;
    newnode->next=head;
    head=newnode;
  }

  
}

void insertattail(Node*&head,Node*&tail,int data){
if(head==NULL){
  Node*newnode=new Node(data);
  head=newnode;
  tail=newnode;
}
  else{
    Node*newnode=new Node(data);
    tail->next=newnode;
    newnode->prev=tail;
    tail=newnode;
  }
}


void insertatanyposition(Node*&head,Node*&tail,int data,int pos){
  if(head==NULL){
    Node*newnode=new Node(data);
    head=newnode;
    tail=newnode;
  }
  else{
    int len=findlength(head);
   if(pos==1){

    insertathead(head,tail,data);
  }
  
  else if(pos==len+1){
    insertattail(head,tail,data);
  }
    else{
Node*newnode=new Node(data);
      Node*prevnode=NULL;
      Node*currnode=head;
      while(pos!=1){
        pos--;
        prevnode=currnode;
        currnode=currnode->next;
      }
      prevnode->next=newnode;
      newnode->prev=prevnode;
      currnode->prev=newnode;
      newnode->next=currnode;
      

      
    }
  


  
}
}
// delete krane k steps
//1 new temp ka node bao
// 2 head ko aage bejdo
// 3 temp ko next h usko null krao
// head k prev ko null krao
void deleteallnode(Node*&head,Node*&tail,int pos){
  if(head==NULL){
    return;
  }
  
  
  if(head==tail){
    Node*temp=head;
    delete temp;
    head=NULL;
    tail=NULL;
    return;
  }

int len=findlength(head);

   if(pos==1){
   Node*temp=head;
  head=head->next;
  temp->next=NULL;
  head->prev=NULL;
  delete temp;
}
   else if(pos==len){
     Node*prevnode=tail->prev;
     prevnode->next=NULL; // yha s hmne uske link tod diyee
     tail->prev=NULL;
     delete tail;
     tail=prevnode;
   }
     // 3 pointer bna k kr denge  bich vale dono ko null set krdenege 
   else{
    Node*prevnode=NULL;
     Node*currnode=head;
     while(pos!=1){
       pos--;
       prevnode=currnode;
       currnode=currnode->next;
     }
     Node*nextnode=currnode->next;
     prevnode->next=nextnode;
     nextnode->prev=currnode;
     currnode->next=NULL;
     currnode->prev=NULL;
     delete currnode;
     
     
   }
}



int main(){

  Node*head=NULL;
  Node*tail=NULL;
  insertathead(head,tail,20);
  insertathead(head,tail,30);
  insertathead(head,tail,40);
  insertathead(head,tail,50);
  insertattail(head,tail,60);
  insertattail(head,tail,70);
  insertattail(head,tail,80);
  insertatanyposition(head,tail,10,1);
  insertatanyposition(head,tail,90,2);
  printall(head);
  cout<<endl;
  deleteallnode(head,tail,1);
  printall(head);
  
}