#include <iostream>
using namespace std;

// string removedublicate(string str){
//   string ans="";
//   int index=0;
//   while(index<str.length()){
//     // ans ka right most character aur string ka character to pop kar denge
//     if( ans.length()>0 && ans[ans.length()-1]==str[index]){
//       ans.pop_back();
//     }
//     else{
//       ans.push_back(str[index]);
//     }
//     index++;
//   }return ans;
// }








// int main() {
//   string str;
// cin>>str;
//   string a=removedublicate(str);
//   cout<<a;
//   }

// remove all occurenece of a string

string removeoccurence(string str1,string str2){
  while(str1.find(str2)!=string ::npos){
      str1.erase(str1.find(str2),str2.length());
  }return str1;
  
}



int main(){
string str1="computer";
  string str2="cat";
  
  string ans=removeoccurence(str1,str2);
  cout<<ans;
  
}

// remove character
string removeChars(string str1, string str2) {
   for (char ch : str2) {
      while (str1.find(ch) != string::npos) {
          str1.erase(str1.find(ch), 1);
      }
  }
  return str1; 
  }

// palindrome after remove one character

// bool checkpalindrome(string str,int left,int right){
//   while(left<=right){
//     if(str[left]!=str[right]) return false;
//     else{
//       left++;
//       right--;
//     }
//   }return true;
// }

// bool palindrome(string str){
// int left=0;
//   int right=str.length()-1;
//   while(left<=right){
//     if(str[left]==str[right]){
//       left++;
//       right--;
//     }
//     else{
//       // ek remove kar skte hai bs to hum ek br left vala kardenge aur ek br right vala
//       bool ans1 =checkpalindrome(str,left+1,right);
//       bool ans2= checkpalindrome(str,left,right-1);
//       return ans1||ans2;
//     }
//   }return true;
  
// }



// int main(){
//   string str;
//   cin>>str;
//   bool a=palindrome(str);
//   cout<<a;
// }


// palindromic substring
// ham isme ek hi variable p pointer approach lgayenge
int expand(string s,int p,int q){
  int count=0;
  while( p>=0 && q<s.length()&& s[p]==s[q]){
    count++;
    p--;
    q++;
    
  }return count;
}



int countsubstring(string s){
int total_count=0;
  for(int i=0;i<s.length();i++){
    int oddAns=expand(s,i,i);
    int evenAns=expand(s,i,i+1);
    total_count+=oddAns+evenAns;
  }return total_count;
  
}

// int main(){
//   string s={"abc"};
//   int ans=countsubstring(s);
//   cout<<ans;
// 





  
  
