/// check if word is valid after substitution
// hme abc insert krna hai
bool isValid(string s) {
    if(s.size()==0){
        return true;
    }
    int find=s.find("abc");
    if(find!=string::npos){
        string tleft=s.substr(0,find);  // starting index,count
        string tright=s.substr(find+3,s.size());
        return isValid(tleft+tright);
    }
    return false;
}

// second method
bool isValid(string s) {
  if(s[0]!='a'){
    return false;
  }
  stack<char>st;
  for(auto ch:s){
    if(ch=='a'){
        st.push(ch);
    }
    else if(ch=='b'){
        if(!st.empty() &&st.top()=='a'){
            st.push('b');
        }
        else{
           return false; 
        }
    }
    else{
        if(!st.empty() && st.top()=='b'){
            st.pop();
            if(!st.empty() && st.top()=='a'){
                st.pop();
            }
            else{
                return false;
            }

        }
        else{
            return false;
        }
    }

  }
  return st.empty();
}


// decode the string
// Input: s = 3[b2[ca]]
// Output: bcacabcacabcaca
// Explaination: 2[ca] means 'ca' is repeated 
// twice which is 'caca' which concatenated with 
// 'b' becomes 'bcaca'. This string repeated 
// thrice becomes the output.
stack<string> st;
for (auto ch : s) {
    if (ch == ']') {
        // Collect the string to be repeated
        string stringToRepeat = "";
        while (!st.empty() && st.top() != "[") {
            stringToRepeat = st.top() + stringToRepeat;
            st.pop();
        }
        st.pop();  // Remove the '['

        // Collect the number (digits can be multiple characters)
        string NumericString = "";
        while (!st.empty() && isdigit(st.top()[0])) {
            NumericString = st.top() + NumericString;
            st.pop();
        }

        // Convert the NumericString to an integer
        int n = stoi(NumericString);

        // Form the repeated string
        string repeatedString = "";
        for (int i = 0; i < n; i++) {
            repeatedString += stringToRepeat;
        }

        // Push the result back to the stack
        st.push(repeatedString);
    } else {
        // Push current character to stack
        st.push(string(1, ch));
    }
}

// Form the final decoded string
string ans;
while (!st.empty()) {
    ans = st.top() + ans;
    st.pop();
}
return ans;
}


/// simplified path  in linux
void buildAns(stack<string>&st,string &ans){
  if(st.empty()) return;
  string minpath=st.top(); st.pop();
  buildAns(st,ans);
  ans+=minpath;
}


  string simplifyPath(string path) {
      stack<string>st;
      int i=0;
      while(i<path.size()){
          int start=i;
          int end=i+1;
          while(end<path.size() && path[end]!='/'){
            ++end;
          }
          string minpath=path.substr(start,end-start); // yha s start aur end ki pos niklalo
          i=end; // ab start aur end ki pos bhi bdlnii pdegii to ye kiyaa
          if(minpath=="/" || minpath=="/."){
             continue; 
          }
          if(minpath!="/.."){
              st.push(minpath);
          } 
              // yha /.. aa gyaa
          else if(!st.empty()){
              st.pop();
          }

      }
      // mtlb hm apne root elemnt p aageye
      string ans=st.empty()?"/":"";
      buildAns(st,ans);
      return ans;
  }


// maximum largest rectangle area
vector<int>nextelement(vector<int>&arr) {
    vector<int>ans(arr.size(),arr.size());
    stack<int>st;
    st.push(-1);
    for(int i=arr.size()-1;i>=0;i--){
        int curr=arr[i];
        while(st.top()!=-1 &&arr[st.top()]>=curr){
            st.pop();
        }
         ans[i]=st.top();
        st.push(i); // hme stack k andar index push krne hai
    }
    return ans;
}


/// prev smaller element

vector<int>prevelement(vector<int>&arr) {
    vector<int>ans(arr.size(),-1);
    stack<int>st;
    st.push(-1);
    for(int i=0;i<arr.size();i++){
        int curr=arr[i];
        while(st.top()!=-1 && arr[st.top()]>=curr){
            st.pop();
        }
         ans[i]=st.top();
        st.push(i);
    }
    return ans;
}

int largestRectangleArea(vector<int>& heights) {



vector<int>next=nextelement(heights);
for(int i=0;i<next.size();i++){
if(next[i]==-1){
    next[i]=heights.size();
}
}
vector<int>prev=prevelement(heights);

vector<int>area(next.size()); // ans stoe krlenege
for(int i=0;i<next.size();i++){
int width=next[i]-prev[i]-1;
int length=heights[i];
int currarea=width*length;
area[i]=currarea;
}
int maxi=INT_MIN;
for(int i=0;i<area.size();i++){
maxi=max(maxi,area[i]);
}
return maxi;

}

int maximalRectangle(vector<vector<char>>& matrix) {
    // firstly we have to convert it into oyr int
    vector<vector<int>>v;
    int n=matrix.size();
    int m=matrix[0].size();
    for(int i=0;i<n;i++){
        vector<int>t;
        for(int j=0;j<m;j++){
         t.push_back(matrix[i][j]-'0');
        }
        v.push_back(t);
    }
    // first row area
    int area=largestRectangleArea(v[0]); // first row
    for(int i=1;i<n;i++){
        for(int j=0;j<m;j++){
            // lets update current row with previous values;
            if(v[i][j]){
                v[i][j]+=v[i-1][j];
            }
            else{
             v[i][j]=0;   
            }
        }
        area=max(area,largestRectangleArea(v[i]));
    }
    return area;
}


// asteroids
vector<int> stack;
    // Loop through all asteroids
    for (int asteroid : asteroids) {
        // If asteroid is moving to the right (positive), add it to the stack.
        if (asteroid > 0) {
            stack.push_back(asteroid);
        } else {
            // While there are asteroids in the stack moving to the right (positive) 
            // and the current asteroid is larger (negative magnitude comparison)
            while (!stack.empty() && stack.back() > 0 && stack.back() < -asteroid) {
                stack.pop_back(); // Pop the smaller asteroids as they are destroyed
            }
            // If the top asteroid on the stack is the same size (opposite direction),
            // Both asteroids destroy each other, pop the top asteroid from the stack.
            if (!stack.empty() && stack.back() == -asteroid) {
                stack.pop_back();
            } else if (stack.empty() || stack.back() < 0) {
                // If the stack is empty or the top asteroid is moving to the left (negative),
                // Add the current asteroid to the stack, since no collision will happen.
                stack.push_back(asteroid);
            } // If none of the above cases, the current asteroid is destroyed
        }
    }
    return stack; 


/// car fleet
class Solution {
    class Car{
    public:
    int pos,speed;
    Car(int p,int s):pos(p),speed(s){};  // ye isie liya uki jb hm sort krenge to pos aur spped mis match hojayenge
};
static bool mycomp(Car &a,Car &b){
    return a.pos<b.pos;
}
public:
// ek car fast chl rhi hai aur ek fastjb fast slow tk aajayegi tb ye dono slow speed schlegi dono
// bumber to bumber dirve
// No overtake
// fleet-group of car
// hm is question m sbase pehle time nikal lenge phir using stack dekhenege ki agr hmara jo curr time
// hai vo agar stack sbda hai to pehle vale ko pop krake use push krdenge
// last m jitnt element stack m rhenege vhii ans hojayegaa

    int carFleet(int target, vector<int>& position, vector<int>& speed) {
        vector<Car>cars;
        for(int i=0;i<position.size();i++){
            Car car(position[i],speed[i]);
            cars.push_back(car);
        }
        sort(cars.begin(),cars.end(),mycomp);
        stack<float>st;
        for(auto car:cars){
            float time=(target-car.pos)/((float)car.speed);
            while(!st.empty() && time>=st.top()){
               st.pop();
            }
            st.push(time);
        }
        return st.size();
    }
};

// car fleet 2
// we have to find the collison time
// har position p hm dekehenge ki hmsare age aii koi gadi hia jise m collide kr pau
// collison nikalnge nextcarpostioin-currcarpos/nextcarspped-nowcarspeed
class Solution {
public:
    vector<double> getCollisionTimes(vector<vector<int>>& cars) {
        vector<double>answer(cars.size(),-1);
        stack<int>st;
        for(int i=cars.size()-1;i>=0;i--){
            // hmare aage ki gadi agar fast h to sifga pop krdenge
            while(!st.empty() && cars[st.top()][1]>=cars[i][1]){ // 1 islie kuki hme sppe dcgaiye
                st.pop();
            }

            while(!st.empty()){
                // collison toime
            double coltime=(double)(cars[st.top()][0]-cars[i][0])/(cars[i][1]-cars[st.top()][1]);
            if(answer[st.top()]==-1 || coltime<=answer[st.top()]){
                answer[i]=coltime;
                break;
            }
                st.pop();


            }
            st.push(i);
        }
        return answer;
    }
};