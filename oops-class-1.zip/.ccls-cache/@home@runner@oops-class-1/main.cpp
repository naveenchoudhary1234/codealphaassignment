#include <iostream>
using namespace std;
// object -is an instance of class -actual implementaion
// class-idea,custom data type

// empty class ka size 1 bit hota hai

// sabse bade data type k nearest multiple p chle jao- padding in memory

// bydefault class member re private;

// acess modifires - they define scope 

// constructor-construct karta hoga it is the only function in c++ which has no return type; chize banata h ctor short form it is an instance of class
// hmesa class k andar constructor hota hai by default

//polymorphism - function ek hi h par vo multiple chize dikha rha hai
// eg in construcotr student1 

// hidden member in class -*this pointer

// local vs global variable

int x=5;

// int main() {

// x=4;
// int x=20;
// cout<<x<<endl; //print local variable
// cout<<::x<<" "; // print global variable
  
// }

class Student{  // size of class is 2 bit kuki 3 bytes ki compiler n padding kardi hai taki compilation fast ho jaye
private:
string gf;
public:
int id;
int age;  //state/properies
bool attendance;
string name; // string bhi ek class hi hai 24 bit ka space khati haii ye string.h m pdi hai


void study(){
  cout<<"studying";  // behavior/method/funcion
}
void sleep(){
  cout<<"sleeping";
}
private:
void chatting(){
  cout<<"chating";
}
};


// int main(){
//   Student s1;   // studnt object hai
//  s1.name="Naveen";
//   s1.age=12;
//   s1.id=1;
//   s1.attendance=0;

  
//   Student S2; 
//   S2.name="Choudhary";
//   S2.age=18;
//   S2.id=10;
//   S2.attendance=1;
  
    
// }


// constructor
class Student1{
public:
int rollno;
int age;
bool attendance;
string name;

Student1(){

  
}

Student1(int _rollno,int _age,bool _attendance,string _name){
rollno=_rollno;
age=_age;
attendance=_attendance;
name=_name;
}

};
int main(){
  Student1 s1;
  Student1 S2(1,12,0,"Naveen Choudhary"); // yeh stack memory m allocated h
  Student1 *S4=new Student1(1,12,0,"naveen"); // heap p memory allocate hui hai
  cout<<S2.name;
  cout<<S2.age;
  cout<<S4->name<<endl; // arrow krke print krte hai

  delete S4;
  
  
}