#include <iostream>
#include <vector>
using namespace std;
// // question 1 remove dublicate and return the length of array
int removeDuplicates(vector<int>& nums) {
int j=0; int i=1;
 while(i<nums.size()){
   if(nums[i]==nums[j]) ++i;
   else{
     j++;
     nums[j]=nums[i];
     i++;
   }
 }return j+1;
}


int main() {
    vector<int> nums = {0, 0, 1, 1, 1, 2, 2, 3, 3, 4};
    int result = removeDuplicates(nums);
    cout << "Length after removing duplicates: " << result << endl;
    return 0;
// }

// question 2
// maximum sub average array
   double JAAT(vector<int>& nums, int k){
     int i=0,j=k-1;
      int sum=0;
      for(int y=i;y<=j;y++)
          sum+=nums[y];
          int maxsum=sum;
          j++;  // this is bcoz tak hm pehle hi pta lgale ki hmari subarray k s choti to nhii hai
          while(j<nums.size()){
              sum-=nums[i++];  // agli br hme piche vale elemnt ka sum nhi lena islie subtract kr rhe h
              sum+=nums[j++];  // aage bdana h sum agle elemnt ka lene k lye
              maxsum=max(maxsum,sum);
          }




     double maxavg=maxsum/(double)k;
      return maxavg;


     }


}

int findMaxAverage(int arr[], int n, int k) {
    int windowSum = 0;
for (int i = 0; i < k; i++) {
    windowSum += arr[i];
}
int maxSum = windowSum;
int maxIndex = 0;

// Slide the window and update the maximum sum
for (int i = k; i < n; i++) {
    windowSum += arr[i] - arr[i - k];
    if (windowSum > maxSum) {
        maxSum = windowSum;
        maxIndex = i - k + 1;
    }
}
return maxIndex;
}

void reverse(int arr[],int n,int k){
    for(int i=0;i<n;i+=k){
        int left=i;
        int right=min(i+k-1,n-1);
        while(left<right){
            swap(arr[left++],arr[right--]);
        }
    }

}


vector<int> intersection(vector<int>& nums1, vector<int>& nums2) {
    unordered_set<int>ans;
    vector<int>sol;
    for(int i=0;i<nums1.size();i++){
        int elem=nums1[i];
        for(int j=0;j<nums2.size();j++){
            if(elem==nums2[j]){
              ans.insert(elem);
              nums2[j]=INT_MIN;
              break;
            }
        }
    }
    sol.assign(ans.begin(),ans.end());
    return sol;

}

vector<vector<int>> threeSum(vector<int>& nums) {
  vector<vector<int>>ans;
  sort(nums.begin(),nums.end());
  int n=nums.size();
  for(int i=0;i<nums.size();i++){
    int a=nums[i];
    int target=-a;
    int start=i+1;
    int end=n-1;
    while(start<end){
      if(nums[start]+nums[end]==target){
        ans.push_back({nums[i],nums[start],nums[end]});
        while(start<end && nums[start]==nums[start+1]) start++;
        while(start<end && nums[end]==nums[end-1]) end--;
        start++;
        end--;
      }
      else if(nums[start]+nums[end]>target){
        end--;
      }
      else{
        start++;
      }
    }
    while(i+1<n && nums[i+1]==nums[i]) i++;

  }
  return ans;
}














