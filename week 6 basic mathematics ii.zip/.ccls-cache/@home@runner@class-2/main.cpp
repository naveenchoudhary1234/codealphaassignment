#include <iostream>
#include<math.h>
#include<vector>
using namespace std;

// // question 1 count prime no
// vector<bool>countprime(int n){
//     vector<bool>prime(n+1,true);
//     prime[0]=prime[1]=false;
//     for(int i=2;i*i<n;i++){
//         if(prime[i]){
//             int j=i*i;
//             while(j<=n){
//                 prime[j]=false;
//                 j+=i;
//             }
//         }
//     }return prime;
// }



// // int main() {
// //    int n=25;
// //    vector<bool>ans=countprime(n);
// //    for(int i=0;i<n;i++){
// //        if(ans[i]) cout<<i<<" ";
// //    }

// //     return 0;
// // }






///// question 2 segmented sieve

// vector<bool>countprime(int n){
//     vector<bool>prime(n+1,true);
//     prime[0]=prime[1]=false;
//     for(int i=2;i*i<n;i++){
//         if(prime[i]){
//             int j=i*i;
//             while(j<=n){
//                 prime[j]=false;
//                 j+=i;
//             }
//         }
//     }return prime;
// }

// vector<bool> sieve(int l, int r) {
//   vector<bool> sieve = countprime(sqrt(r)); 
//   vector<int> baseprime;
//   for (int i = 0; i < sieve.size(); i++) {
//     if (sieve[i]) {
//       baseprime.push_back(i);
//     }
//   }
//   vector<bool> segsieve(r - l + 1, true); 
//   if (l == 1 || l == 0) {
//     segsieve[l] = false;
//   }

//   for (auto primes : baseprime) {
//     int first_multiple = (l / primes) * primes;
//     if (first_multiple < l) {
//       first_multiple += primes;
//     }
//     int j = max(first_multiple, primes * primes);
//     while (j <= r) {
//       segsieve[j - l] = false;
//       j += primes;
//     }
//   }
//   return segsieve; // Return segsieve from the function
// }



// int main() {
//   int l = 110;
//   int h = 130;
//   vector<bool> ss = sieve(l, h);
//   for (int i = 0; i < ss.size(); i++) { // Changed sieve to ss.size()
//     if (ss[i]) {
//       cout << i * l << " "; // Added missing semicolon
//     }
//   }
}

vector<bool>prime(int n){
  vector<bool>isprime(n+1,true);
  isprime[0]=isprime[1]=false;
  for(int i=2;i*i<n;i++){
    if(isprime[i]){
      int j=i*i;
      while(j<=n){
        isprime[j]=false;
        j+=i;
      }
    }
  }return isprime;
}

vector<bool>seives(int l,int h){
  vector<bool>seives=prime(sqrt(h));
  vector<int>baseprime;
   vector<bool>segsieve(h-l+1);
  for(int i=0;i<seives.size();i++){
    if(seives[i]){
      baseprime.push_back(i);
    }
 
    if (l == 1 || l == 0) {
      segsieve[l] = false;
      for(auto primes:baseprime){
        int first_mul=(l/primes)*primes;
        if(first_mul<l){
          first_mul+=primes;
        }
        int j=max(first_mul,primes*primes);
        while(j<=h){
          segsieve[j-l]=false;
          j+=primes;
        }
      }

    
    }
}return segsieve;

}
