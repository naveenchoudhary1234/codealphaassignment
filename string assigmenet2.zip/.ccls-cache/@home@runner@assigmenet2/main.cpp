#include <iostream>
#include<vector>
#include<map>
#include<algorithm>
#include <climits> 
using namespace std;
// gorup anagram
// map -key pair combination



vector<vector<string>>groupanagram(vector<string>strs){
    map<string,vector<string>>mp;
    for(auto str:strs){
        string sorted=str;
        sort(sorted.begin(),sorted.end());
        mp[sorted].push_back(str);
    }
    vector<vector<string>>ans;
    for(auto it=mp.begin();it!=mp.end();it++){
        ans.push_back(it->second);
    }
    
}


// longest palindromic substring
// bool ispalindrome(string &s,int start,int end){
//   while(start<end){
//     if(s[start]!=s[end]) return false;
//     else start++; end--;
//   }return true;
// }


// string longest(string s){
//   string ans=" ";
//   for(int i=0;i<s.size();i++){
//     for(int j=i;j<s.size();j++){
//       if(ispalindrome(s,i,j)){
//         string t=s.substr(i,j-i+1); // isme starting point dete hai aur length dete hau 
//         ans=t.size()>ans.size()? t:ans;
//       }
//     }
//   }return ans;
// }

// int main(){
//   string s="naveen";
//   string a=longest(s);
//   cout<<a;
// }




/// string to integer using std function atoi
// int main(){
//   string ans="1234";
//   int integer=atoi(ans.c_str());
//   cout<<integer;
// }

// int myauto(string s){
//   int num=0;int i=0;int sign=1;// it means first term is positive
//   while(s[i]==' '){
//     i++;
//   }
//   if(i<s.size() && (s[i]=='-' || s[i]=='+')){
//     sign =s[i]=='+'?1:-1;
//     ++i;
//   }
//   while(i<s.size() && isdigit(s[i])){
//     if(num>INT_MAX/10||(num==INT_MAX/10 &&s[i]>'7')){
//       return sign==-1?INT_MIN:INT_MAX;  // out pf bound condition
//     }
//     num=num*10+(s[i]-'0');  // convert character to int
//     ++i;
//   }
//   return num*sign;
// }

// int main(){
//   string s="   123";
//   int ans=myauto(s);
//   cout<<ans;
// }




/// string compression
// aabbcccd- count the value of alphabet a2b2c3d1


#include <vector>
#include <algorithm>

class Solution {
public:
    int compress(std::vector<char>& s) {
        int index = 0; // yha hmara ans store krvayenge
        int count = 1;
        char prev = s[0];

        for (int i = 1; i <= s.size(); i++) {
            if (i < s.size() && s[i] == prev) {
                count++;
            } else {
                s[index++] = prev;
                if (count > 1) {
                    int start = index;
                    while (count) {
                        s[index++] = (count % 10) + '0';
                        count /= 10;
                    }
                    std::reverse(s.begin() + start, s.begin() + index);
                }
                if (i < s.size()) {
                    prev = s[i];
                    count = 1;
                }
            }
        }
        return index;
    }
};


