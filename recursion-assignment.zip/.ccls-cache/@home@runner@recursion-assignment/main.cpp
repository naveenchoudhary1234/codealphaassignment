#include <iostream>
#include<algorithm>
using namespace std;

//last occurenece of a char strrchr()
// right to left
void lastocc(string s,char x,int &ans,int i){
if(i<0) return;
  if(s[i]==x){
    ans=i;
    return;
  }
  lastocc(s,x,ans,i-1);
}

// left to right

void lastoccu(string s,char x,int &ans,int i){
if(i>0) return;
  if(s[i]==x){
    ans=i;
  }
  lastocc(s,x,ans,i+1);
}

// int main() {
// string s;
//   cin>>s;
//   char x;
//   cin>>x;
//   int i=0;
//   int ans=-1;
//   lastocc(s,x,ans,i);
//   cout<<ans;
  
// }
// int main(){
//   string s;
//   cin>>s;
//   char x;
//   cin>>x;
//   int ans=-1;
//   int i = s.size() - 1;
//   lastocc(s,x,ans,i);
//   cout<<ans;
  
// }



/// reverse of string

// void myswap(char *left,char *right){
//   char temp=*left;
//   *left=*right;
//   *right=temp;
  
  
// }


// int main(){
//   string s;
//   cin>>s;
//   int left=0;
//   int right=s.size()-1;
//   while(left<=right){
//     myswap(&s[left],&s[right]);
//     left++;
//     right--;
//   }
//   cout<<s;
// }



// reverse of string using recursion
 // void reverse(string s,int left,int right){
 //   if(left>=right){
 //     return;
 //   }
 //   swap(s[left],s[right]);
 //   reverse(s,left+1,right-1);
 // }



/// add string
// java - biginteger();


void add(string &num1,int p1,string &num2,int p2,int carry,string &ans){
    if(p1<0 && p2<0){
        if(carry!=0){
            ans.push_back(carry+'0');
        }
        return;
    }
    int n1=(p1>=0?num1[p1]:'0')-'0';
    int n2=(p2>=0?num2[p2]:'0')-'0';
int sum=n1+n2+carry;
int digit=sum%10;
carry=sum/10;
ans.push_back(digit+'0');
add(num1,p1-1,num2,p2-1,carry,ans);



}

string addstrings(string num1,string num2){
    string ans="";
    add(num1,num1.size()-1,num2,num2.size()-1,0,ans);
    reverse(ans.begin(),ans.end());
    return ans;
}

int main(){
    string num1="123";
    string num2="456";
    string ans=addstrings(num1,num2);
    cout<<ans;
}



// palindrom check
// bool check(string s){

//   int left=0;
//    int right=s.size()-1;
//   while(left<=right){
//     if(s[left]!=s[right]) return false;
//     else{
//       left++;
//       right--;
//     }
//   }return true;
// }


// int main(){
//   string s;
//   cin>>s;
//    if(check(s)){
//      cout<<"string are palindrome";
//     }
//   else{
//     cout<<"string are not palindorme";
//   }
    
  
// }

bool cehckpalindrome(string s,int left,int right){
  if(left>=right) return true; 
  if(s[left]!=s[right]) return false;
  return cehckpalindrome(s,left+1,right-1);
}

#include<vector>
/// print all subarrays

void print(vector<int>&arr,int left,int right){
  if(right>=arr.size()){
      return;
  }
  for(int i=left;i<=right;i++){
      cout<<arr[i];
  }cout<<endl;
  print(arr,left,right+1);

}

int main() {
 vector<int>arr={1,2,3,4,5};
 int left=0;
 int right=0;
 print(arr,left,right);
}


