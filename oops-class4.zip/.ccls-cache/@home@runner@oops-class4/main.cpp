#include <iostream>
#include "mystring.h";
#include<cstring>
using namespace std;



//* Run time or dynamic time polymorphism- 

// isme ham ek hi function s ek hi time p thino ki sound print karvana chahte hai

// function overriding- late binding virtual lgadenge animal p ki tu ise serious mt le 
class Animal{
public:
virtual void sound(){
  cout<<"animal making sound";
}
};
class Dog:public Animal{
public:
void sound() override{
  cout<<"dog hoooo";
}
};

class Cat:public Animal{
public:
void sound() override{
  cout<<"billli,miyauuuu";
}
};

void sound(Animal *animal){
animal->sound();  //polymorphic

  
}

// int main() {

// Animal *animal=new Dog();
//   sound(animal);
  
//   animal=new Cat();
// sound(animal);
  
// }



// abstract class

class Bird{
public:
virtual void eat()=0;
virtual void fly()=0;
// jisko bbi ye class inherit krni hai usko ye 2 function to likhne hi pdengee

};

class sparrow:public Bird{
public:
void eat(){
  cout<<"hlwww";
}
void fly(){
  cout<<"flying";
}
};

void birddoessomething(Bird&bird){
  bird.fly();
  bird.eat();
}
int main(){
  Bird bird;
  birddoessomething(bird);
}



