#ifndef MY_STRING_H
#define MY_STRING_H
#include<iostream>

class mystring{
private:
char *data;
int length;
public:
// default ctor
mystring();


// parameter ctor
mystring(const char*str);

//copy ctor
mystring(const mystring&other);

// destrucot
~mystring();

int size() const;

bool empty() const;
}