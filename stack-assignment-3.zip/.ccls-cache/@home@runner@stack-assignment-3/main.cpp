/// Longest Valid parenthesis

class Solution {
public:
    int longestValidParentheses(string s) {
        stack<int>st;
        st.push(-1);
        int maxlen=0;
        for(int i=0;i<s.length();i++){
            char ch=s[i];
            if(ch=='('){
              st.push(i);
            }
            else{
               st.pop();
               if(st.empty()){
                st.push(i);

               }
               else{
                int len=i-st.top();
                maxlen=max(len,maxlen);
               } 
            }
        }
        return maxlen;
    }
};



//// Daily temperature
// current day s warmer day kb aayefa
// agar nahi aata h to 0 returj krdo
// approach-next greater element
// ham isme approacg lgayenge ki i-st.top means agla index eg 1 bdaa hai 0 index s to usme s subtract krdenge to hme ans miljayega i-st.top()
class Solution {
public:
    vector<int> dailyTemperatures(vector<int>& temperatures) {
        vector<int>ans(temperatures.size(),0);
        stack<int>st;
        for(int i=0;i<temperatures.size();i++){
            while(!st.empty() && temperatures[i]>temperatures[st.top()]){
             ans[st.top()]=i-st.top();
             st.pop();
            }
            st.push(i);
        }
        return ans;
    }
};// remove k digit
// remove in such a way it makes minimum digit
// 1 2 3 4 5 6 7
// remove 5 6 7

class Solution {
public:
    string removeKdigits(string num, int k) {
      stack<char>st;
      string ans;
      for(auto digit:num){
        if(k>0){
           while(!st.empty() && st.top()>digit){
            st.pop();
            k--;
            if(k==0) break;
           } 
        }
        st.push(digit);
      }
      // hmara stack khali nhi hua h aur k ki value bchi huii hai
      if(k>0){
        while(!st.empty() && k){
            st.pop();
            k--;
        }
      }
      while(!st.empty()){
        ans.push_back(st.top());
        st.pop();
      }
      // remove aage vale zeros
      while(ans.size()>0 && ans.back()=='0'){
        ans.pop_back();
      }
      reverse(ans.begin(),ans.end());
      return ans==""?"0":ans;
    }
};


// Minimum vale to add make parenthseis valid
class Solution {
public:
    int minAddToMakeValid(string s) {
        stack<char>st;
        for(auto ch:s){
            if(ch=='('){
                st.push(ch);
            }
            else{
                if(!st.empty() && st.top()=='('){
                    st.pop();
                }
                else{
                    st.push(ch);
                }
            }
        }
        return st.size();
    }
};

// browser history
/// only one tab
// starts at one page
// ->forward
//<- back
// last back-home page
// jaise hm google to facebook to insta to youtube 
// return to insta to facebook then go to spotify so fow=rward history removes
// bydefault-leetcode home page
// hme forward history store krni pdegi to hm isme 2 stack use krne vale hai


class BrowserHistory {
    stack<string>browserStack,fwdStack;  // 2 stack
public:
    BrowserHistory(string homepage) {
// by default home page to rkhna hi rkhna hai
        browserStack.push(homepage);
    }

    void visit(string url) {
        // lets clear all forward hitory
        while(!fwdStack.empty()){
            fwdStack.pop();
        }
        browserStack.push(url);
    }

    string back(int steps) {
        while(steps--){
            if(browserStack.size()>1){
               fwdStack.push(browserStack.top());
               browserStack.pop();
            }
            else{
                // only home page present
                // back not possible
                break;
            }
        }
        return browserStack.top();
    }

    string forward(int steps) {
        while(steps--){
            if(!fwdStack.empty()){
              browserStack.push(fwdStack.top());
              fwdStack.pop();

            }
            else{
                break;
            }
        }
        return browserStack.top();
    }
};