#include <iostream>
#include <cmath>

using namespace std;

// wildcard matching
// use of * and ? it can be any charater or number so we can use this and solve that the two string are equal or not
// s=a b c d e f g
// p=a b * f g // they are equal

bool isMatching(string &s,int si,string &p,int pi){

  if(si==s.size() && pi==p.size()){
    return true;
  }
  if(si==s.size() && pi<p.size()){
    while(pi<p.size()){ // hme sare character * hi chaiye agar vo na h to return false;
      if(pi!='*') return false;
      pi++; 
    }return true;
  }
  // single character matching
  if(s[si]==p[pi] || '?'==p[pi]){
    return isMatching(s,si+1,p,pi+1);
  }
  if(pi=='*'){
    bool case1=isMatching(s,si,p,pi+1);// treat * as empty
    bool case2=isMatching(s,si+1,p,pi); // treat * as one character
    return case1||case2;
  }
  return false;
}


bool isMatch(string s,string p){
  int si=0;
  int pi=0;
  return isMatching(s,si,p,pi);
}


/// number of dice rolls with target sum
//n=3 - no of dice k=2 - no of face // t=6 

int numRollsToTarget(int n,int k,int target){
  if(target<0) return 0;
  if(n==0 && target==0) return 1;
  if(n==0 && target!=0) return 0;
  if(n!=0 && target==0) return 0;
  int ans=0;
  for(int i=0;i<=k;i++){
    ans+=numRollsToTarget(n-1,k,target-i); // hme target ko k m s subtract karna hai
  }return ans;
}



/// perfect square
int numSquareshelper(int n){
if(n==0) return 1;
  int i=1;
  int ans=0;
  int end=sqrt(n);
  while(i<end){
    int perfectsquare=i*i;
    int numberofperfectsquare=1+numSquareshelper(n-perfectsquare);
    if(numberofperfectsquare<ans){
      ans=numberofperfectsquare;
    }
    ++i;
    
  }

 
  return ans;
}

int numSquares(int n){
  return numSquareshelper(n)-1;
}


