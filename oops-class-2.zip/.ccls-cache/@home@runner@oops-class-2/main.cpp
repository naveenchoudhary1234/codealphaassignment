#include <iostream>
using namespace std;

// static memeber -share memory all of the classes mtlb ek hi x and y ko point kr rhe hogee

/// static ember of class
class a{
    public:
    static int x;
    a(){
        /// we cannot intialise the value of static meber in constructor
        // it is used by all the member of class
        // we cannot intialaise the static meber within class
        // acees of static member 
        // class_name::var_name;

    }
};

int a::x=2;

// int main(){
//     cout<<a::x;
// }



/// we can also access the static meber through object

class naveen{
    public:
    int val;
    naveen(int v=10){
        val=v;
    }
};

class choudhary{
    public:
   static naveen s;
   choudhary(){

   }

};

naveen choudhary::s=naveen(11);

int main(){
    cout<<choudhary::s.val;

}

// class abc{
//   public:
// int x,y;
//   void print() const{ // isme private variable automatically pas sho rhe h this pointer s 
//     cout<<x<<y;
//   }
// };
// // int main() {
// // abc obj1={1,2};
// // abc obj2={3,4};
// //   obj1.print();
// //   obj2.print();
// // }

// class abc1{
//   public:
// static int a,b;
//   void print() const{ // isme private variable automatically pas sho rhe h this pointer s 
//     cout<<a<<b;
//   }
// };
// int abc1::a;
// int abc1::b;
// int main(){
//   abc1 obj1;
//   obj1.a=5;
//   obj1.b=10;
//   obj1.print();
//   abc1 obj2;

//   obj2.a=20;
//   obj2.b=30;
//   obj2.print();
//   obj1.print();
  
  
// }

///// copy ctor
// constructor - two types default parameterised default m garbage value aa jati hai

class student{
public:
int a;
int b;
int *v;
string name;

student(int _a,int _b,string _name){
  a=_a;
  b=_b;
  name=_name;
}
// copy constructor jb hme deep copy krni ho 
student(const student &srcobj){
  cout<<"copy ctor call";
  this->name=srcobj.name;
  this->a=srcobj.a;
  this->b=srcobj.b;
  this->v=new int(10);
}
// destructive constructor 
~student(){
  cout<<"dtor called";
  delete v;
}

};

// int main(){
//   student s1(12,13,"naveen");
//   student s2=s1;
//   cout<<s1.name;
//   cout<<s2.name;
  
// }


/// pillar of oops
// 1 Abstraction-sirf use krte rhna ulse andar nhi dekhna ki kya kaise hua
// loose coupling-insert kiya aur bnd kiya eg vector
// encapsulation-bundling of data and methods is a way to implement abstraction
// easy to handle 2 protect security eg we can make private variable
// perfect encapsulation -if all data memeber are privat getter and setter s inko access kar skte hai
// encapsulation is often mean to achieve abstraction  hide details and see necesary details
// inheritence-inherit the property from parent class

// mode of inheritnece - kin kin chizko ko inheritnce krna chahte ho

class Bird{
public:
int age,weight;
string color;
void eat(){
  cout<<"eating";
}
void fly(){
  cout<<"flying";
}

  
};
class Sparrow:public Bird{
public:
Sparrow(int age,int weight,string color){
  this->age= age;
  this->weight= weight;
  this->color= color;
}
};

class pigeon:public Bird{
public:
void guttering(){
  cout<<"bird is guttering";
}
};

// int main(){
//   Sparrow s(12,1,"red");
//   cout<<s.color;
//   pigeon p;
//   p.guttering();
  
// }


// private data cont inherit it does not derive
// protected inherit ho skta hai


// Types of inheritance
// single inheritance-bird s sparrow bnayi mtlb ek hi sub class bnaye uski
// Multi Level or chain of inheritance-fruit -mango-naveen 
// 3 Hierachal 
// animal-dog bird -cat
// dog-desi lebra german

// 4 Multiple Inheritance
// derived class inherit from more than one class
// professor sub class h dono ki teacher aur researcher ki





////// DIAMOND PROBLEM

class Person{
public:
void walk(){
  cout<<"walking";
}
};
class Teacher:virtual public Person{
public:
void teach(){
  cout<<"teaching";
}
};
class Researcher:virtual public Person{
public:
void research(){
  cout<<"Researching";
}
};
// multiple inheritance
class Professor:public Teacher,public Researcher{
public:
void bore(){
  cout<<"boring";
}
};










// int main(){

// Professor p;
//  // p.walk(); // yha error islie aa rha h kuki professor confuse hai teacher vala walk chune ya phor researcher vala

// // 1 scope Resolution
//   p.Teacher::walk(); 
//   p.Researcher::walk();

//   // 2 virtual aage lgado apni classes k aage
//   p.walk();
  
// }
// solution usig 
// 1  scope solution-agr  ham aisa kuch krde ki dono teacher aur reasearcher ka walk same krdee
// 2 virtual-  dono ka ek hi walk hai same copy share krenge viratual ka mtlb abhi mt kro run time p dekh lenaa




// #Polymorphism
// existing in many forms 
// to achieve the polymorphism two ways 1 run time 2 compile time fast compile time

// 1 Static Polymorphism-fixed 
// function overloading -multiple constructor-function ka name same but type alg rkdia
int add(int a,int b){
  return a+b;
}
double add(double a,double b){
  return a+b;
}
// int main(){
//   cout<<add(2,3);
//   cout<<add(5.6,6.7);
// }

// 2 Operaor Overloading
class vector{
int x, y;
public:
vector(int x,int y){
  this->x=x;
  this->y=y;
}
// op overloading
void operator+(const vector &src){
  // src refernce to v2
  this->x=this->x+src.x;
  this->y=this->y+src.y;
  
}
  void display(){
    cout<<x<<y;
  }

};

int main(){
  vector v1(2,3);
  vector v2(4,5);
  v1+v2; // addition answer should be stored in v1
  v1.display();
  
  
  
}







