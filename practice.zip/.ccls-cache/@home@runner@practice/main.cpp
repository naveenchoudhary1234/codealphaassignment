#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

// int main() {
//   vector<int>v;
//   int n;
//   cin>>n;
//   for(int i=0;i<n;i++){
//     int d;
//     cin>>d;
//     v.push_back(d);
//   }
//   for(auto it:v){
//     cout<<it<<" ";
//   }
//   }

// int main(){
// vector<vector<int>>v(5,vector<int>(8,0));
//   for(int i=0;i<v.size();i++){
//     for(int j=0;j<v[i].size();j++){
//       cout<<v[i][j]<<" ";
//     }
//     cout<<endl;
//   }
// }


// jagges array
// int main(){
//   vector<vector<int>>arr;
//   vector<int>a(10,0);
//    vector<int>b(9,1);
//    vector<int>c(8,3);
//    vector<int>d(9,1);
//    vector<int>e(10,0);
//   arr.push_back(a);
//   arr.push_back(b);
//   arr.push_back(c);
//   arr.push_back(d);
//   arr.push_back(e);
//     for(int i=0;i<arr.size();i++){
//      for(int j=0;j<arr[i].size();j++){
//          cout<<arr[i][j]<<" ";
//       }
//        cout<<endl;
//     }
//   }

// rotation of a array

int main(){
  int k=3;
  int arr[]={1,2,3,4,5};
  int n=5;
  int ans[n];
  k=k%n;
  // if(k==0) return;
  for(int i=0;i<n;i++){
    int newi=(i+n-k)%n;  // it also handle negative case
    ans[newi]=arr[i];
  }
  for(int i=0;i<n;i++){
    arr[i]=ans[i];
  }
  for(int i=0;i<n;i++){
    cout<<arr[i];
  }
}




// missing number
// int main(){
// int nums[]={1,0,3};
//   int sum=0;
//   int n=3;
//   for(int i=0;i<n;i++){
//     sum+=nums[i];
//   }
//  int totalsum=((n)*(n+1))/2;
//   int ans=totalsum-sum;
//   cout<<ans;
// }

// int missingNumber(int n, vector<int>& arr) {
//   int i=0;
//     while(i<n-1){
//         int index=arr[i]-1;
//         if(arr[i]>0 && arr[i]<n-1 && arr[i]!=arr[index] ){
//             swap(arr[i],arr[index]);
//         }
//         else{
//             i++;
//         }
//     }
//     for(int i=0;i<n;i++){
//         if(arr[i]!=i+1){
//             return i+1;
//         }
//     }
//     return n;
// }




// // transpose of a matrix --bad m reverse kar dena;
// int main(){

// int arr[][3]={{1,2,3},{4,5,6},{7,8,9}};
//   for(int i=0;i<3;i++){
//     for(int j=2;j>=i;j--){
//       swap(arr[i][j],arr[j][i]);
//     }
//   }
//   for(int i=0;i<3;i++){
//      reverse(arr[i], arr[i] + 3);
//   }
//   for(int i=0;i<3;i++){
//     for(int j=0;j<3;j++){
//       cout<<arr[i][j];
//     }cout<<endl;
//   }
  
// }
// transpose of a matrix

// int main(){
//   int arr[3][3]={{1,2,3},{4,5,6},{7,8,9}};
//   for(int i=0;i<3;i++){
//     for(int j=2;j>=i;j--){
//       swap(arr[i][j],arr[j][i]);
//     }
//   }
//   for(int i=0;i<3;i++){
//     for(int j=0;j<3;j++){
//       cout<<arr[i][j]<<" ";
//     }cout<<endl;
//   }
// }

// print the row with maximum one
// int main(){

// int arr[][2]={{1,0},{0,1}};
//   int onecount=0;
//   int row=-1;
//   for(int i=0;i<2;i++){
//     int count=0;
//     for(int j=0;j<2;j++){
//       if(arr[i][j]==1) 
//         count++;
//     }
//     if(count>onecount){
//       onecount=count;
//       row=i;
//     }
//   }
//   if(row!=-1){
//     for(int j=0;j<2;j++){
//       cout<<arr[row][j];
//     }
//   }
//     else{
//     cout<<"no  array";
//     }
//   }

#include <iostream>

// using namespace std;

// int main(){

// int matrix1[3][3] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
// int matrix2[3][3] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
// int results[3][3];
// int product = 0;
// int i;
// int j;

//   for (i = 0; i < 3; i++){
//     for (j = 0; j < 3; j++){
//         product += matrix1[i][j] * matrix2[j][i];
//         cout << product <<" ";
//     }cout<<endl;
//     results[i][j] = product;
//     product = 0;
//   }

//   cout << endl << "Output Matrix: " << endl;

//   for (int i = 0; i < 3; i++){
//     for (int j = 0; j < 3; j++){
//         cout << results[i][j]<<" ";
//     }
//     cout << endl;
//   }

// return 0;
// }

// C++ program to multiply two matrices

// #include <bits/stdc++.h>
// using namespace std;

// Edit MACROs here, according to your Matrix Dimensions for
// mat1[R1][C1] and mat2[R2][C2]
#define R1 2 // number of rows in Matrix-1
#define C1 2 // number of columns in Matrix-1
#define R2 2 // number of rows in Matrix-2
#define C2 3 // number of columns in Matrix-2

void mulMat(int mat1[][C1], int mat2[][C2])
{
  int rslt[R1][C2];

  cout << "Multiplication of given two matrices is:\n";

  for (int i = 0; i < R1; i++) {
    for (int j = 0; j < C2; j++) {
      rslt[i][j] = 0;

      for (int k = 0; k < R2; k++) {
        rslt[i][j] += mat1[i][k] * mat2[k][j];
      }

      cout << rslt[i][j] << "\t";
    }

    cout << endl;
  }
}

// Driver code
// int main()
// {
//   // R1 = 4, C1 = 4 and R2 = 4, C2 = 4 (Update these
//   // values in MACROs)
//   int mat1[R1][C1] = { { 1, 2,}, { 2, 2 } };

//   int mat2[R2][C2] = { { 1, 1, 1 }, { 2, 2, 2 } };



//   // Function call
//   mulMat(mat1, mat2);

//   return 0;
// }


// int kthSmallest(int arr[], int N, int K)
// {
//     // Sort the given array
//     sort(arr, arr + N,greater<int>());

//     // Return k'th element in the sorted array
//     return arr[K - 1];
// }

// int main(){
//   int arr[]={1,2,3,4,5};
//   int K=2;
//   int N=5;
//   int ans=kthSmallest(arr,N,K);
//   cout<<ans;
// }




  




