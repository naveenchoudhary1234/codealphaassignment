#include <iostream>
#include<vector>
#include<deque>
using namespace std;

// qeuee using stacks
// 1 make two stacks s1 and s2
// s2 k sare element s1 m daldo
// s1 .add x
// s1 k sare eement s2 m daldo
class MyQueue {
public:
stack<int>s1,s2;
    MyQueue() {

    }

    void push(int x) {
        s1.push(x);
    }

    int pop() {
        int pop=-1;
        // agar stack 2 khali nhi hai to sifha sidha pop krdo
        if(!s2.empty()){
            pop=s2.top();
        }
        else{
            // pehle sara data s2 k andar dalo
            // phir s2 m s hi pop kro
            while(!s1.empty()){
                s2.push(s1.top());
                s1.pop();
            }
            pop=s2.top();
        }
        s2.pop();
        return pop;

    }

    int peek() {
        int front=-1;
        if(!s2.empty()){
            front=s2.top();
        }
        else{
             while(!s1.empty()){
                s2.push(s1.top());
                s1.pop();
            }
            front=s2.top();
        }
        return front;
    }

    bool empty() {
        return s1.empty() && s2.empty();
    }
};

// method 2
void enqueue(int x) {
   while (!s1.empty()) {
      s2.push(s1.top());
      s1.pop();
  }

  // Push item into s1
  s1.push(x);

  // Push everything back to s1
  while (!s2.empty()) {
      s1.push(s2.top());
      s2.pop();
  }

}

int dequeue() {
    if (s1.empty()) {
      return -1;
  }

  // Return top of s1
  int x = s1.top();
  s1.pop();
  return x;
}




// //// 2 stacks using queue
class MyStack {
public:
queue<int>q1,q2;
    MyStack() {

    }

    void push(int x) {
        // push x to queue 2
        // all element q1-q2
        // all lement q2 to q1
        q2.push(x);
        while(!q1.empty()){
            q2.push(q1.front());
            q1.pop();
        }
          while(!q2.empty()){
            q1.push(q2.front());
            q2.pop();
        }

    }

    int pop() {
        // pop-q1.front()
        int pop=-1;
        pop=q1.front();
        q1.pop();
        return pop;

    }

    int top() {
        // q1.front()
        return q1.front();
    }

    bool empty() {
        return q1.empty() && q2.empty();
    }
};




///*pending question
//// k queues in an array
/// n stacks in a array

// sum of minimum and maximum elements of all subarrays of size k
int sumofallmaxandminwindowofsizek(vector<int> nums, int k) {
       int ans=0;
        deque<int>dq;
        deque<int>dq2; // it store minimum valye
        for(int i=0;i<k;i++){
            int element=nums[i];
            // chota element remove kardo
            while(!dq.empty() && element>nums[dq.back()]){
                dq.pop_back();
            }
            // bada element remove kardo
            while(!dq2.empty() && element<nums[dq2.back()]){
                dq2.pop_back();
            }
            dq.push_back(i);
            dq2.push_back(i);
        }
        ans+=nums[dq.front()]+nums[dq2.front()];
        for(int i=k;i<nums.size();i++){
    // out of window element
            // removal
            if(!dq.empty() && i-dq.front()>=k){
              dq.pop_front();
            }
            if(!dq2.empty() && i-dq2.front()>=k){
              dq2.pop_front();
            }
              int element=nums[i];
                while(!dq.empty() && element>nums[dq.back()]){
                dq.pop_back();
            }
            while(!dq2.empty() && element<nums[dq2.back()]){
                dq2.pop_back(); // Correctly use dq2 here
            }
            dq.push_back(i);
            dq2.push_back(i);
              ans+=nums[dq.front()]+nums[dq2.front()];
        }
        // last window ka ans dekh lete hi
      return ans;
    
}

int main(){
    vector<int>v={2,5,-1,7,-3,-1,-2};
    int k=4;
    cout<<sumofallmaxandminwindowofsizek(v,k);
}


/// * No of recent call
class RecentCounter {
public:
queue<int>q;
    RecentCounter() {


    }

    int ping(int t) {
        // 1 
        q.push(t);
        // 2 pop invalid req older than t-3000
        while(!q.empty() && q.front()<(t-3000)){
            q.pop();
        }

        // 3 now queue has quwue has recenet call
        return q.size();
    }
};



/// find the winner of circular game
// n-5 k-3
// clockwise diretion
// game ko chlate rho jb kisi k upr k aajaye vo out hojayega
int findTheWinner(int n, int k) {
   // all player should go in queue
   queue<int>q;
   for(int i=1;i<=n;i++){
    q.push(i);
   } 

   while(q.size()>1){
    for(int i=1;i<k;i++){
        // inko hme elemeinate nhii krna hai
        auto player=q.front();
        q.pop();
        q.push(player);
    }
    // kth ko remove krna hai
    q.pop();
   }
   return q.front();

}


/// * reveral card in increasing ordet
/// ek card ko reeal kro aur dusre card ko bottom p daldo
// 2 13 3 11 5 17 7
// 2 3 5 7 11 13 17
class Solution {
public:
    vector<int> deckRevealedIncreasing(vector<int>& deck) {
        sort(deck.begin(),deck.end());
         vector<int>ans(deck.size());
         queue<int>q;
         for(int i=0;i<ans.size();i++){
            q.push(i);
          }
          for(int i=0;i<deck.size();i++){
            ans[q.front()]=deck[i];
            q.pop();

            // push front to bottom
            if(!q.empty()){
                q.push(q.front());
                q.pop();
            }
          }
        return ans;
    }
};


/// Number of people aware of secret
class Solution {
public:
    int peopleAwareOfSecret(int n, int delay, int forget) {
        int curr=0; // active spreader jitne log active honge vgi secret btayenge
        int ans=1; // kitno ko secret ptaa hain 
        queue<pair<int,int>>delayQ,forgetQ; // is din kitnr logo ko secret pta chla hai
        delayQ.push({1,1});
        forgetQ.push({1,1});
        for(int i=1;i<=n;i++){
            if(!forgetQ.empty() && forgetQ.front().first+forget<=i){
                auto front=forgetQ.front();
                forgetQ.pop();  
                auto no=front.second; // kitnr log bhulne vale hai
                ans=ans-no;
                curr=curr-no;

            }

            //make new active speaker
            if(!delayQ.empty() && delayQ.front().first+delay<=i){
                auto front=delayQ.front();
                delayQ.pop();
                curr=curr+front.second;
            }

            // spread the secret
            if(curr>0){
                ans=ans+curr;
                delayQ.push({i,curr});
                forgetQ.push({i,curr});
            }
        }
        return ans;
    }
};