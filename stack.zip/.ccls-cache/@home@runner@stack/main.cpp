#include <iostream>
#include<stack>
using namespace std;
// stack -store data as lifo
// undeflow -ham empty krna chahte haii par stack empty hia
// overflow-full h staack ur ham insrt krna chate haii
/// creation-stack<int>st;
// insert st.push(13);
// delete st.pop();
// st.empty();
// st.top();
// st.size();
// full stack ko print nhi kr a sktee

// int main() {
//   stack<int>st;
//   st.push(10);
//   st.push(20);
//   st.push(30);
//   cout<<st.size()<<endl;
//   st.pop();
//   if(st.empty()){
//     cout<<"stack is empty";
//   }
//   else{
//     cout<<"stack is not empty";
//   }

//   cout<<st.top();
// }

// implementation of stack
// array ,size,top;
// overflow an undeflow consitiom
class mystack{
public:
int*arr;
int size;
int top;
mystack(int size){
  arr=new int[size];
  this->size=size;
  this->top=-1;
}

void push(int data){
  if(top==size-1){
    cout<<"stack overflow";
  }
  else{top++;
  arr[top]=data;
}
}
void pop(){
  if(top==-1){
    cout<<"no element exist";
  }
  else{
  top--;
}
}
bool isempty(){
  if(top==-1){
    return true;
  }
  else{
    return false;
  }
}
int gettop(){
  if(top==-1){
  cout<<"stack empty";
  }
  
  return arr[top];

}
int getsize(){
  return top+1;
}
void print(){
  cout<<top<<endl;
  cout<<gettop()<<endl;
  for(int i=0;i<getsize();i++){
    cout<<arr[i]<<" ";
  }cout<<endl;
}
};

// int main(){
//   mystack st(5);
//   st.push(10);
//   st.print();
//   st.push(20);
//   st.print();
//   st.push(30);
//   st.print();
//   st.pop();
//   st.print();
//   cout<<st.getsize()<<endl;
//   cout<<st.gettop()<<endl;
  

  
  
  
  
// }







void solve(stack<int>& s, int pos) {
  if (pos == 1) {
      s.pop(); 
      return;
  }

  int temp = s.top(); 
  s.pop(); 

  solve(s, pos - 1); 

  s.push(temp);  
}


void deleteMid(stack<int>& s, int n) {
  if (s.empty() || n <= 0) return;

  int pos = (n / 2) + 1;
  solve(s, pos);
}



// insert at bottom of the stack


void help(stack<int> &st,int x){
  if(st.empty()){
    st.push(x);
    return;
}
int temp=st.top();
st.pop();
help(st,x);
st.push(temp);  
}
stack<int> insertAtBottom(stack<int> st,int x){
help(st,x);
return st;
}



// reverse a stack

void insertatbottom(stack<int>&st,int x){
  if(st.empty()){
      st.push(x);
      return;
  }

  int temp=st.top();
  st.pop();
  insertatbottom(st,x);
  st.push(temp);
}

  void Reverse(stack<int> &st){
      if(st.empty()){
          return;
      }
      int temp=st.top();
      st.pop();
      Reverse(st);
      insertatbottom(st,temp);
  }


///insert a  sort a stack

void insertsorted(stack<int>&st,int x){
  if(st.empty() || x>st.top()){  // gltii krenge
    st.push(x);
    return;
  }
  int temp=st.top();
  st.pop();
  insertsorted(st,x);
  st.push(temp);
}

void sort(stack<int>&st){
  if(st.empty()){
    return;
  }
  int temp=st.top();
  st.pop();
  sort(st);
  insertsorted(st,temp);
}

int main(){
 stack<int>st;
  st.push(10);
  st.push(20);
  st.push(30);

  sort(st);
  while(!st.empty()){
    cout<<st.top()<<" ";
    st.pop();
  }
}

//sort a stack

void insertsort(stack<int>&st,int x){
    if(st.empty() || x>st.top()){
        st.push(x);
        return;
    }
    int temp=st.top();
    st.pop();
    insertsort(st,x);
    st.push(temp);

}


void sort(stack<int>&st){
    if(st.empty()){
        return;
    }
    int temp=st.top();
    st.pop();
    sort(st);
    insertsort(st,temp);
}

void insertatbottom(stack<int>&st,int x){
    if(st.empty()){
        st.push(x);
        return;
    }
    int temp=st.top();
    st.pop();
    insertatbottom(st,x);
    st.push(temp);


}

void reverse(stack<int>&st){
    if(st.empty()){
        return;
    }
    int temp=st.top();
    st.pop();
    reverse(st);
    insertatbottom(st,temp);
}


void solve(stack<int>&s,int pos){
    if(pos==1){
        s.pop();
        return;
    }
    int temp=s.top();
    s.pop();
    solve(s,pos-1);
    s.push(temp);

}

void deletemid(stack<int>&s,int n){
    if(s.empty() || n<=0){
        return;
    }
    int pos=(n/2)+1;
    solve(s,pos);


}
class Solution {
public:
    void reverseString(vector<char>& s) {
       stack<char>st;
      for(int i=0;i<s.size();i++){
        st.push(s[i]);
      }
      for(int i=0;i<s.size();i++){
        s[i]=st.top();
        st.pop();
      }

    }
};






int main(){
    stack<int>st;
    st.push(60);
    st.push(20);
    st.push(90);
    st.push(40);
    st.push(50);
    sort(st);
    reverse(st);
    while(!st.empty()){
        cout<<st.top()<<" ";
        st.pop();
    }
}








