#include <iostream>
using namespace std;

// int main() {
  // pointer
  // int a=5;
  // cout<<&a<<endl; // address of a
  // int *ptr=&a;
  // cout<<*ptr<<endl; // give the value of a
  // cout<<ptr<<endl; // ptr k andar a ka address pda hai vo print krdenge
  // cout<<&ptr<<endl; // ptr vale dabbe ka address print hoga

  // int *ptrs=0; // null pointer
  // cout<<*ptrs;  // it is wrong



  // int a=100;
  // int *ptr =&a;
  // cout<<a<<endl;
  // // cout<<*a<<endl; -- null pointer h error
  // cout<<ptr<<endl;
  // // cout<<*ptr<<endl;
  // cout<<&ptr<<endl;
  // cout<<(*ptr)++<<endl; // bdme increase hogii
  // cout<<++(*ptr)<<endl;
  // cout<<(*ptr=*ptr/2)<<endl;
  // cout<<(*ptr=*ptr-2)<<endl;




  // pointer with arrays
   
  // int arr[5]={10,20,30,40,50};
  // cout<<arr<<endl; // print base address
  // cout<<&arr<<endl;// same
  // cout<<arr[0]<<endl;
  // cout<<&arr[0]<<endl;
  // cout<<*arr<<endl; // print the value at ba
  // cout<<*arr+1<<endl;
  // cout<<*(arr+1)<<endl;  // (arr+i)=arr[i];  (i+arr)=i[arr];
  // we cannot do this arr=arr+1; this shows error

// character array
  // char ch[50]="naveen";
  // char *p=ch;
  // cout<<p<<endl; // value print hojayegi isme 
  // cout<<&ch<<endl; // print address
  // cout<<ch[0]<<endl;
  // cout<<&p<<endl;
  // cout<<*p<<endl;   //*(p+0) n print hojayega
  
//   char ch='a';
//   char *cptr=&ch;
//   cout<<cptr;
  
  
// }



// int main() {

// char ch='a';
// char *ptr=&ch;
// cout<<ptr;
// cout<<(void*)&ch;
// // cout<<*ptr;

// }
// int main(){

//   int *p=0;
//   cout<<p;
// }

int main(){
  
}