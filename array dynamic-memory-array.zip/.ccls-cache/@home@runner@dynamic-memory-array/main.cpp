#include <iostream>
#include<vector>

using namespace std;

// int main() {
//   int n;
//   cin>>n;
//   int *arr= new int[n];
//  for(int i=0;i<n;i++){
//    cin>>arr[i];
//  }
//   for(int i=0;i<n;i++){
//     cout<<arr[i]<<" ";
//   }
// }


// void print(vector<int>v){
//   int size=v.size();
//   for(int i=0;i<size;i++){
//     // cout<<v[i]<<" ";
//     cout<<v.at(i)<<endl;
//   }
// }

// int main(){
// vector<int>v;
//   v.push_back(1);
//   v.push_back(2);
//   v.push_back(3);
//   print(v);

//   v.pop_back(); // delete the element in last
//   print(v);

  
// }

// int main(){
//    vector<int>v;
//   while(1){
   
//   int d;
//     cin>>d;
//   v.push_back(d);
//     cout<<v.capacity()<<" "<<v.size();
  
//   }
// }


// int main(){
// vector<int> v;
//   int n;cin>>n;
//   for(int i=0;i<n;i++){
//     int d;
//     cin>>d;
//     v.push_back(d);
//   }
//   for(int i=0;i<100;i++){
//     v.push_back(80);
//   }
//   print(v);
//   v.clear(); // erase all the data in vector


  
// }


// initilaisation of array
// int main(){
//   vector<int>arr;  //1
  
//   vector<int>arr2(5,-1); // 5 size ka array print hoga aur default value 1 jayegi
//   vector<int>arr3={1,2,3,4,5}; // 3
//   int size=arr2.size();
//   for(int i=0;i<size;i++){
//     cout<<arr2.at(i)<<" ";
//   }
// }


// how to copy vector
// int main(){
// vector<int>arr5{1,2,3,4,5};
// vector<int>arr6(arr5);
//   int size=arr5.size();
//   for(int i=0;i<size;i++){
//   cout<<arr6.at(i)<<" ";
// }
// }



// int main(){
// vector<char>jabru;
 
//   int n;
//   cin>>n;
//   for(int i=0;i<n;i++){
//     char d;
//     cin>>d;
//     jabru.push_back(d);
//   }
   
//   for(auto it:jabru){
//     cout<<it<<" ";
   
    
//   }
//   cout<<jabru.front()<<endl;
//   cout<<jabru.back();
// }


int main(){
vector<int>n;
  for(int i=0;i<5;i++){
    int d;
    cin>>d;
    n.push_back(d);
  }
  for(auto et:n){
    cout<<et<<endl;
  }
  cout<<n.front();
  
  
}
