#include <iostream>
#include <climits>
#include <vector>
using namespace std;

/// HOUSE ROBBER PROBLEM 

int solve(vector<int>& nums, int s, int e) {
    if (s > e) {
        return 0;
    }
    int option1 = nums[s] + solve(nums, s + 2, e);
    int option2 = 0 + solve(nums, s + 1, e);
    int finalans = max(option1, option2);
    return finalans;
}

int rob(vector<int>& nums) {
    int n = nums.size();
    if(n==1) return nums[0];
    int option1 = solve(nums, 0, n - 2);
    int option2 = solve(nums, 1, n - 1);
    int option3 = max(option1, option2);
    return option3;
 }

// int main() {
    
//     vector<int> nums = {1, 2, 3, 1};
//     int ans = rob(nums);
//     cout << ans;
//     return 0;
// }


//// COUNT DE ARRANGEMENT  - koi apni purani position p nhi aayega
// 10 20 30- 20 30 10 // this is deaaarngment



int solve(int n){
    if(n==1) return 0;
    if(n==2) return 1;
    int ans=(n-1)*(solve(n-1)+solve(n-2));
    return ans;
}



// int main(){

// int n=4;
// cout<<solve(n);
// }


//// PAINTING FENCE ALGORITHM - ONLY TWO ADJACENT COLOUR ARE SAME

int isfence(int n,int k){
    //base case
if(n==1) return k;
if(n==2) return k+k*(k-1);  // same aur diff vale add kre h isme

int ans=(k-1)*(isfence(n-1,k)+isfence(n-2,k));  // function call
    return ans;
    

    
}



// int main(){
// int n=3; // no of fences
// int k=3; // no of colour
// int ans=isfence(n,k);
//     cout<<ans;
    
// }


 //// EDIT DISTANCE
// convert one word to another word in minium ways
// operation 1 remove insert or replace

int solve(string &a,string &b,int i,int j){

    if(i>=a.length()){
       return b.length()-j; // agr hmari string a vali khtm ho gyii to b vali return krni opdegii
    }

    if(j>=b.length()){
        return a.length()-i;
    }
    int ans=0;

    if(a[i]==b[j]){
        ans=0+solve(a,b,i+1,j+1);
    }
    else{
        // not match
        // insert
        int option1=1+solve(a,b,i,j+1);
        // remove
        int option2=1+solve(a,b,i+1,j);
        // replace
        int option3=1+solve(a,b,i+1,j+1);
        ans=min(option1,min(option2,option3));
    
    }
    return ans;
}


int mindistance(string word1,string word2){
    int i=0; // iterate for word1
    int j=0; //iterte for word2
    int ans=solve(word1,word2,i,j);
    return ans;
    
}
  int solve(string &a,int i,string &b,int j,vector<vector<int>> &dp){
    int ans=0;
    if(i>=a.length()){
        return b.length()-j;
    }
    if(j>=b.length()){
        return a.length()-i;
    }
     if (dp[i][j] != -1) {
        return dp[i][j];
    }

    if(a[i]==b[j]){
        ans=0+solve(a,i+1,b,j+1,dp);
    }
    else{
        int option1=1+solve(a,i+1,b,j,dp);
        int option2=1+solve(a,i,b,j+1,dp);
        int option3=1+solve(a,i+1,b,j+1,dp);
        ans=min(option1,min(option2,option3));
    }
    dp[i][j]=ans;
    return ans;
}
    int editDistance(string word1, string word2) {
         int n = word1.length();
    int m = word2.length();

    vector<vector<int>> dp(n, vector<int>(m, -1));
    return solve(word1, 0, word2, 0, dp);
    }

// int main(){
//     string word1="naveen";
//     string word2="neevan";
//     int ans=mindistance(word1,word2);
//     cout<<ans;
    
// }

// ///// MAXIMAL SQAURE - THE MAX NO OF SQYARE AND RETURN THEIR AREA
// int solve(vector<vector<char>>&matrix,int i,int j,int row,int col,int &maxi){
// if(i>=row || j>=col) return 0;
// // we are going in all direction
// int right=solve(matrix,i,j+1,row,col,maxi);
// int diagonal=solve(matrix,i+1,j+1,row,col,maxi);
// int down=solve(matrix,i+1,j,row,col,maxi);
// /// chack can we build square from current position

// if(matrix[i][j]=='1'){
//     int ans=1+min(right,min(down,diagonal));
//     maxi=max(maxi,ans);
//     return ans;
// }
// else{
//     return 0;
// }
    
// }




// int maxialSquare(vector<vector<char>>&matrix){

//     int i=0;
//     int j=0;
//     int row=matrix.size();
//     int col=matrix[0].size();
//     int maxi=0;
//     int ans=solve(matrix,i,j,row,col,maxi);
//     return maxi*maxi;
// }




