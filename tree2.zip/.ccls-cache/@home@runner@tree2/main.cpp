#include <iostream>
using namespace std;

// left subtree aur right dubtree ka absolute difference armost 1 hai
// abs(lh-rh)<=1
bool isbalalnced=true;
int height(Node*root){
    if(!root) return NULL;
    int a=height(root->left);
    int b=height(root->right);
    if(isbalanced && abs(a-b)>1){
        isbalanced=false;
    }
    return (a,b)+1;
}

bool isbalanced(Node*root){
    height(root);
    return isbalanced;
}

// ek jaise node jha s niche s dono p and q poehle br miljana vhi coomon anestro hai
// approach- sbse phele hm p and q ko dhundenge

class Solution {
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
       if(root==NULL){
        return NULL;
       } 
       if(root==p){
        return p;
       }
       if(root==q){
        return q;
       }

       TreeNode*leftans=lowestCommonAncestor(root->left,p,q);
       TreeNode*rightans=lowestCommonAncestor(root->right,p,q);

       if(leftans==NULL && rightans==NULL) return NULL;
       else if(leftans==NULL && rightans!=NULL) return rightans;
       else if(leftans!=NULL && rightans==NULL) return leftans;
       else return root;




    }
};


// path k end m leaf node honi chiaye

class Solution {
public:
   bool solve(TreeNode* root, int targetSum,int sum){
      if(root==NULL) return false;
           sum+=root->val;
        if(root->left==NULL && root->right==NULL){


           if(sum==targetSum){
            return true;
           } 
           return false;
        }

        bool leftans=solve(root->left,targetSum,sum);
        bool rightans=solve(root->right,targetSum,sum);
        return leftans||rightans;
   }


    bool hasPathSum(TreeNode* root, int targetSum) {
        int sum=0;
        return solve(root,targetSum,sum);

    }
};
// same as above bas sime hme vo arr return krni hain

class Solution {
public:

void solve(TreeNode* root, int targetSum,vector<vector<int>>&ans,vector<int>temp,int sum){

if(root==NULL) return;
sum+=root->val;
temp.push_back(root->val);

if(root->left==NULL && root->right==NULL){
    if(sum==targetSum){
        ans.push_back(temp);
    }
    else{
        return;
    }
}

solve(root->left,targetSum,ans,temp,sum);
solve(root->right,targetSum,ans,temp,sum);

}

    vector<vector<int>> pathSum(TreeNode* root, int targetSum) {
        vector<vector<int>>ans;
        vector<int>temp;
        int sum=0;
        solve(root,targetSum,ans,temp,sum);
        return ans;
    }
};


/// make an tree using pre order ans post order


#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = NULL;
        right = NULL;
    }
};



int help(int in[],int n,int target){
  for(int i=0;i<n;i++){
      if(in[i]==target) return i;
  }
  return -1;
}



Node*helper(int in[],int pre[],int &preindex,int instart,int inend,int n){
  if(preindex>n || instart>inend) return NULL;

  int elem=pre[preindex];
  preindex++;

  Node*root=new Node(elem);

  int pos=help(in,n,elem);

  root->left=helper(in,pre,preindex,instart,pos-1,n);
  root->right=helper(in,pre,preindex,pos+1,inend,n);
  return root;


}




Node* buildTree(int in[],int pre[], int n)
{
  int preindex=0;
  Node*root=helper(in,pre,preindex,0,n-1,n);
  return root;
}




/// using post order and inorder
// imp concept- order hme reursion m pehle right vala ko pehle lena hogaa

