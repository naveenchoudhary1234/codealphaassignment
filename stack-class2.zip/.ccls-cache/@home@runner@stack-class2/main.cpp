#include <iostream>
#include<stack>
using namespace std;

// ek single array m 2 stack implementtaion
class Stack{
public:
int *arr;
int size;
int top1;
int top2;

Stack(int size){
  arr=new int[size];
  this->size=size;
  top1=-1;
  top2=size;
}


void push1(int data){
  if(top2-top1==1){
    cout<<"overflow";
  }
  else{
  top1++;
  arr[top1]=data;
}
}

void push2(int data){
  if(top2-top1==1){
    cout<<"overflow";
  }
  else{
  top2--;
  arr[top2]=data;
}
}

void pop1(){
  if(top1==-1){
    cout<<"stack is empty";
  }
  else{
arr[top1]=0;
  top1--;
  
}
}

void pop2(){
  if(top2==size){
    cout<<"stack is empty";
  }
  else{
arr[top2]=0;
  top2++;


  
}
}
void print(){
  cout<<"top1"<<top1<<endl;
  cout<<"top2"<<top2<<endl;
  for(int i=0;i<size;i++){
    cout<<arr[i]<<" ";
  }
}

};

// int main() {
//   Stack st(6);
//   st.print();
//   st.push1(10);
//   st.print();
//   st.push1(20);
//   st.print();
//   st.push2(30);
//   st.print();
//   st.push2(40);
//   st.print();
  
// }



//////**** valid parenthesis
//({} ()) -it is valid

// cancel krdo sari ko agr hojaye to valid hai
// stack bnao
// jb bi close vala bracket mila to vo stack m dhunde jayegii ki iska open pda hai ya nhoii
// bool isvalid(string s){
//   stack<char>st;
// for(int i=0;i<s.length();i++){
//   char ch=s[i]; // open bracket
//   if(ch=='(' || ch=='[' || ch=='{'){
//     // for open bracet just push
//     st.push(ch);
//   }
//   else{
//     // closing bracket
//     if(!s.empty()){
//     if(ch==')' && st.top()=='('){
//       st.pop();
//     }
//     else if(ch=='}' && st.top()=='{'){
//       st.pop();
//     }
//     else if(ch==']' && st.top()=='['){
//       st.pop();
//     }
//     else{
//       return false;
//     }
//   }
// }
// }
//   if(st.size()==0) return true;
//   else return true;
// }



/// Remove Reduntant Brackets
// remove karna hia faltu ki bracket ko
// agar 2 bracket k bich m operator present h to vo shii hai
// vrna faltu hai


bool checkreduntant(string &str){
  stack<char>st;
  for(int i=0;i<str.length();i++){
    char ch=str[i];
    if(ch=='(' || ch=='+' || ch=='-' || ch=='*' ||ch=='/'){
      st.push(ch);
    }
    else if(ch==')'){
      // closing bracket
      int oprcount=0;
      while(!st.empty() && st.top()!='('){
        char temp=st.top();
        if(temp=='+' ||temp=='-' ||temp=='*' ||temp=='/'){
        oprcount++;
        
      }st.pop();
      }
      st.pop();
      if(oprcount==0) return true;



        
      
    }
  }
  return false;
}



int main(){
  string str="(((a+b)*(c+d)))";
  bool ans=checkreduntant(str);
  if(ans==true){
    cout<<"reduntatnt bracket";
  }
  else{
    cout<<"noo such bracket";
  }
}

class Solution {
public:
    int minAddToMakeValid(string s) {
        stack<char>st;
        for(auto ch:s){
            if(ch=='('){
                st.push(ch);
            }
            else{
                if(!st.empty() && st.top()=='('){
                    st.pop();
                }
                else{
                    st.push(ch);
                }
            }
        }
        return st.size();
    }
};  


// longest valid parnerhseis
class Solution {
public:
    int longestValidParentheses(string s) {
        stack<int>st;
        st.push(-1);
        int maxlen=0;
        for(int i=0;i<s.length();i++){
            char ch=s[i];
            if(ch=='('){
              st.push(i);
            }
            else{
               st.pop();
               if(st.empty()){
                st.push(i);

               }
               else{
                int len=i-st.top();
                maxlen=max(len,maxlen);
               } 
            }
        }
        return maxlen;
    }
};

