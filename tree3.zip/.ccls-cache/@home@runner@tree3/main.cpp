/// views - mtlb hm tree ko kaise dekh rhe hain
// leftviws- using level order first element is out left elemnt
#include<iostream>
#include<queue>
#include<map>
using namespace std;

class Node{
public:
int data;
Node* left;
Node* right;

Node(int data){
  this->data=data;
  this->left=NULL;
  this->right=NULL;
}


};

Node*constructTree(){
  int data;
  cin>>data;
  if(data==-1) return NULL;
  Node*root=new Node(data);
  root->left=constructTree();
  root->right=constructTree();

  return root;
}

void preorder(Node*root){
  if(root==NULL) return;
  // nlr
  cout<<root->data;
  preorder(root->left);
  preorder(root->right);
}

void postorder(Node*root){
  if(root==NULL) return;

  postorder(root->left);
  postorder(root->right);
  cout<<root->data;
  
}

void inorder(Node*root){
  if(root==NULL) return;
  inorder(root->left);
  cout<<root->data;
  inorder(root->right);
}

void levelorder(Node*root){
  if(root==NULL) return;
  queue<Node*>q;
  q.push(root);
  q.push(NULL);

  while(!q.empty()){
    Node*temp=q.front();
    q.pop();

    if(temp==NULL){
      cout<<endl;
      if(!q.empty()){
        q.push(NULL);
      }
    }
    else{
      cout<<temp->data<<" ";
      if(temp->left!=NULL){
        q.push(temp->left);
      }
      if(temp->right!=NULL){
        q.push(temp->right);
      }
    }
  }
  
  
}


void printleftView(Node*root,int level,vector<int>&leftview){
  if(root==NULL) return;
  if(level==leftview.size()){
    // leftview ki node milgii storw karlo
    leftview.push_back(root->data);
  }
    printleftView(root->left,level+1,leftview);
    printleftView(root->right,level+1,leftview);
  
}

void printrightview(Node*root,int level,vector<int>&rightview){
  if(root==NULL) return;
  if(level==rightview.size()){
    // leftview ki node milgii storw karlo
    rightview.push_back(root->data);
  }
    
  printrightview(root->right,level+1,rightview);
  printrightview(root->left,level+1,rightview);
}
// vertical level create krlie left m jayeng -1 krte rhnge right m level +1 krte rhenge
void printtopview(Node*root){
  map<int,int>hdtoNodeMap;
  queue<pair<Node*,int>>q;  // ek khud node aur uksa level
  q.push(make_pair(root,0));  // push intiytial state of queue
  while(!q.empty()){
    pair<Node*,int>temp=q.front();
    q.pop();
    Node*frontnode=temp.first;
    int hd=temp.second;
    // agar abhi tk is horizontal distance k lite ans store nhii hai to ab karl
    if(hdtoNodeMap.find(hd)==hdtoNodeMap.end()){ // mtltb koi bhi entry nhi milii
      hdtoNodeMap[hd]=frontnode->data;
    }

    // child ko dekhna hai
    if(frontnode->left!=NULL){
      q.push(make_pair(frontnode->left,hd-1));
    }
    if(frontnode->right!=NULL){
      q.push(make_pair(frontnode->right,hd+1));
    }
    
  }
  for(auto it:hdtoNodeMap){
    cout<<it.second<<" ";
  }
}

void bottomview(Node*root){
  map<int,int>hdtoNodeMap;
  queue<pair<Node*,int>>q;  // ek khud node aur uksa level
  q.push(make_pair(root,0));  // push intiytial state of queue
  while(!q.empty()){
    pair<Node*,int>temp=q.front();
    q.pop();
    Node*frontnode=temp.first;
    int hd=temp.second;
    // agar abhi tk is horizontal distance k lite ans store nhii hai to ab karl
     
      hdtoNodeMap[hd]=frontnode->data;
    

    // chuld ko dekhna hai
    if(frontnode->left!=NULL){
      q.push(make_pair(frontnode->left,hd-1));
    }
    if(frontnode->right!=NULL){
      q.push(make_pair(frontnode->right,hd+1));
    }

  }
  for(auto it:hdtoNodeMap){
    cout<<it.second<<" ";
  }
}

int main(){
  Node*root=constructTree();
  // levelorder(root);
  vector<int>leftview;
  vector<int>rightview;
  printleftView(root,0,leftview);
  for(int i=0;i<leftview.size();i++){
    cout<<leftview[i]<<" ";
  }
  cout<<endl;

  printrightview(root,0,rightview);
  for(int i=0;i<rightview.size();i++){
    cout<<rightview[i]<<" ";
  }
  cout<<endl;
int horizontaldistance=0;
  printtopview(root,horizontaldistance);

  bottomview(root);
}




//***** Boundary Traversal
// left + // leaf+// right branch
void printleftboundary(Node *root)
{

    // in a leaf node s pehle tk print krana hain 
    if(root==NULL) return;
    if(root->left==NULL && root->right==NULL) return;

    cout<<root->data<<" "; 
    if(root->left!=NULL){
        printleftboundary(root->left);
    }
    else{
        printleftboundary(root->right);
    }

}

void printleafboundary(Node*root){
  if(root->left==NULL && root->right==NULL){
    cout<<root->data;
  }
  printleafboundary(root->left);
  printleafboundary(root->right);
}

void printrightboundary(Node*root){
  // ulta jana pdegaa
  if(root==NULL) return;
  if(root->left==NULL && root->right==NULL) return;

  if(root->right!=NULL){
      printleftboundary(root->left);
  }
  else{
      printleftboundary(root->right);
  }
  cout<<root->data<<" "; 
  
}

void boundarytraversal(Node*root){
  if(root==NULL) return;
  printleftboundary(root->left);
  printleafboundary(root->left);
  printleafboundary(root->right);
  printrightboundary(root->right);
  
 
}