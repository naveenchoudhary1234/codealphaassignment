#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

// string decodeMessage(string key,string message){
//   char start='a';
//   char mapping[1000]={0};
//   for(auto ch:key){
//     if(ch!=' '&& mapping[ch]==0){
//       mapping[ch]=start;
//       start++;
//     }
//   }
//   // update ans
//   string ans;
//   for(auto ch:message){
//     if(ch==' '){
//       ans.push_back(' ');
//     }
//     else{
//       ans.push_back(mapping[ch]);
//     }
//   }return ans;
// }

// int main() {
//     string key;
//     getline(cin, key);
//     string message = "naveen choudhary";
//     string a = decodeMessage(key, message);
//     cout << a;
//     return 0;
// }







// is question m hmee garbage ka time nikalna hai hmare pas 3 truck h 
// int garbagecollector(vector<string>& garbage,vector<string>&travel){
//   int pickplastic=0;
//   int pickmetal=0;
//   int pickglass=0;
  
//   int travelp=0;
//   int travelm=0;
//   int travelg=0;

//   // hme kaise pta clehga kha tak jana hai islie variable ko define karna pdega
//   int lastp=0;
//   int lastg=0;
//   int lastm=0;

//  // ham ab pure garbage p travel karenge
//   for(int i=0;i<garbage.size();i++){
//     string current=garbage[i];
//     // ab hme ek ek string p jayenge aur check karenge ki metal h ya plastic h
//     for(int j=0;j<current.length();j++){
//       char ch=current[j];
//       if(ch=='p'){
//         pickplastic++;
//         lastp=i;
//       }
//       else if(ch=='g'){
//         pickglass++;
//         lastg=i;
//       }
//       else if(ch=='m'){
//         pickmetal++;
//         lastm=i;
//       }
//     }
//   }

//  //calculate travel time
// for(int i = 0; i < lastp; i++) {
//     travelp += stoi(travel[i]);
// }
// for(int i = 0; i < lastg; i++) {
//     travelg += stoi(travel[i]);
// }
// for(int i = 0; i < lastm; i++) {
//     travelm += stoi(travel[i]);
// }
// int ans=(pickplastic+travelp)+(pickglass+travelg)+(pickmetal+travelm);
//   return ans;
  
// }

int garbagecollector(string garbage,)
// int main() {
//     int numGarbageItems;
//     cout << "Enter the number of garbage items: ";
//     cin >> numGarbageItems;

//     vector<string> garbage(numGarbageItems);
//     vector<string> travel(numGarbageItems);

//     cout << "Enter the type of garbage (p for plastic, g for glass, m for metal) and travel time (separated by space) for each item:\n";
//     for (int i = 0; i < numGarbageItems; i++) {
//         cin >> garbage[i] >> travel[i];
//     }

//     int totalEffort = garbagecollector(garbage, travel);

//     cout << "Total effort (picking + travel): " << totalEffort << endl;

//     return 0;
// }



// custom sort string
// string str;
// bool compare(char char1,char char2){
//   return (str.find(char1)<str.find(char2)); // hmari order vali string k hisab s chl rha hai ye agar hmara char 1 pehle aa rh hai to use pehle hi rakho
// }

// string customstring(string order,string s){ 
//   str=order;
// sort(s.begin(),s.end(),compare);
//    return s;
// }
// int main(){
// string order="cba";
//   string s="abcd";
//   string ans=customstring(order,s);
//   cout<<ans;
  
// }


// pattern aab mtlb pehla character ek br aa rha hai phir  2 vala 2 br aa rha hai
// void createmapping(string &str){
//   char start='a';
//   char mapping[300]={0};
//   for(auto ch:str){
//     if(mapping[ch]==0){
//       mapping[ch]=start;
//       start++;
//     }
//   }
//   // update the string
//   for(int i=0;i<str.length();i++){
//     char ch=str[i];
//     str[i]=mapping[ch];
//   }
// }



// vector <string> findandreplacepattern(vector<string>&words,string pattern){
//   vector<string>ans;
//   // hmare pas ek pattern pda hai jo question md de rakha hai to hame usko bhi abc k format m hi convert karna pdega islie ye kiyaa
//   createmapping(pattern);

//   for(auto s:words){
//     string tempstring=s;
//     createmapping(tempstring);
//     if(tempstring==pattern){
//       ans.push_back(s);
//     }
//   }return ans;
// }

// int main(){
//   vector<string>words={"abb"};
//   string pattern;
//   getline(cin,pattern);
//    vector<string>a=findandreplacepattern(words,pattern);
//   for(const auto& word : a) {
//       cout << word << " ";
//   }
// }



