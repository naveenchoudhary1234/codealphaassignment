#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// int main() {
//   const char s1[6] = "hello";
//   const char s2[6] = "world";
//   string s3 = string(s1) + " " + string(s2);
//   cout<<s3;

//   return 0;
// }

//// question 1 Anangram
// approach 1

// int main(){
//   string a="naveen";
//   string b="navneejk";
//   sort(a.begin(),a.end());
//   sort(b.begin(),b.end());
//   if(a==b) cout<<"valid anangram";
//   else cout<<"no valid";
// }

// approach 2
//using with the help of frequency table -same h to h 
// bool isanagram(string s, string t) {
//     int freqtable[128] = {0}; 
//     for (int i = 0; i < s.size(); i++) {
//         freqtable[static_cast<int>(s[i])]++;
//     }
//     for (int i = 0; i < t.size(); i++) {
//         freqtable[static_cast<int>(t[i])]--;
//     }
//     for (int i = 0; i < 128; i++) { 
//         if (freqtable[i] != 0) {
//             return false;
//         }
//     }
//     return true;
// }

// int main() {
//     string s = "naveen";
//     string t = "neevan";
//     bool ans = isanagram(s, t);
//     cout << ans;
// }


/// reverse only the letters
// string reverseOnlyLetters(string s) {
//      int left=0;
//      int right=s.length()-1;
//      while(left<=right){
//         if(isalpha(s[left]) && isalpha(s[right])){
//             swap(s[left],s[right]);
//             left++;
//             right--;
//         }
//         else if(!isalpha(s[left])){
//             left++;
//         }
//         else{
//             right--;
//         }
//      }  return s; 
//     }
// };

// int main() {
//     string str = "nav-abc";
//     reverse(str);
//     return 0;
// }


/// longest common prefix - two string m jo common h 
// Input: strs = ["flower","flow","flight"]
//Output: "fl"

// string longestCommonPrefix(vector<string>& strs) {
//     string ans;
//     int i=0;
//     while(true){
//         char currentcharacter=0;
//         for(auto str:strs){
//             if(i>=str.size()){
//                 currentcharacter=0;
//                 break;
//             }
//             if(currentcharacter==0){
//             currentcharacter=str[i];}
//             else if(currentcharacter!=str[i]){
//                 currentcharacter=0;
//                 break;
//             }
//         }
//         if(currentcharacter==0){
//             break;
//         }
//         if(currentcharacter==' '){
//             ans.push_back(' ');
//         }
//         ans.push_back(currentcharacter);
//         i++;
//     }
//     return ans;
// }


// reverse only yhe vowel of a string
// bool isvowel(char ch){
//   ch=tolower(ch);
//   return ch=='a'|| ch=='e' || ch=='i' || ch=='o' ||ch=='u';
  
// }



// string vowel(string str){
//   int left=0;
//   int right=str.length()-1;
//   while(left<=right){
//     if(isvowel(str[left]) && isvowel(str[right])){
//       swap(str[left],str[right]);
//       left++;
//       right--;
//     }
//     else if(!isvowel(str[left])){
//       left++;
//     }
//     else{
//       right--;
//     }
//   }return str;
// }
// int main(){
//   string str="leetcode";
//  string a=vowel(str);
//   cout<<a;
// }


// isomorphic string- eg egg and odd hm e ko alg language m o bolenge aur g ko d bolde hai agar aise mapping kar skte ha to phir ye string h

// void createmapping(string &str){
//   char start='a'; // isme mapping s aur t dono ki h
//   char mapping[256]={0}; // isme vo store krega mapping t k sath
//   for(auto ch:str){
//     if(mapping[ch]==0){
//       mapping[ch]=start;
//       start++;
//     }
//   }
//   for(int i=0;i<str.length();i++){
//    char ch=str[i];
//     str[i]=mapping[ch];
    
//   }
// }
// bool isIsormphic(string s,string t){
// createmapping(s);
// createmapping(t);
// if(s!=t) return false;
// else return true;

// }
// int main(){
//   string s="paper";
//   string t="title";
//   bool ans=isIsormphic(s,t);
//   cout<<ans;
// }







