#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

// int main() {
//  vector<int>v;
//   int n;
//   cin>>n;
//   for(int i=0;i<n;i++){
//    int d;
//     cin>>d;
//     v.push_back(d);
//   }

//   sort(v.begin(), v.end()); 
//   for(auto et:v){
    

//     cout<<et<<" ";
//   }
// }




// void shifting(int arr[],int n){
//   int j=0;
//   for(int i=0;i<n;i++){
//     if(arr[i]<j){
//       swap(arr[i],arr[j]);
//       j++;
//     }
//   }
//   for(int i=0;i<n;i++){
//     cout<<arr[i];
//   }
// }

// int main(){
// int arr[]={0,-3,-4,0};
//   int n=4;
//   shifting(arr,n);

// }


// int main(){
//   int arr[]={1,2,3,-1,-5,-8};
//   int n=6;
//   for(int i=0;i<6;i++){
//     sort(arr,arr+n);
    
//   }
//   for(int i=0;i<n;i++){
//     cout<<arr[i];
//   }
// }




/// rotate an array imp question 90 degree clockwise
void rotate(vector<vector<int>>v){
  int n=v.size();
  for(int i=0;i<n;i++){
    for(int j=i;j<v[i].size();j++){
      swap(v[i][j],v[j][i]);
    }
  }
  for(int i=0;i<n;i++){
    reverse(v[i].begin(),v[i].end());
  }
  for(int i=0;i<n;i++){
    for(int j=0;j<n;j++)
      cout<<v[i][j]<<" ";
    cout<<endl;
  }
}
int main(){
  vector<vector<int>>v={{1,2,3},{4,5,6},{7,8,9}};
rotate(v);

  
}













