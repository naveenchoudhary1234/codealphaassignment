#include <iostream>
#include<vector>
#include<algorithm>
#include<set>

using namespace std;


// find unique pair which have differenece qual to 2




// class Solution {
// public:
//     int findPairs(vector<int>& nums, int k) {
//         sort(nums.begin(), nums.end());
//         set<pair<int, int>> ans;
//         int i = 0;
//         int j = 1;
//         while (j < nums.size()) {
//             int diff = nums[j] - nums[i];
//             if (diff == k) {
//                 ans.insert(make_pair(nums[i], nums[j]));
//                 i++;
//                 j++;
//             } else if (diff > k) {
//                 i++;
//             } else {
//                 j++;
//             }
//             if(i==j) j++;
//         }
//         return ans.size();
//     }
// };



// int main() {
//     vector<int> nums = {1, 2, 3, 4, 5, 6};
//     int k = 2;
//     findpair(nums, k);
//     return 0;
// }



// two pointer approach
vector<int> closestelement(vector<int>& v, int k, int x) {
    int l = 0;
    int h = v.size() - 1;
    while (h - l >= k) {
        if (x - v[l] > v[h] - x) {
            l++;
        } else {
            h--; // Correct decrement
        }
    }
    vector<int> ans;
    for (int i = l; i <= h; i++) {
        ans.push_back(v[i]);
    }
    return ans;
}

int main() {
    vector<int> v = {1,2,3,4,5};
    int x = 3;
    int k = 4;
    vector<int> result = closestelement(v, k, x);
    for (int val : result) {
        cout << val << " ";
    }
    return 0;
}

vector<vector<int>> threeSum(vector<int>& nums) {
  vector<vector<int>>ans;
  sort(nums.begin(),nums.end());
  int n=nums.size();
  for(int i=0;i<nums.size();i++){
    int a=nums[i];
    int target=-a;
    int start=i+1;
    int end=n-1;
    while(start<end){
      if(nums[start]+nums[end]==target){
        ans.push_back({nums[i],nums[start],nums[end]});
        while(start<end && nums[start]==nums[start+1]) start++;
        while(start<end && nums[end]==nums[end-1]) end--;
        start++;
        end--;
      }
      else if(nums[start]+nums[end]>target){
        end--;
      }
      else{
        start++;
      }
    }
    while(i+1<n && nums[i+1]==nums[i]) i++;

  }
  return ans;
}

int closest3Sum(int arr[], int n, int x) {
    int closest_sum = INT_MAX;
    std::sort(arr, arr + n); // Sort the array

    for (int i = 0; i < n - 2; i++) {
        int start = i + 1;
        int end = n - 1;

        while (start < end) {
            int sum = arr[i] + arr[start] + arr[end];

            // Update the closest sum if the current sum is closer to x
            if (abs(x - sum) < abs(x - closest_sum)) {
                closest_sum = sum;
            }

            if (sum < x) {
                start++;
            } else {
                end--;
            }
        }
    }

    return closest_sum;
}

bool find3Numbers(int arr[], int n, int x) {
    sort(arr,arr+n);
    for(int i=0;i<n-2;i++){
        int start=i+1;
        int end=n-1;
        while(start<end){
            if(arr[start]+arr[end]+arr[i]==x){
                return true;
            }
            else if(arr[start]+arr[end]+arr[i]<x){
                start++;
            }
            else{
                end--;
            }
        }
    }
    return false;
}




/// exponenetial search 

// int binarysearch(int arr[],int start,int end,int x){
//   while(start<=end){
//     int mid=(start+end)/2;
//     if(arr[mid]==x) return mid;
//     else if(x>arr[mid]) start=mid+1;
//     else end=mid-1;
//   }
//   return -1;
// }


// int expsearch(int arr[],int n,int x){
//   if(arr[0]==x) return 0;
//   int i=1;
//   while(i<n && arr[i]<=x){
//     i*=2;
//   }
//   return binarysearch(arr,i/2,min(i,n-1),x);
// }

// int main(){
//   int arr[]={1,2,3,4,5,6,7,8,9};
//   int n=9;
//   int x=5;
//   int ans=expsearch(arr,n,x);
//   if (ans != -1) {
//     cout << "Element " << x << " found at index " << ans << endl;
//   } else {
//     cout << "Element " << x << " not found" << endl;
//   }
//   return 0;
// }


//*** book allocation problem
bool ispossiblesolution(int a[],int n,int m,int sol){
  int pagesum=0;// current sum btata ja rha hai
  int counter=1;// kitne allocate kar diye hai
  for(int i=0;i<n;i++){
    if(a[i]>sol){ // current book no of pages solution s bde hai  no of pages hi bde hai mid s
      return false;
    }
    if(pagesum+a[i]>sol){
      counter++;
      pagesum=a[i];
      if(counter>m) return false;
    }
    else{
      pagesum+=a[i];
    }
  }return true;
  
}




int book(int a[],int n,int m){ // n- no of pages m-no of student
  if(m>n) return -1;
  int start=0;
  int end=accumulate(a,a+n,0); // sum nikalta hai arr,arr+size,initial value
  int ans=-1;
  while(start<=end){
    int mid=(start+end)/2;
    if(ispossiblesolution(a,n,m,mid)){
      ans=mid;
      end=mid-1;
    }
    else{
      start=mid+1;
    }
  }return ans;
  
  
}


int main(){
  int a[]={12,34,67,90};
  int n=4;  // no of pages
  int m=5;  // no of student
  bool check=book(a,n,m);
  cout<<check;
  
}


// painter problem
// bool ispossiblesoln(int arr[],int n,int k,int sol){
//   int timesum=0;
//   int counter=1;
//   for(int i=0;i<n;i++){
//     if(arr[i]>sol) return false;
//     if(arr[i]+timesum>sol){
//       counter++;
//     timesum=arr[i];
//     if(counter>k) return false;}
  
//   else{
//     timesum+=arr[i];
//   }
//   }
//   return true;
  
// }



// int boat(int arr[],int n,int k){
//   int start=0;
//   int ans=-1;
//   int end=accumulate(arr,arr+n,0);
//   while(start<=end){
//     int mid=(start+end)/2;
//     if(ispossiblesoln(arr,n,k,mid)){
//       ans=mid;
//       end=mid-1;
      
//     }
//     else{
//       start=mid+1;
//     }
//   }return ans;
// }





// int main(){
//   int arr[]={10,20,30,40};
//   int n=4; // no of board
//   int k=2;// no of painter
//   bool check=boat(arr,n,k);
//   cout<<check;
// }


//* cow problem 
// bool ispossiblesolution(int arr[],int n,int k,int sol){
//   int counter=1;
//   int pos=arr[0];
//   for(int i=0;i<n;i++){
//     if(arr[i]-pos>=sol){
//       counter++;
//       pos=arr[i];
      
//     }
//     if(counter==k) return true;
//   }return false;
// }



// int cow(int arr[],int n,int k){
//   sort(arr,arr+n);
//   int left=0;
 
//   int right = arr[n - 1] - arr[0]; // maxposition- min position
//    int ans=-1;
//   while(left<=right){
//     int mid=(left+right)/2;
//     if(ispossiblesolution(arr,n,k,mid)){
//       ans=mid;
//       left=mid+1;
      
//     }
//     else{
//       right=mid-1;
//     }
//   }return ans;
//  }


// // no of solution 4 tak hi hone chaie 

// int main(){
//   int arr[]={1,2,4,8,9};
//   int n=5;
//   int k=3;
//   cout<<cow(arr,n,k);sol
 
// }

//** tree cutting problem
bool ispossiblesolution(vector<long long int>trees,long long int m,long long int mid){
  long long int woodcollector=0;
  for(int i=0;i<trees.size();i++){
    if(trees[i]>mid)
      woodcollector+=trees[i]-mid;
  }return woodcollector>=m;
}


long long int macsawbladeheight(vector<long long int>trees, long long int m){
  long long int start=0,end,ans=-1;
  end=*max_element(trees.begin(),trees.end());
  while(start<=end){
    long long int mid=(start+(end-start))/2;
    if(ispossiblesolution(trees,m,mid)){
      ans=mid;
      start=mid+1;
    }
    else{
      end=mid-1;
    }
  }return ans;
}

// int main(){
//   long long int n,m;
//   cin>>n;// total no of tree
//   cin>>m;// atleast height to cut tree
//   vector<long long int>trees;
//   while(n--){
//     long long int height;
//     cin>>height;
//     trees.push_back(height);
//   }
//   cout<<macsawbladeheight(trees,m)<<endl;
// }




