#include <iostream>
using namespace std;


//shallow copy and deep copy

class abc{
public:
int x;
int *y;

abc(int _x,int _y):x(_x),y(new int(_y)){}
  void print()const{
    printf("%d %d %p\n",x,*y,y);
  }


// deep copy construcor
abc(const abc&obj){
  x=obj.x;
  y=new int(*obj.y);
}

};

// int main1() {

// abc a(1,2);
//   a.print();

//   abc b(a);
//   *b.y=20;
//   b.print();
//   a.print();

// }



/// can construcotr be made private-yes it can made private ham koi friend class bna k uski class de skte hai main k andar call nhi kar skte
class box{
int width;
box(int _val): width(_val) {} 
public:

int getwidth()const{
  return width;
}
void setwidth(int _val){
  width=_val;
}
friend class boxfactory;
};


class boxfactory{
int count;
public:
box getABox(int _w){
  ++count;
  return box(_w);
}


};

// int main(){

//   boxfactory bfact;
//   box b=bfact.getABox(5);
//   cout<<b.getwidth()<<endl;
// }



// Friend Keyword 
// used to share the infromation
// private bi dikhana chahte ho

class a{
int x;
public:
a(int _val):x(_val){};
int getx() const{
  return x;
}
void setx(int _val){
  x=_val;
}
friend class b;
};

class b{
public:
void print(const a&A){
  cout<<A.x;
}
};


// int main(){
// a A(5);
//   b B;
//   B.print(A);
  
// }


class cricket{
public:
int over;
int run;
float runrate;
void calaculaterate(){
  runrate=run/over;
  cout<<runrate;
}
};

class T20:public cricket{
public:
int r,o;

void input(int a,int b){
  over=a;
  run=b;
  cout<<"over"<<over<<" ";
  cout<<"run"<<run<<" ";
}

};

class Oneday:public cricket{
public:
int r,o;
void one(int c,int d){
  over=c;
  over=d;
}

};

class testmatch:public cricket{
public:
int r,o;
void test(int a,int b){
  over=a;
  over=b;
}

};

// int main(){
//   T20 t20match;
//   t20match.input(20,200);

//   Oneday onedaymatch;
//   onedaymatch.one(50,300);

//   testmatch Test;
//   Test.test(90,500);
  
  
  
  
// }

int main(){
  // int a=10;
  char c='a';
  
  int *q=(int*)&c;
  cout<<q<<endl;
  cout<<*q;
  // int *p
}
