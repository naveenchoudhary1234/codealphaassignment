#include <iostream>
#include<vector>
using namespace std;

// void bubble(vector<int>v){
//   int n=v.size();
//   for(int i=0;i<n-1;i++){
//     for(int j=0;j<n-i-1;j++){
//       if(v[j]>v[j+1]) swap(v[j],v[j+1]);
//     }
 
//   }
//   for(int i=0;i<5;i++){
//     cout<<v[i]<<" ";
// }
// }

// void selectionsort(vector<int>b){
//   int n=b.size();
//   for(int i=0;i<n-1;i++){
//     int minIndex=i;
//     for(int j=i+1;j<n;j++){
//       if(b[j]<b[minIndex]) minIndex=j;
//     }swap(b[i],b[minIndex]);
//   }for(int i=0;i<n;i++){
//     cout<<b[i]<<" ";
//   }
  
// }
// void insertion(vector<int>c){
//   int n=c.size();
//   for(int i=1;i<n;i++){
//     int key=c[i];
//     int j=i-1;
//     while(j>=0 && c[j]>key){
//       c[j+1]=c[j];
//       j--;
//     }
//     c[j+1]=key;
//   }
//   for(int i=0;i<n;i++){
//     cout<<c[i]<<" ";
//   }
// }


// void bubblesort(vector<int>v){
//   int n=v.size();
//   for(int i=0;i<n-1;i++){
//     for(int j=0;j<n-i-1;j++){
//       if(v[j]>v[j+1]) swap(v[j],v[j+1]);
//     }
//   }
//   for(int i=0;i<n;i++){
//     cout<<v[i]<<endl;
//   }
// }

// void selectionsort(vector<int>b){
//   int n=b.size();
//   for(int i=0;i<n-1;i++){
//     int minindex=i;
//     for(int j=i;j<n;j++){
//       if(b[j]<b[minindex]){
//         minindex=b[j];
//       }
//       swap(b[i],b[minindex]);
//     }
//   }  for(int i=0;i<n;i++){
//     cout<<b[i]<<endl;
//   }
// }

// void insertion(vector<int>c){
//   int n=c.size();
//   for(int i=0;i<n;i++){
//     int key=c[i];
//     int j=i-1;
//     while(j>=0 && j>key){
//       c[j+1]=c[j];
//       j--;
//     }
//     key=
//   }
// }

// int main() {
// vector<int>v={5,4,3,1,2};
//   vector<int>b={5,4,3,1,2};
//   vector<int>c={5,4,3,1,2};
//   bubblesort(v);
//   selectionsort(b);
//   // insertion(c);
// }


void swaps(int *a,int *b){
  int temp=*a;
  *a=*b;
  *b=temp;
}

void bubblesort(vector<int>&v){
  int n=v.size();
  for(int i=0;i<n-1;i++){
      for(int j=0;j<n-i-1;j++){
          if(v[j]>v[j+1]) swaps(&v[j],&v[j+1]);
      }
  }for(int i=0;i<n;i++){
      cout<<v[i]<<" ";
  }
}

int main() {
vector<int>v={5,4,3,1,2};
  bubblesort(v);

}