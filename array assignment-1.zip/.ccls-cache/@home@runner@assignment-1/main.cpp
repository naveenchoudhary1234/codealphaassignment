#include <iostream>
#include <unordered_map>
#include<vector>
#include<set>
using namespace std;

// void findmissing(int a[],int n){
//   int i=0;
//   while(i<n){
//     int index=a[i]-1;
//     if(a[i]!=a[index]){
//       swap(a[i],a[index]);
//     }
//     else{
//       i++;
//     }
//   }

  
// }



// int main() {
//   int n;
//  int a[]={1,2,3,3,5};
//   n=sizeof(a)/sizeof(int);
//   findmissing(a,n);
//   for (int i = 0; i < n; i++) {
//       if (a[i] != i + 1) {
//           cout << "Missing number: " << i + 1 << endl;
//           break;
//       }
//   }
// }


// vector<int> findMissingUsingHashMap(vector<int> arr, int n) {
//     unordered_map<int, int> frequency;
//     vector<int> result(2, 0);

//     // Count frequency of each number in the array
//     for (int num : arr) {
//         frequency[num]++;
//     }

//     // Find the missing number
//     for (int i = 1; i <= n; i++) {
//         if (frequency.find(i) == frequency.end()) {
//             result[1] = i; // Missing number
//         } else if (frequency[i] > 1) {
//             result[0] = i; // Repeated number
//         }
//     }

//     return result;
// }





// / question 2
// find first repeating eleemnt-donw with the help of hashing
// hme jo pehle bar element aa rha h vo return krna hai aur uska index +1 de rakha hai question m
// int hashing(int arr[],int n){
//   unordered_map<int ,int>hash;
//   for(int i=0;i<n;i++){
//     hash[arr[i]]++;
//   }
//   for(int i=0;i<n;i++){
//     if(hash[arr[i]]>1) return i+1; 
//   }
//   return -1;
// }




// int main(){
// int arr[]={1,5,2,3,5,2};
//   int n=5;
//   int b=hashing(arr,n);
//   cout<<b;
// }





// vector<int> commonelement(int a[], int b[], int c[], int n1, int n2, int n3) {
//     set<int> st; // Use a set to store common elements
//     int i = 0, j = 0, k = 0;

//     while (i < n1 && j < n2 && k < n3) {
//         if (a[i] == b[j] && b[j] == c[k]) {
//             st.insert(a[i]); // Add common element to the set
//             i++, j++, k++;
//         } else if (a[i] < b[j]) {
//             i++;
//         } else if (b[j] < c[k]) {
//             j++;
//         } else {
//             k++;
//         }
//     }

//     // Convert the set to a vector and return
//     return vector<int>(st.begin(), st.end());
// }

// int main() {
//     int a[] = {1, 2, 3, 4, 5};
//     int n1 = 5;
//     int b[] = {2, 3, 4, 5, 6, 7};
//     int n2 = 6;
//     int c[] = {5, 6, 7, 8, 9, 0};
//     int n3 = 6;

//     vector<int> result = commonelement(a, b, c, n1, n2, n3);

//     cout << "Common elements: ";
//     for (int num : result) {
//         cout << num << " ";
//     }
//     cout << endl;

//     return 0;
// }


/// question 4 wave print of a matrix


// #include <iostream>
// using namespace std;
// void wave(vector<vector<int>>v){
//   int m=v.size();
//   int n=v[0].size();
//   for(int j=0;j<n;j++){
//     if((j&1)==0){
//       for(int i=0;i<m;i++){
//         cout<<v[i][j];
//       }
//     }
//     else{
//       for(int i=m-1;i>=0;i--){
//         cout<<v[i][j];
//       }
//     }
//   }
// }



// int main() {
//   vector<vector<int>>v{
//     {1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}
//   };
//   wave(v);
  
  
// }




// }

// spiral print of a matrix;

// int main() {
//     int arr[][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};

//     int row = 3;
//     int col = 4;
//     int matrix = row * col;
//     int rowstart = 0;
//     int colstart = 0;
//     int endrow = row - 1;
//     int endcol = col - 1;
//     int count = 0;

//     while (count < matrix) {
//         for (int i = colstart; i <= endcol && count < matrix; i++) {
//             cout << arr[rowstart][i] << " ";
//             count++;
//         }
//         rowstart++;

//         for (int i = rowstart; i <= endrow && count < matrix; i++) {
//             cout << arr[i][endcol] << " ";
//             count++;
//         }
//         endcol--;

//         for (int i = endcol; i >= colstart && count < matrix; i--) {
//             cout << arr[endrow][i] << " ";
//             count++;
//         }
//         endrow--;

//         for (int i = endrow; i >= rowstart && count < matrix; i--) {
//             cout << arr[i][colstart] << " ";
//             count++;
//         }
//         colstart++;
//     }

//     return 0;
// }


// int main(){
//   vector<int>ans;
//   ans.push_back(1);
//   int num=500;
//   for(int i=1;i<=num;i++){
//     int carry=0;
//     for(int j=0;j<ans.size();j++){
//       int product=ans[j]*i+carry;
//       ans[j]=product%10;
//       carry=product/10;
//     }
//     while(carry!=0){
//       ans.push_back(carry%10);
//       carry/=10;
//     }
//   }for(int i=ans.size()-1;i>=0;i--){
//     cout<<ans[i];   // used to revsere the answer
//   }
// }

vector<int> spirallyTraverse(vector<vector<int> > &matrix) {
  int row=matrix.size();
  int col=matrix[0].size();
  int startrow=0;
  int endrow=row-1;
  int startcol=0;
  int endcol=col-1;
  int n=row*col;
  int count=0;
  vector<int>ans;
  while(count<n){
   for(int i=startcol;i<=endcol && count<n; i++){
       ans.push_back(matrix[startrow][i]);
       count++;

   }
   startrow++;

   for(int i=startrow;i<=endrow && count<n;i++){
       ans.push_back(matrix[i][endcol]);
       count++;
   }
   endcol--;

   for(int i=endcol;i>=startcol && count<n;i--){

       ans.push_back(matrix[endrow][i]);
       count++;
   }
   endrow--;

   for(int i=endrow;i>=startrow && count<n;i--){
       ans.push_back(matrix[i][startcol]);
       count++;
   }
   startcol++;
  }
   return ans;
  }


































  




