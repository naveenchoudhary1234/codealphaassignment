#include <iostream>
#include<algorithm>
#include<vector>
using namespace std;

// largest number - hme aisa inko arrange karna hai ki vo number largest number bn jayee

// bool mycomp(string a,string b){  // ye ham islie use kr rhe h tb hm 30 3 sort krnge tb ans 303 aayega aur aana chaue 330
//  string t1=a+b;  // eg 30 303
//   string t2=b+a;  // eg 3  330
//   return t1>t2;
// }
// string largest(vector<int>&nums){
//   vector<string>snums; // ye hme gievn hai int m aur hmara answer bhot bda aayega islie hm isko string m convert krlenge
//   for(auto n:nums){
//     snums.push_back(to_string(n)); // hme hmare ans ko string m store karna hai islie pehle isse convert krlia
//   }
//   sort(snums.begin(),snums.end(),mycomp);
//   if(snums[0]=="0") return "0";
//   string ans="";
//   for(auto s:snums){
//     ans+=s;
//   }
//   return ans;
// }


// int main() {
//   vector<int>nums={1,2,30,3,5};
//   string a=largest(nums);
//   cout<<a;
  
  
// }



// index of first occurence
// int firstoccurence(string s,string t){
// int n=s.size();
// int m=t.size();
//   for(int i=0;i<=n-m;i++){ // n-m tk islie chlaya hai kuki hme last tk to jana hi nhi hai 
//     for(int j=0;j<m;j++){
//       if(t[j]!=s[i+j]){  // kuki hme j ko to btadan hi dega agle charcater k sath serach krne k iyee
//         break;
//       }
//       if(j==m-1){
//         return i;
//       }
//     }
    
//   }return -1;
// }

// int main(){
//   string s="leetcode";
//   string t="leet";
//   int ans=firstoccurence(s,t);
//   cout<<ans;
// }


// remove k dublicate in string
// remove k duplicate characters in a string
bool arrlastcharsame(string &ans, char &newch, int k_1){
    int it = ans.size() - 1;
   for(int i=0;i<k_1;i++){
     if(ans[it]!=newch){
       return false;
     }
   }
    return true;
}
string removedub(string &s, int &k){
    string ans = "";
    for(int i = 0; i < s.size(); i++){
        char &newch = s[i];
        if(ans.size() < k - 1) 
            ans.push_back(newch);
        else {
            if(arrlastcharsame(ans, newch, k - 1))
                ans.pop_back();
            else
                ans.push_back(newch);
        }
    }
    return ans;
}

int main(){
    string s = "naveeeeechoudhary";
    int k = 3;
    string a = removedub(s, k);
    cout << a;
}





