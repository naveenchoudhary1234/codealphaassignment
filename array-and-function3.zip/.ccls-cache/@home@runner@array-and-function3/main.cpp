#include <iostream>
using namespace std;

//  void solve(int arr[],int size){
//   for(int i=0;i<size;i++){
//     cout<<arr[i]<<" ";
//   }
// }

// bool search(int arr[],int size,int target){
//    for(int i=0;i<size;i++){
//   if(arr[i]==target){
//     return true;
//   }
     
// }
//   return false;
// }



// int main() {
//   int arr[5]={1,2,3,4,5};
//   int size=5;
//   int target=3;
//    solve(arr,size);
//  bool ans= search(arr,size,target);
//   if(ans==1) cout<<"no is present";
//   else cout<<"no is not present";
// }


// int sum(int arr[],int n){
//   int add=0;
//   for(int i=0;i<n;i++){
//     add+=arr[i];
   
//   }   return add;
// }








