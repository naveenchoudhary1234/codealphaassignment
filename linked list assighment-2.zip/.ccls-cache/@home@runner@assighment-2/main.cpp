#include <iostream>

// merge node between zeros
// 2 zero  bich m integer ko sum krke ekm rkh dena hi
// 2 pointer bnayenge skow aur fast fast sum krta chlega jb tk fast ko 0 nhi mil jata hai
// slow ko modify krdenge
// ab slow ko aage krdenge
// last node pointer bhi rkhenge
// last node  k next ko null krdo
// slow intital ko modify krta rhegaa
ListNode* mergeNodes(ListNode* head) {
    if(head==0) return 0;
    ListNode*slow=head;
    ListNode*fast=head->next;
    ListNode*lastnode=0;
    int sum=0;
    while(fast){
        if(fast->val!=0){
            sum+=fast->val;
        }
        else{
            // fast ki value 0 hogyii
            slow->val=sum;
            lastnode=slow;
            slow=slow->next;
            sum=0;
        }
        fast=fast->next;
    }
    ListNode*temp=lastnode->next;
    // delte aur old list
    lastnode->next=NULL;
    while(temp){
        ListNode*nxt=temp->next;
        delete temp;
        temp=nxt;
    }
    return head;
}


/// odd and even linked list
// odd valo ko ek sath combine krna hau index ko
// even walo ek sath index ko
// 2 head bnalenege 
// head 1 odd k liyee head 2 ko even
// head1-next head2next
// h2-next h2-next-next
// h1=h1.next
//h2=h2.next
ListNode* oddEvenList(ListNode* head) {
    if(head==0 ||head->next==0) return head;
   ListNode*h1=head;  // for odd
   ListNode*h2=head->next; // for even
   ListNode*evenhead=h2;
   while(h2 &&h2->next){
    h1->next=h2->next;
    h2->next=h2->next->next;
    h1=h1->next;
    h2=h2->next;

   }
   // combine kardi dono
   h1->next=evenhead;
   return head;



}
    Node* divide(Node* head) {
       if (head == nullptr || head->next == nullptr) return head;

    Node *evenStart = nullptr, *evenEnd = nullptr;
    Node *oddStart = nullptr, *oddEnd = nullptr;
    Node *current = head;

    while (current != nullptr) {
        int value = current->data;

        if (value % 2 == 0) { // Even
            if (evenStart == nullptr) {
                evenStart = current;
                evenEnd = evenStart;
            } else {
                evenEnd->next = current;
                evenEnd = evenEnd->next;
            }
        } else { // Odd
            if (oddStart == nullptr) {
                oddStart = current;
                oddEnd = oddStart;
            } else {
                oddEnd->next = current;
                oddEnd = oddEnd->next;
            }
        }

        current = current->next;
    }

    // If there are no even numbers, return the odd list
    if (evenStart == nullptr) {
        return oddStart;
    }

    // If there are no odd numbers, return the even list
    if (oddStart == nullptr) {
        return evenStart;
    }

    // Link the end of even list to the start of odd list
    evenEnd->next = oddStart;
    oddEnd->next = nullptr; // Mark the end of the list

    return evenStart;
    }

// double a number in linked list
// hm isme sabse pehle recursion li help s last tk phuch kayenge
// phir prod=head-->val*2+carry;
//head->val=prod%10;
//carry=prod/10;

void solve(ListNode* head,int &carry){
if(!head) return;
solve(head->next,carry); // last tk phuch gyee hai

int prod=head->val*2+carry;
head->val=prod%10;
carry=prod/10;





}


    ListNode* doubleIt(ListNode* head) {
        int carry=0;
        solve(head,carry);
        if(carry){
            ListNode*newnode=new ListNode(carry);
            newnode->next=head;
            head=newnode;

        }
        return head;
    }


// swapping nodes in linked list
//if k=2;
// 1 2 3 4 5
// 1 4 3 2 5
nt length(ListNode*head){
 int len=0;
        ListNode*temp=head;
        while(temp!=NULL){
            len++;
            temp=temp->next;
        }
        return len;
}
    ListNode* swapNodes(ListNode* head, int k) {
       int n=length(head);
       ListNode*first=head;
        // left position
       for(int i=1;i<k;i++){
          first=first->next;
       }
        // right position
       ListNode*second=head;
       for(int i=1;i<n-k+1;i++){
        second=second->next;
       }
       int temp=first->val;
       first->val=second->val;
       second->val=temp;
       return head;
    }


// Remove zero sum consecutive nodes from linked list
// map m sb ke prefix ka sum nikallenge
// agar map m 2 value match ho gyii to use it name denge
// head ko it.next krdenge
// map vali sari entries rmove krdo
// then if(sum==0) so use remove kro 
// final ans

class Solution {
public:

void sanitizemap(ListNode*curr,unordered_map<int,ListNode*>&mp,int csum){
int temp=csum;
while(true){
    temp+=curr->val;
    if(temp==csum) break;
    mp.erase(temp);
    curr=curr->next;
}


}
    ListNode* removeZeroSumSublists(ListNode* head) {
         if (head == nullptr || (!head->next && head->val == 0)) return nullptr;
        unordered_map<int,ListNode*>mp;
        auto it=head;
        int csum=0;
        while(it){
            csum+=it->val;
            if(csum==0){
                head=it->next;
                mp.clear();
            }
            else if(mp.find(csum)!=mp.end()){
                sanitizemap(mp[csum]->next,mp,csum);
                mp[csum]->next=it->next;

            }
            else{
                mp[csum]=it;

            }
             it=it->next;
        }
        return head;
    }
};









