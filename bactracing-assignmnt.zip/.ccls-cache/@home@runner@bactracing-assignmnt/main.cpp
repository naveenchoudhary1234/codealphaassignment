#include <iostream>
#include<vector>
using namespace std;

//1 count inversion
long long int inversionCount1(long long arr[], int n) {
 int count=0;
 for(int i=0;i<n;i++){
     for(int j=i+1;j<n;j++){
         if(arr[i]>arr[j]){
             count++;
         }
     }
 }
 return count;
}

// method 2
long merge(long long arr[],int n,int start,int end,int mid){
  long long  count=0;
  int leftlength=mid-start+1;
  int rightlength=end-mid;
  int k=start;
    long long *left = new long long[leftlength];
    long long *right = new long long[rightlength];

  for(int i=0;i<leftlength;i++){
    left[i]=arr[k];
    k++;
  }
  k=mid+1;
  for(int j=0;j<rightlength;j++){
    right[j]=arr[k];
    k++;
  }
  int leftindex=0;
  int rightindex=0;
  int mainarrayindex=start;
  while(leftindex<leftlength && rightindex<rightlength){
       while (leftindex < leftlength && rightindex < rightlength) {
        if (left[leftindex] <= right[rightindex]) {
            arr[mainarrayindex] = left[leftindex];
            leftindex++;
        } else {
            arr[mainarrayindex] = right[rightindex];
            rightindex++;
            // Count the inversions
            count += (leftlength - leftindex);
        }
        mainarrayindex++;
    }
  }
  while(leftindex<leftlength){
    arr[mainarrayindex]=left[leftindex];
    leftindex++;
    mainarrayindex++;
  }
  while(rightindex<rightlength){
    arr[mainarrayindex]=right[rightindex];
    mainarrayindex++;
    rightindex++;
  }
  delete[] left;
  delete[] right;
  return count;
}





long mergesort(long long arr[],int n,int left,int right){
  long count=0;
  if(left>=right){
    return 0;
  }
  int mid=(left+right)/2;
  count+=mergesort(arr,n,left,mid);
  count+=mergesort(arr,n,mid+1,right);
  count+=merge(arr,n,left,right,mid);
  return count;
}



long long int inversionCount(long long arr[], int n) {

   return mergesort(arr,n,0,n-1);


}



/// question 2 Maximum subarray
// isme ham leftsum nikalnege right sum nikalenge kuki ya ti hmara max sum left side hoga ya phir right side hogaa ya phir mid ko cross krke hogaa
/// 3ko max lenge
int maxSubArrayHelper(vector<int>&v,int start,int end){
   if(start==end){
  return v[start];
   }


  int maxleftbordersum=0;
  int maxrightbordersum=0;

  int mid=(start+end)/2;
  int maxls=maxSubArrayHelper(v, start, mid);
  int maxrs=maxSubArrayHelper(v, mid+1, end);



  int leftbordersum=0,rightbordersum=0;
  // border cross sum
  for(int i=mid;i>=start;i--){
    leftbordersum+=v[i];
    if(leftbordersum>maxleftbordersum) maxleftbordersum=leftbordersum;
  }

  for(int i=mid+1;i<=end;i++){
    rightbordersum+=v[i];
    if(rightbordersum>maxrightbordersum) maxrightbordersum=rightbordersum;
  }
  int crossbordersum=maxleftbordersum+maxrightbordersum;
  return max(maxls,max(maxrs,crossbordersum));


  
  
}






int maxSubArray(vector<int>&nums){
  return maxSubArrayHelper(nums,0,nums.size()-1);
}

// int main(){
//   vector<int>nums={-2,1,-3,4,-1,2,1,-5,4};
//   int ans=maxSubArray(nums);
//   cout<<ans;
// }




//// Question 4
/// combination sum
// no ka sum target k equal hoga ya nhii

void combinationSumHelper(vector<int>&c,int target,vector<int>&v,vector<vector<int>>&ans,int index){
if(target==0) {
  ans.push_back(v);
return;
}
  if(target<0) return;
  
  for(int i=index;i<c.size();i++){
    v.push_back(c[i]);
    combinationSumHelper(c, target-c[i], v,ans,index);
    v.pop_back();
    
  }
}




vector<vector<int>>combinationSum(vector<int>c,int target){
vector<vector<int>>ans;  // store the ans
vector<int>v; // current index k liyee
  combinationSumHelper(c,target,v,ans,0);
  return ans;

  
}


// combination sum-II
 // no dublivate
// each candidate used only once

class Solution {
public:


void cshelper(vector<int>& c, int target, vector<int>& v, vector<vector<int>>& ans, int index) {
    if (target == 0) {
        ans.push_back(v);
        return;
    }
    if (target < 0) {
        return;
    }

    for (int i = index; i < c.size(); i++) {

        if (i > index && c[i] == c[i - 1]) continue;

        v.push_back(c[i]);
        cshelper(c, target - c[i], v, ans, i + 1);
        v.pop_back();
    }
}

vector<vector<int>> combinationSum2(vector<int>& c, int target) {
    sort(c.begin(), c.end()); 
    vector<vector<int>> ans;
    vector<int> v;

    cshelper(c, target, v, ans, 0);

    return ans;
}
};



/// Permutation 
void permuteuniquehelper(vector<int>&nums,vector<vector<int>>&ans,int index){
  if(index>=nums.size()){
      ans.push_back(nums);
      return;
  }
  for(int j=index;j<nums.size();j++){
      swap(nums[index],nums[j]);
      permuteuniquehelper(nums,ans,index+1);
      swap(nums[index],nums[j]);
  }
}


  vector<vector<int>> permuteUnique(vector<int>& nums) {
     vector<vector<int>>ans;
    permuteuniquehelper(nums,ans,0);
    set<vector<int>>st;
    for(auto e:ans){
      st.insert(e);
    }
    ans.clear();
    for(auto e:st){
      ans.push_back(e);
    }
    return ans;
  }


/// Beautiful Arrangeent
// if n=2  1 2
//         2 1   conditoon perm[i]%i=0 || i%perm[i]=0;

void counthelper(vector<int>&v,int n,int &ans,int currnum){

if(currnum==n+1){ 
  ++ans;
  return;
}

  
  for(int i=1;i<=n;i++){
    if(v[i]==0 &&(currnum%i==0 || i%currnum==0)){
      v[i]=currnum;
      counthelper(v,n,ans,currnum+1);
      v[i]=0;
    }
  }
}


int countarranegemnt(int n){
vector<int>v(n+1); // index start with 1;
  int ans=0;
  counthelper(v,n,ans,1);

  
}





   









