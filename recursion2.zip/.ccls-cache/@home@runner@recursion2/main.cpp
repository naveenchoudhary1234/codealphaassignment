#include <iostream>
#include<climits>
#include<vector>
#include<algorithm>
using namespace std;


// we are checking the array is sorted or not
// bool issorted(int arr[],int size,int index){
// if(index>=size){
//   return true;
// }
//   if(arr[index]>arr[index-1]){
//     bool ans=issorted(arr,size,index+1);
//     return ans;
//   }
//   else
//     return false;
//   }
  
// }
/////// iterative approach
// if (n == 0 || n == 1)
//   return true;

// for (int i = 1; i < n; i++)

//   // Unsorted pair found
//   if (arr[i - 1] > arr[i])
//       return false;

// // No unsorted pair found
// return true;

int binarysearch(int arr[],int s,int e,int target){
  if(s>e){
    return -1;
  }
  int mid=(e+s)/2;
  if(arr[mid]==target)  return mid;
  else if(arr[mid]<target) {s=mid+1;
  return binarysearch(arr,s,e,target);
                           }
  else{
    e=mid-1;
    return binarysearch(arr,s,e,target);

  }
  
}



int main() {
  int arr[]={10,20,30,40,50,60};
  int size=6;
//   int index=1;
//   bool issortedarray=issorted(arr,size,index);
//   if(issortedarray){
//     cout<<"true";
//   }
//   else{
//     cout<<"false";
//   }
// int s=0;
// int e=size-1;
// int target=90;
// int found=binarysearch(arr,s,e,target);
// if(found!=-1)  cout<<"true";
//   else cout<<"false";
// }



/// ** subsequences of string
// abc - isme ham kisi ko bbi remove kar skta hai par order samr rhna chaie abc a pehle aa rha h b bdme aa rha h aise
// eg abc a * * -a
// abc * b * -b
// n length k andar 2*n substring bnenge
// void substring(string str,string output,int index){
//   if(index>=str.length()){
//     // ham index 3 p aa gye hai aur hmara ans build ho gyaa hai to yhi print kra denge 
//     cout<<"->"<<output<<endl;
//     return;  // index s bdi value aate hi return lar jayege
//   }
//   char ch=str[index];
//   // exclude vala case 
//   substring(str,output,index+1);
//   // include vala case handle krenge
//   output.push_back(ch);
//   substring(str,output,index+1);
// }

// int main(){
//   string str="abc";
//   string output="";
//   int index=0;
//   substring(str,output,index);
// }

  bool isSubsequence(string s, string t) {
    int index=0;
  int sIndex = 0, tIndex = 0;

    while (sIndex < s.size() && tIndex < t.size()) {
        if (s[sIndex] == t[tIndex]) {
            sIndex++;
        }
        tIndex++;
    }

    return sIndex == s.size();
  }


/// * cut into segment
// ek eoad ko pice m kato aur phir total count karloo
/// isme ham sabse pehle x length katenge total n m s
/// isme ham sabse pehle ylength katenge total n m s


int maximiseTheCuts(int n,int x,int y,int z){

  if(n==0) return 0;
  if(n<0) return INT_MIN;
// 1 segment katna darsa rha hai
int option1=1+maximiseTheCuts(n-x,x,y,z);
int option2=1+maximiseTheCuts(n-y,x,y,z);
int option3=1+maximiseTheCuts(n-z,x,y,z);
  int totalans=max(option1,option2,option3);
  return totalans;

  
}


/// coin change
/// infinite sikke pde hai minimum no of coin kitne use kre ki sikke bn jaye
/// sikke pde h 1 2 5 ka to ham 5 5 1 kar skte hai minimum sikke use ho rhe h   
int solve(vector<int>&coins,int amount){
  if(amount==0) return 0;
   int ans=INT_MAX;
  int minimum=INT_MAX;
  for(int i=0;i<coins.size();i++){
    int coin=coins[i];
    // agar hmara amount ki value choti hai coin s to vo hoga hi nhii
    if(coin<=amount){
      int recans=solve(coins,amount-coin); // ek coin use krlia
      if(recans!=ans)  // yha agr int max mil gyaa aur 1+int max ho gyaa to code fat jayega islie hmne ye cidnition lgayi hii
      ans=1+recans;
    }
    minimum=min(minimum,ans);
  }
  return minimum;
}

int coinChange(vector<int>&coins,int amount){
  int ans=solve(coins,amount);
  if(ans==INT_MAX) return -1;
  else{
    return ans;
  }
}



/// house robber
// 2 adjacent ghar m chori nhi kar skte nhi to alarm bj jayegaa
/// chori aise karni hai kihm max money bna skee
int solve(vector<int>&nums,int size,int index){
  if(index>=size) return 0; // ghar hi nahi bacha chorikarne k liyee


  // chori karlii
  int option1=nums[index]+solve(nums,size,index+2);
  // nhi hui chorii
  int option2=0+solve(nums,size,index+1);
  int finalans=max(option1,option2);
  return finalans;
  
  
}




int rob(vector<int>&nums){
  int size=nums.size();
  int index=0;
  int ans=solve(nums,size,
  index);
  return ans;
  
}


