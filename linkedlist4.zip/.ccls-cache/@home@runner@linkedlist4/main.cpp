#include <iostream>
using namespace std;
class Node{
int data;
Node*next;

};

// second ethod to solve loop present h ya nhii
// isme hm lgaynege ki agr hmara slow aur fast mile to loop present hai varna nhii hai

//   bool hasCycle(ListNode *head) {
// ListNode*slow=head;
// ListNode*fast=head;
// while(fast!=NULL){
//   fast=fast->next;
//   if(fast!=NULL){
//     fast=fast->next;
//     slow=slow->next;
//   }
//   // check for loop
//   if(fast==slow) return true;

// return false;

//   }


// starting point of loop-
// 1 slow ko vpais head p lgao 
// 2 slow aur fast ko 1 1 step chlao agr vo dobara mil gyee to vhii starting point hai

// ListNode *detectCycle(ListNode *head) {
//     ListNode*slow=head;
//     ListNode*fast=head;
//     while(fast!=NULL){
//         fast=fast->next;
//         if(fast!=NULL){
//             fast=fast->next;
//             slow=slow->next;
//         }
//         if(slow==fast) break;
//     }
//     if(fast==NULL){
//         return NULL;
//     }
//     slow=head;
//     while(fast!=slow){
//         slow=slow->next;
//         fast=fast->next;
//     }
//     return slow;
// }



// remove a loop
// starting point k pehle vale ko null krado


// void removeloop(ListNode*head){
//     ListNode*slow=head;
//       ListNode*fast=head;
//       while(fast!=NULL){
//           fast=fast->next;
//           if(fast!=NULL){
//               fast=fast->next;
//               slow=slow->next;
//           }
//           if(slow==fast) break;
//       }
//       if(fast==NULL){
//           return NULL;
//       }
//       slow=head;
//       while(fast!=slow){
//           slow=slow->next;
//           fast=fast->next;
//       }
//       Node*startpoint=slow;
//   Node*temp=fast;
//   while(temp->next!=startpoint){
//     temp=temp->next;
//   }
//   temp->next=NULL;
  
// }


// add 1 to a linked list
// step1 reverse karo
// step 2 add karo
// step 3 reverse karo
// agar carry/!=0 h to new node creta karo
// Node* reverse(Node* head) {
//   Node* prev = NULL;
//   Node* curr = head;
//   while (curr != NULL) {
//       Node* newnode = curr->next;
//       curr->next = prev;
//       prev = curr;
//       curr = newnode;
//   }
//   return prev;
// }

// Node* addOne(Node *head) { 
//   head = reverse(head);
//   int carry = 1;
//   Node* temp = head;
//   while (temp != NULL) {
//       int totalsum = temp->data + carry;
//       int digit = totalsum % 10;  // Corrected from %0 to %10
//       carry = totalsum / 10;
//       temp->data = digit;
//       if (temp->next == NULL && carry != 0) {
//           Node* newnode = new Node(carry);
//           temp->next = newnode;
//           carry = 0;
//       }
//       temp = temp->next;
//   }
//   head = reverse(head);
//   return head;
// }




// reverse linked list in k-group
// group m reverse krna hai
// eg 1 2 3 4 5 6 7
// 2 1 4 3 6 5 7
int getlength(ListNode*head){
  int count=0;
  ListNode*temp=head;
  while(temp!=NULL){
      count++;
      temp=temp->next;

         }
         return count;
}
  ListNode* reverseKGroup(ListNode* head, int k) {
      if(head==NULL){
          return head;
      }
      if(head->next==NULL){
          return head;
      }
      ListNode*prev=NULL;
      ListNode*curr=head;
      ListNode*newnode=NULL;
      int pos=0;
      int len=getlength(head);
      if(len<k) return head;
      while(pos<k){
          newnode=curr->next;
          curr->next=prev;
          prev=curr;
          curr=newnode;
          pos++;
      }
      ListNode*recans=NULL;
      if(newnode!=NULL){
          recans=reverseKGroup(newnode,k);
          head->next=recans;
      }
      return prev;
  }


// remove dublicate in linked list
// ListNode* deleteDuplicates(ListNode* head) {
//     if(head==NULL){
//         return head;
//     }
//     if(head->next==NULL){
//         return head;
//     }
//     ListNode*temp=head;
//     while(temp!=NULL){
//         if (temp->next != NULL && temp->val == temp->next->val) {
//          ListNode*newnode=temp->next;

//          temp->next=newnode->next;
//          newnode->next=NULL;
//          delete newnode;
//         }
//         else{
//             temp=temp->next;
//         }
//     }
//     return head;
// }


