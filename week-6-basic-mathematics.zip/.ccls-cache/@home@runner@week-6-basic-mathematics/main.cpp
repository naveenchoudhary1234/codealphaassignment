#include <iostream>
#include<math.h>
#include<vector>
#include<cstring>
using namespace std;




// 1 count all prime number
int prime(int n){
  vector<int>isprime(n+1,true); // all fix to prime
  isprime[0]=isprime[1]=false; // not prime;
  int count=0;
  for(int i=2;i<=n;i++){
    if(isprime[i]){
      count++;
      int j=2*i;
      while(j<n){
        isprime[j]=false;
        j+=i;
      }
    }
  }return count;
}

int main(){
  int n=5;
  int a=prime(n);
  cout<<a;
}

//2 gcd of a number
// int main(){
//   int a=5;
//   int b=2;
//   if(a==0) return b;
//   if(b==0) return a;
//   while(a>0 && b>0){
//   if(a>b){
//     a=a-b;
//   }
//     else{
//       b=b-a;
//     }
// }
//   if(a==0) cout<<b;
//   else cout<<a;

// }


//3 lcm of two number
// int main(){
//   int a=5;
//   int b=2;
//   if(a==0) return b;
//   if(b==0) return a;
//   int original_a=a;
//   int original_b=b;
//   while(a>0 && b>0){
//   if(a>b){
//     a=a-b;
//   }
//     else{
//       b=b-a;
//     }
// }
//  int gcd=a=0?b :a;
//   cout<<(original_a*original_b)/gcd;

// }

// 4 power of a number
// int main(){
//   int a = 12;
//   int b = 21;
//   int ans = 1; // if power is 0, it always returns 1
//   while(b>0){
//     if(b & 1){
//       ans = ans * a;
//     } 
//     a = a * a;
//    b = b / 2;
//   }
//   cout << ans;
// }


// int main() {
//     char str[] = "naveen choudhary";
//     int n = strlen(str);
//     cout<<str[0];
//     for(int i=1;i<n;i++){
//    if((str[i-1])==" ") && str[i]!=" ") cout<<str[i];
//     }cout<<endl;
// }



bool isprime(int n){
    for(int i=2;i<n;i++){
        if(n%i==0) return false;
    }

    return true;
}

// int main(){
//     int n=5;
//     int ans=isprime(n);
//     cout<<ans;
// }



#include <iostream>
using namespace std;

long long power(int a, int b) {
    long long ans = 1;    // Result initialized to 1
    long long base = a;   // Use long long for base to avoid overflow

    while (b > 0) {
        // If b is odd, multiply the current base with the result
        if (b & 1) {
            ans = ans * base;
        }

        // Square the base
        base = base * base;

        // Divide b by 2
        b = b >> 1;
    }

    return ans;
}

// int main() {
//     int a = 2;
//     int b = 11;

//     cout << a << "^" << b << " = " << power(a, b) << endl;

//     return 0;
// }

