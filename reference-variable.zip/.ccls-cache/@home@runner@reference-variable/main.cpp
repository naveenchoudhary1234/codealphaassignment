#include <iostream>
using namespace std;

// int main() {
//   int n=5;
//   int &k=n;
//   int &c=n;
//   cout<<n<<endl;
//   cout<<k<<endl;
//   cout<<c<<endl;
//   k++;
//   cout<<n<<endl;
//   cout<<k<<endl;
//   cout<<c<<endl;
// }
// void increment(int&n){
//   n=n+1;
//   return;
// }
//   int main(){
//     int n=5;
//     increment(n);
//     cout<<n<<endl;
//   }


// int decrement(int &n){
//   n=n-1;
//   return n;
// }

// int main(){
//   int a=5;
//   int b=decrement(a);
//   cout<<b<<endl;
// }

void decrement(int &k){
  k=k-1;
  return;
}

int main(){
  int a=5;
  decrement(a);
  cout<<a<<endl;
}


  
