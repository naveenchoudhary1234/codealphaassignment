#include <iostream>
#include<vector>
using namespace std;
// pivot - maximum element in rotated array and sorting array

int pivot(vector<int>&num){
  int left=0;
  int right=num.size()-1;
  int n=num.size();
  while(left<=right){
    int mid=(left+right)/2;
    if(left==right) return left;
    else if(num[mid]<n && num[mid]<num[mid-1]) return mid-1; // yha agar condition nhi denege to index -1 m chla jayega
    else if(num[mid]>=0 && num[mid]>num[mid+1]) return mid;
    else if(num[left]>num[mid]) right=mid-1;   // agr hm starting index s chote hai to line b par hai to hmara ans left m exist kar raha hai  
    else{
      left=mid+1;
    }
  }return -1;
}

int binarysearch(vector<int>num,int left,int right,int target){
  while(left<=right){
    int mid=(left+right)/2;
    if(num[mid]==target)  return mid;
    else if(target>num[mid]) left=mid+1;
    else if(target<num[mid]) right=mid-1;
  }
  return -1;
}

int search(vector<int>num,int target){
  int pivotindex=pivot(num);
  int n=num.size()-1;
  int ans=-1;
  if(target>=num[0] && target<=num[pivotindex]){
    ans=binarysearch(num,0,pivotindex,target);
  }
  else{
    ans=binarysearch(num,pivotindex+1,n-1,target);
  }
  return ans;
}

int main() {
vector<int>num={12,14,16,2,4,6,8};

  int target=14;
 int a=search(num,target);
  cout<<a;
}





// searcg space m range bnani hoti hai
// int sqrt(int x){
//   int s=0;
//   int e=x;
//   int ans=-1;
//   while(s<=e){
//     long long int mid=s+(e-s)/2;
//     if(mid*mid==x) return mid;
//     else if(mid*mid<x) {
//       ans=mid; 
//       s=mid+1;
//   }
//     else{
//       e=mid-1;
//     }
    
// }return ans;
// }
// int main(){
//   int x=49;
//   int a=sqrt(x);
//   cout<<a;
    
// }



// int mains(int x){
//   int left=0;
//   int right=x;
//   int ans=-1;
//   while(left<=right){
//     int mid=(left+right)/2;
//     if(mid*mid==x) return mid;
//     else if(mid*mid<=x){
//       ans=mid;
//       left=mid+1;
      
//     }
//     else{
//       right=mid-1;
//     }
//   }return ans;
// }

// double square(int x){
//   double root=mains(x);
//   int precision=10;
//   double step=0.1;
//   for(int i=0;i<=precision;i++){
//     double j=root;
//     while(j*j<=x){
//       root=j;
//       j+=step;
//     }
//     step /= 10;
//   }
//   return root;
// }

// int main(){
//   int x=47;
//   double a=square(x);
//   cout<<a;
// }




// binary searching in 2-d array
// int searchmatrix(vector<vector<int>>matrix,int target){
//   int row=matrix.size();
//   int col=matrix[0].size();
//   int n=row*col;
//   int s=0;
//   int e=n-1;
//   while(s<=e){
//     int mid=s+(e-s)/2;
//     int i=mid/col;
//     int j=mid%col;
//     int ans=matrix[i][j]; 
//     if(ans==target) return true;
//     else if(target>ans) s=mid+1;
//     else e=mid-1;
//   }
//   return false;
// }
// int main(){
//   vector<vector<int>>matrix={{1,2,3},{4,5,6},{7,8,9}};
//   int target=7;
//   int anscheck=searchmatrix(matrix,target);
//   cout<<anscheck;
  
// }

class Solution {
public:

int pivot(vector<int>&arr){
    int left=0;
    int right=arr.size()-1;
    int n=arr.size();
    while(left<=right){
        int mid=(left+right)/2;
        if(mid<n-1 &&  arr[mid]>arr[mid+1]) return mid;
        if( mid>0 && arr[mid-1]>arr[mid]) return mid-1;
        if(arr[left]>arr[mid]){
            right=mid-1;
        }
        else{
            left=mid+1;
        }
    }
    return -1;
}

int binarysearch(vector<int>&arr,int left,int right,int target){

    while(left<=right){
        int mid=(left+right)/2;
        if(arr[mid]==target) return mid;
        else if(arr[mid]<target) left=mid+1;
        else right=mid-1;
    }
    return -1;
}


    int search(vector<int>&arr, int target) {
    int index=pivot(arr);
   int ans=-1;
   int n=arr.size();
       // If the array is not rotated
    if (index == -1) {
        return binarysearch(arr, 0, n - 1, target);
    }
   if(target<=arr[index] && target>=arr[0]){
       ans=binarysearch(arr,0,index,target);
   }
   else{
       ans=binarysearch(arr,index+1,n-1,target);
   }
   return ans;
    }
};






