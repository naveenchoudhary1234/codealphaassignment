#include <iostream>
#include<algorithm>
#include<vector>
#include<unordered_map>
using namespace std;



// third method -best method
// int main(){
// vector<int>num={0,2,1,2,1,2,0,0,1};
//   int l=0;
//   int h=num.size()-1;
//   int m=0;
//   for(int i=0;i<num.size();i++){
//     if(num[m]==0) {
//       swap(num[l],num[m]);
//       l++;
//       m++;
    
//   }
//     else if(num[m]==1){
//       m++;
//     }
//     else {
//       swap(num[h],num[m]);
//       h--;
//     }
  
// }
//   for(int i=0;i<num.size();i++){
//     cout<<num[i]<<" ";
//   }
// }


//// question 4
// int main(){
// vector<int>missing{0,1,3,4};
//   int n=missing.size();
//   int sum=0;
//   int totalsum=0;
//   for(int i=0;i<n;i++){
//     sum+=missing[i];
//   }
//     totalsum+=(n*(n+1))/2;
  
//   cout<<totalsum-sum;
//   }

/// question 5
// int main(){
// int arr[5]={1,-1,-2,-3,-4};
// int n=5;
// int j=0;
//   for(int i=0;i<n;i++){
//     if(arr[i]<j){
//       swap(arr[i],arr[j]);
//       j++;
//     }
//   }
//   for(int i=0;i<n;i++){
//     cout<<arr[i]<<" ";
//   }
  
  
// }

// question 6

int dublicate(vector<int>&num){
vector<int>result;
  unordered_map<int,int>count;
  for(int i=0;i<num.size();i++){
    count[num[i]]++;
    if(count[num[i]]==2){
      result.push_back(num[i]);
    }
  }
  
}
// int dublicate(vector<int>num){
 

//   sort(num.begin(),num.end());
//   for(int i=0;i<num.size()-1;i++){
//     if(num[i]==num[i+1]) return num[i];
//   }return -1;
// // while(num[0]!=num[num[0]]){
// //   swap(num[0],num[num[0]]);
// // }return num[0];
  
// }
// int main(){
//    vector<int>num={3,1,3,4,2};
//   int a=dublicate(num);
//   cout<<a;
// }


// bool name(vector<int>arr,int size){
//   int sum=9;
//   int left=0;
//   int right=size-1;
//   sort(arr.begin(),arr.end());
//   while(left<=right){
//     int calcsum=arr[left]+arr[right];
//     if(calcsum==sum) return true;
//     else if(calcsum>sum) right--;
//     else if(calcsum<sum) left++;
//   }
//   return false;
// }
// int main(){
//   vector<int>arr={1,2,3,4,5};
//   int size=5;
//   bool a=name(arr,size);
//   cout<<a;
// }


// int pivotIndex(vector<int>& nums) {
//     int n = nums.size();
//     if (n == 0) return -1; 

//     vector<int> lsum(n, 0);
//     vector<int> rsum(n, 0);


//     for (int i = 1; i < n; i++) {
//         lsum[i] = lsum[i - 1] + nums[i - 1];
//     }


//     for (int i = n - 2; i >= 0; i--) {
//         rsum[i] = rsum[i + 1] + nums[i + 1];
//     }

//     for (int i = 0; i < n; i++) {
//         if (lsum[i] == rsum[i]) {
//             return i;
//         }
//     }
//     return -1; 
// }


// vector<int> twoSum(vector<int>& nums, int target) {
//     vector<int>result;
//     for(int i=0;i<nums.size();i++){
//         for(int j=i+1;j<nums.size();j++){
//             if(nums[i]+nums[j]==target){
//                 result.push_back(i);
//                 result.push_back(j);
//                 return result;
//             }
//         }
//     }return result;
// }

// int main() {
//     vector<int> arr = {1, 2, 3, 4, 5};
//     int target = 5;
//     vector<int> indices = twoSum(arr, target);
//     if (indices.size() == 2) {
//         cout << "Indices: " << indices[0] << ", " << indices[1] << endl;
//     } else {
//         cout << "No two elements found that add up to target." << endl;
//     }

//     return 0;
// }










  







