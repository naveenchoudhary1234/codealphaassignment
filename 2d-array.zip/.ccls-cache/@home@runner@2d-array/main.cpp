#include <iostream>
#include<algorithm>
#include<vector>
using namespace std;
// column vise access
// int main() {
//     int arr[2][4]={{10,20,30,40},{50,60,70,80}};

//    for(int i=0;i<2;i++){
//      for(int j=0;j<4;j++){
//       cout<<arr[i][j];


//      }cout<<endl;
//    }
// }

// int main(){
//   int arr[3][3];
//   int row=3;
//   int col=3;
//   for(int i=0;i<row;i++){
//     for(int j=0;j<col;j++){
//       cin>>arr[i][j];
//     }
//   }
//   for(int i=0;i<row;i++){
//     for(int j=0;j<col;j++){
//       cout<<arr[i][j];
//     }
//   }
  
// }

// int main(){
//   int arr[][3]={{1,2,3},{4,5,6},{7,8,9}};
//   for(int i=0;i<3;i++){
//     for(int j=2;j>=i;j--){
//     swap(arr[i][j],arr[j][i]);
//     }
//   }
//   for(int i=0;i<3;i++){
//     for(int j=0;j<3;j++){
//       cout<<arr[i][j]<<" ";
//     }cout<<endl;
//   }
// }

// int main() {
// vector<vector<int>>arr={{1,2,3},{4,5,6},{7,8,9}};
// int n=arr.size();
// for(int i=0;i<n;i++){
//     for(int j=i+1;j<n;j++){
//         swap(arr[i][j],arr[j][i]);
//     }
// }
// for(int i=0;i<n;i++){
//     reverse(arr[i].begin(),arr[i].end());
// }
// for(int i=0;i<n;i++){
//     for(int j=0;j<n;j++){
//         cout<<arr[i][j]<<" ";
//     }cout<<endl;
// }


// }

int main() {
vector<int>arr={{1,2,3},{4,5,6},{7,8,9}};
int row=3;
int col=3;
for(int i=0;i<3;i++){
    for(int j=i+1;j<3;j++){
        swap(arr[i][j],arr[j][i]);
    }
}
for(int i=0;i<3;i++){
    reverse(arr[i].begin(),arr[i].end());
}
for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
        cout<<arr[i][j]<<" ";
    }cout<<endl;
}

}
