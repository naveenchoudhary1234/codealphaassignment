#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;


bool mycomp(int &a ,int &b){
  return a>b; // sort in decreasing order
}

int main() {
  vector<int>v={1,2,3,4,5};
  sort(v.begin(),v.end(),mycomp);
  for(int i=0;i<v.size();i++){
    cout<<v[i];
  }
  
}

// 1 index k hisab s sorting
// bool mycomporator(vector<int>&a,vector<int>&b){
//   return a[1]>b[1];
// }

// int main() {
//     vector<vector<int>> v = {{1,41},{0,22},{2,33},{4,44},{0,6}};
//     sort(v.begin(), v.end(), mycomporator);
//     for(int i = 0; i < v.size(); i++) {
//         for(int j = 0; j < v[i].size(); j++) {
//             cout << v[i][j] << " ";
//         }
//         cout << endl;
//     }
//     return 0;
// }