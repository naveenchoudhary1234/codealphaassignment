#include <iostream>
#include<stack>
#include<vector>
using namespace std;


// pair 
// pair<int,int>p=make_pair();



class MinStack {
public:
vector<pair<int,int>>st;
    MinStack() {


    }

    void push(int val) {
        if(st.empty()){
            // sbse pehle pehla element dal rhe haii
            pair<int,int>p;
            p.first=val;
            p.second=val;
            st.push_back(p);
         }
         else{
            pair<int,int>p;
            p.first=val;
            int puranaMin=st.back().second;
            p.second=min(puranaMin,val);
            st.push_back(p);
         }
    }

    void pop() {
         st.pop_back();
    }

    int top() {
        pair<int,int>rightmostpair=st.back();
        return rightmostpair.first;
    }

    int getMin() {
        pair<int,int>rightmostpair=st.back();
        return rightmostpair.second;
    }
};


/// *next smaller eleemnt
// eg 8 4 6 2 3
// hme uske aage m s small er elemtn nikalna hai
// 4 2 2 -1 -1
// ham right to left check krenge
// last k liye hmesa -1 aayega
class Solution {
public:
    vector<int> finalPrices(vector<int>& prices) {

        int n=prices.size();
      vector<int>ans(n);
        stack<int>st;
        st.push(-1);
        for(int i=n-1;i>=0;i--){
            int curr=prices[i];
            while(st.top()>=curr){
                st.pop();
            }
             ans[i]=st.top();
            st.push(curr);
        }
        return ans;
    }
};


/// prev smaller element
class Solution1 {
public:
    vector<int> finalPrices(vector<int>& prices) {

        int n=prices.size();
      vector<int>ans(n);
        stack<int>st;
        st.push(-1);
        for(int i=0;i<n-1;i++){
            int curr=prices[i];
            while(st.top()>=curr){
                st.pop();
            }
             ans[i]=st.top();
            st.push(curr);
        }
        return ans;
    }
};

// Largest area in ahistogram
class Solution {
public:
// hme height aur width nokalni hai height to samr rhegii par width hm aage aur piche vale age barababar or sbde hai to hme aage bdna hogaa to hm ye use kr rhe h aur hme index vise chlna h to stack k andar hm index push kra rha hai
    vector<int>nextelement(vector<int>&arr) {
        vector<int>ans(arr.size(),arr.size());
        stack<int>st;
        st.push(-1);
        for(int i=arr.size()-1;i>=0;i--){
            int curr=arr[i];
            while(st.top()!=-1 &&arr[st.top()]>=curr){
                st.pop();
            }
             ans[i]=st.top();
            st.push(i); // hme stack k andar index push krne hai
        }
        return ans;
    }


/// prev smaller element

    vector<int>prevelement(vector<int>&arr) {
        vector<int>ans(arr.size(),-1);
        stack<int>st;
        st.push(-1);
        for(int i=0;i<arr.size();i++){
            int curr=arr[i];
            while(st.top()!=-1 && arr[st.top()]>=curr){
                st.pop();
            }
             ans[i]=st.top();
            st.push(i);
        }
        return ans;
    }


int largestRectangleArea(vector<int>& heights) {
vector<int>next=nextelement(heights);
for(int i=0;i<next.size();i++){
    if(next[i]==-1){
        next[i]=heights.size();
    }
}
vector<int>prev=prevelement(heights);

vector<int>area(next.size()); // ans stoe krlenege
for(int i=0;i<next.size();i++){
    int width=next[i]-prev[i]-1;
    int length=heights[i];
    int currarea=width*length;
    area[i]=currarea;
}
int maxi=INT_MIN;
for(int i=0;i<area.size();i++){
    maxi=max(maxi,area[i]);
}
return maxi;
 }
};


