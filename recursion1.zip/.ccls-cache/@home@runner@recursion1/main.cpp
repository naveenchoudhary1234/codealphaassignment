#include <iostream>
using namespace std;

int factorial(int n){
  if(n==0 || n==1) return 1;
  int ans=n*factorial(n-1);
  return ans;
}

int sum(int n){
  if(n<0) return false;
  int ans=n+sum(n-1);
  return ans;
}
void counting(int n){
  if(n==1) {
    cout<<1<<endl; return ;}
  cout<<n<<" ";
  counting(n-1);  // tail recursion
}

void simplecounting(int n){
  if(n==1){ cout<<1<<" "; return ;}
  simplecounting(n-1);
  cout<<n<<" "<<endl;  // head recursion
}

// int power(int n){
//   if(n==0) return 1;
//   int ans=2*power(n-1);
//   return ans;
// }

// int fibonicci(int n){
//   if(n==0) return 0;
//   if(n==1) return 1;
//   int ans=fibonicci(n-1)+fibonicci(n-2);
//   return ans;
// }



int main() {

int n=5;
  // int a=factorial(n);
  // int b=sum(n);
  counting(n);
  simplecounting(n);
  // int c=power(n);
  // cout<<c<<endl;

  // cout<<b<<endl;
  // cout<<a<<endl;

  // cout<<fibonicci(7);
  
}

