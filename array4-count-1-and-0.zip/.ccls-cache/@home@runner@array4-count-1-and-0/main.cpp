#include <iostream>
#include<algorithm>
#include<cctype>
using namespace std;

// int main() {
//   int arr[5]={1,0,0,1,1};
//   int onecount=0;
//   int zerocount=0;
//   for(int i=0;i<5;i++){
//     if(arr[i]==1){
//       onecount++;
//     }
//     else zerocount++;
//   }
//   cout<<onecount<<endl;
//   cout<<zerocount;
// }

// int main(){
// int a[9]={1,2,3,4,5,6,7,8,9};
//   int min=a[0];
//   for(int i=0;i<9;i++){
//     if(a[i]<min)
//     {min=a[i];}
    
//   }
//   cout<<min;
// }

// int main(){
// int a[9]={1,2,3,4,5,6,7,8,9};
//   int max=a[0];
//   for(int i=0;i<9;i++){
//     if(a[i]>max)
//     {max=a[i];}

//   }
//   cout<<max;
// }

// void reverse(int arr[],int size){
//   int left=0;
//   int right=size-1; 
//   while(left<=right){
//     swap(arr[left],arr[right]);
//     left++;
//     right--;
//   }

// for(int i=0;i<size;i++){
//   cout<<arr[i]<<" ";
// }
// }

// int main(){
// int arr[8]={1,2,3,4,5,6,7,8};
//   int size=6;
//   reverse(arr,size);

  

  
// }

// void reverse(int arr[],int size){
//   int left=0;
//   int right=size-1; 
//   while(left<=right){
//     if(left==right){
//       cout<<arr[left];
//       break;
//     }
//     else{
//     cout<<arr[left]<<" ";
//     cout<<arr[right]<<" ";
//     left++;
//     right--;
//   }
//   }
// }




// int main(){
// int arr[9]={1,2,3,4,5,6,7,8,9};
//   int size=9;
//   reverse(arr,size);
// }
   // void reverseInGroups(vector<long long int> &arr, int k) {
   // int n = arr.size();
   //  for (int i = 0; i < n; i += k) {
   //      int left = i;
   //      // The end index for the current group, it shouldn't exceed n - 1
   //      int right = min(i + k - 1, n - 1);

   //      // Reverse the elements in the current group
   //      while (left < right) {
   //          swap(arr[left], arr[right]);
   //          left++;
   //          right--;
   //      }
   //  }
   //  }


#include <iostream>
#include <algorithm>
using namespace std;

int findKthMax(int arr[], int size, int k) {
    sort(arr, arr + size, greater<int>()); // greater<int> - reverse 
    return arr[k - 1];
}

int main() {
    int arr[5] = {1, 2, 3, 4, 5};
    int k = 2;
    int kthMax = findKthMax(arr, 5, k);
    cout << "The " << k << "th maximum element is: " << kthMax << endl;
    return 0;
}



  

  








