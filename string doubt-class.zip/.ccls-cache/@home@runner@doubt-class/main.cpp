#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

// maximum occurence which is greater then n/2  always exist at middle

int maximumoccurence(vector<int>nums,int n) {
  sort(nums.begin(),nums.end());
 return nums[(0+n-1)/2];
  
  
}

// int main(){
//    vector<int>nums={1,3,3};
//   int n=nums.size();
//   int ans=maximumoccurence(nums,n);
//   cout<<ans;
// }


// lower bound in binary search
// lower-bound(vector.begin(),vector.end(),2); gives exact index of first occurence
// upper-bound(vector.begin(),vector.end(),2); gives +1exact index of last occurence

// int main(){
//   vector<int>v={1,1,2,2,2,2,3,4};
//   auto it=lower_bound(v.begin(), v.end(),2);
//   cout<<*it<<endl;//bcoz array print the addresss so we want the value;
//   cout<<"index at "<<it-v.begin()<<endl;
//   auto it1=upper_bound(v.begin(), v.end(),2);
//   cout<<*it1<<endl;
//   cout<<"index at "<<it1-v.begin()<<endl;
// }


void capit(string &str)
{
  int i=0;
    if(isalpha(str[0])){
    str[i]=str[i]-'a'+'A';
  }
  while(i<str.length() ){
     if(str[i-1]==' ' && i<str.length() && i>0){
      str[i]=str[i]-'a'+'A';
    }
    i++;
  }
}
int main() {
string str="naveen choudhary";
capit(str);
cout<<str;
}