#include <iostream>
using namespace std;

// int main() {
//   int a[5];
//   for(int i=0;i<5;i++){
//     cin>>a[i];
//   }
//   int sum=0;
//   for(int i=0;i<5;i++){
//     sum=sum+a[i];
   
//   }
//    cout<<sum;
  
// }

// int main(){
// int search[5];
//   int n;
//   for(int i=0;i<5;i++){
//     cin>>search[i];
//   }
//   cin>>n;
//   bool target=0;
//   for(int i=0;i<5;i++){
//     if(search[i]==n) 
//     {target=1;
//     break;}
    

//   }
//   if(target==1) cout<<"no is present";
//   else cout<<"no is not present";
// }




