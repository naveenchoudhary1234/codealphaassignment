#include <iostream>
using namespace std;

// array aur vector k andar memory leak hota hai
// linked list-non contiguous memory location
// it is collection of nodes
// node-pehle uska data store krnege aur phir suka address store krenge
// linked-list - jab null nhi mil jata hai tb tk chlte rhoo
// it is hindi
// Types 1 singly  aage aage kr rha h
//  2 doubly  aage bhi point kr rha h aur piche bhii
// 3 circularly
// 4 circular dubly 








class Node{
public:
int data;
Node*next;

Node(){
  this->next=NULL;
}

Node(int data){
  this->data=data;
  this->next=NULL;
}
} ;

// starting point-head
// ending point-tale
// ham yha p knhi bhii original pointer ka use nhi krengee
// ham ek nya  pointer bnayenge
void printall(Node *head){
  Node*temp=head;

  while(temp!=NULL){
    cout<<temp->data<<" ";
    
    temp=temp->next;

  }cout<<endl;
}

int getlength(Node*head){
  int length=0;
  Node *temp=head;
  while(temp!=NULL){
    length++;
    temp=temp->next;
  }
  return length;
}

// insertion
void insertathead(Node *&head,Node*&tail,int data){
  if(head==NULL){
    // empty all
    // strp 1 create new node
    Node *newNode=new Node(data);
    head=newNode;
    tail=newNode;
  }
  else{
  Node*newNode=new Node(data);
  newNode->next=head;
  head=newNode;
  
}
}

void insertattail(Node *&head,Node*&tail,int data){
if(head==NULL){
  Node *newnode=new Node(data);
  head=newnode;
  tail=newnode;
}


  else{
    Node *newnode=new Node(data);
    tail->next=newnode;
    tail=newnode;
  }
  
}


void insertatanyposition(Node *&head,Node*&tail,int data,int position){

int length=getlength(head);
 
  if(position<=1){
    insertathead(head,tail,data);
  }
  if(position>length){  // yha glti  kri thii
    insertattail(head,tail,data);
  }

  // insert at middle of the list
  // create node
  else{
  Node *newnode=new Node(data);
  Node*prev=NULL;
  Node*curr=head;
  while(position!=1){
    prev=curr;
    curr=curr->next;
    position--;
  }
  prev->next=newnode;
  newnode->next=curr;
  
  
}
}


int main() {

  Node*head=NULL;
  Node*tail=NULL;
  insertathead(head,tail,20);
  insertathead(head,tail,30);
  insertathead(head,tail,40);
  insertathead(head,tail,50);
  insertattail(head,tail,60);
  insertatanyposition(head,tail,2000,200);
  printall(head);
  
//   Node *first=new Node(10);
//   Node *second=new Node(20);
//   Node *third=new Node(30);
//   Node *fourth=new Node(40);
// // linked list create
//   first->next=second;
//   second->next=third;
//   third->next=fourth;
//   Node *head=first;
//   Node *tail=fourth;
//   printall(head);
//   int a=getlength(head);
//   cout<<a<<endl;
//   insertathead(head,tail,500);
//    printall(head);
//   insertattail(head,tail,600);
//   printall(head);

  
  
}

#include <iostream>
using namespace std;

class Node{
public:
int data;
Node*next;

Node(){
  this->next=NULL;
}
Node(int data){
  this->data=data;
  this->next=NULL;
}

};

void printall(Node*head){
  Node*temp=head;
  while(temp!=NULL){
    cout<<temp->data<<" ";
    temp=temp->next;
  }cout<<endl;
}

int getlength(Node*head){
  Node*temp=head;
  int count=0;
  while(head!=NULL){
    count++;
    temp=temp->next;
  }
  return count;
}

void deleteNode(Node*&head,Node*&tail,int position){
if(head==NULL){
  cout<<"cannot delete";
  return;
}
  if(head==tail){
    Node*temp=head;
    delete temp;
    head=NULL;
    tail=NULL;
  }

 // delete from head
  if(position==1){
    Node*temp=head;
    head=head->next;
    temp->next=NULL;
    delete temp;
  }


  // delete from tail
    // prev val ko last second element p le aayenge perv->next=null krdo
  else if(position==getlength(head)){
  Node*prev=head;
    while(prev->next!=tail){
      prev=prev->next;
    }
    prev->next=NULL;
    delete tail;
    tail=prev;


  }
// at any position
  else{
  Node*prev=NULL;
  Node*curr=head;
    while(position!=1){
      position--;
      prev=curr;
      curr=curr->next;
    }
    prev->next=curr->next;
    curr->next=NULL;
    delete curr;


  }
}






int main() {

Node*first=new Node(10);
  Node*second=new Node(20);
  Node*third=new Node(30);
  Node*fouth=new Node(40);
  first->next=second;
  second->next=third;
  third->next=fouth;
  Node*head=first;
  Node*tail=fouth;
  printall(head);

  deleteNode(head,tail,1);
  printall(head);



}




// Doubly Linked list
// 1 division -prev
// 2-data
// 3 next

class Node{
    public:
    Node*next;
    int data;

    Node(){
        this->next=NULL;
    }
    Node(int data){
        this->data=data;
        this->next=NULL;
    }
};

    void printall(Node*&head){
        Node*temp=head;
        while(temp!=NULL){
            cout<<temp->data<<" ";
            temp=temp->next;
        }
    }

    int getlength(Node*&head){
        Node*temp=head;
        int count=0;
        while(temp){
            count++;
            temp=temp->next;
        }
        return count;
    }

    void insertionathead(Node*&head,int data){
        if(head==NULL){
            Node*newnode=new Node(data);
            head=newnode;
        }
        else{
            Node*newnode=new Node(data);
            newnode->next=head;
            head=newnode;
            }
    }

  void insertionattail(Node*&head,int data){
      if(head==NULL){
          Node*newnode=new Node(data);
            head=newnode;
      }
      Node*temp=head;
      while(temp->next!=NULL){
          temp=temp->next;
      }
      Node*newnode=new Node(data);
      temp->next=newnode;

  }

  void insertatanypos(Node*&head,int data,int pos){
        if(head==NULL){
            Node*newnode=new Node(data);
            head=newnode;
        }
      Node*prev=NULL;
      Node*curr=head;
      while(pos!=1){
          pos--;
          prev=curr;
          curr=curr->next;

      }
      Node*newnode=new Node(data);
      prev->next=newnode;
      newnode->next=curr;
  }

void deleteatanypos(Node*&head,int pos){
    int len=getlength(head);
    if(head==NULL){
        return;
    }
    if(pos==1){
        Node*temp=head;
        head=head->next;
        temp->next=NULL;
        delete temp;
    }

    else if(pos==len){
        Node*temp=head;
        while(temp->next->next!=NULL){
            temp=temp->next;
        }
        temp->next=NULL;

    }

    else{
        Node*prev=NULL;
        Node*curr=head;
        while(pos!=1){
            pos--;
            prev=curr;
            curr=curr->next;
        }
        prev->next=curr->next;
        curr->next=NULL;
    }

}

int main() {
    Node*head=NULL;
insertionathead(head,50);
insertionathead(head,60);
insertionathead(head,70);
insertionattail(head,20);
insertatanypos(head,100,5);
deleteatanypos(head,2);
printall(head);


}