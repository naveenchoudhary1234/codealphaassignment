#include <iostream>
#include<queue>

// first non repeating character in a stream
// eg ababc
// at t=0 a->a
// t=1 ab a
// t=2 aba b
// t=3 abab #
// t=4 ababc c
// we use frequnecy table
// char nikalo count kro queue m push krdo tarck krnr k liyee
string FirstNonRepeating(string str){
    queue<char>q;
    int freq[26]={0};
      string ans;
    for(int i=0;i<str.length();i++){
        // first we find the character
        char ch=str[i];

        // now we have to update it to freq table
        freq[ch-'a']++; // 0 index ko a k sath b ko 1 k sath

        q.push(ch);


        //answer
        while(!q.empty()){
            char front=q.front();
            if(freq[front-'a']>1){
                // so it is not answer
                q.pop();
            }
            else{
                //==1 vala case yhi ans hai
                ans+=front;
                break;
            }
        }

        // kli answer nhi nikla to ans # hai
        if(q.empty()){
        ans+='#';}

    }

    return ans;
}


/// *GAS STATION OR PETROL PUMP
// unlimited tank
// ham kisi gas stattions start krte hai aur vhi aapis aajaye to uska index ans mana jayega 
// ham sbse pehle 0 inde x start krenge + krte chlenge to fulfil nhi ho re hai
// to ham direct 3 index p ja skte hai kuki agr 0 k sath vo fulfil nhi ho rhi to uske bin to possible nhihai
// hm isme two poiter lgaynge
// 1 front 2 rear when front==rear it is true
// aur jb hmari condition break hojaye use aage front=rear+1; rear=front
int canCompleteCircuit(vector<int>& gas, vector<int>& cost) {
    int totaldiff=0;
    int n=gas.size();
    int fuel=0;
    int index=0;
    for(int i=0;i<n;i++){
        int diff=gas[i]-cost[i];
        totaldiff+=diff;
        fuel+=diff;

        if(fuel<0){
            index=i+1;
            fuel=0;
        }
    }
    return (totaldiff<0)?-1:index;

}

//// sliding window maximum
class Solution {
public:
    vector<int> maxSlidingWindow(vector<int>& nums, int k) {
        vector<int>ans;
        deque<int>dq;

        for(int i=0;i<k;i++){
            int element=nums[i];
            while(!dq.empty() && element>nums[dq.back()]){
                dq.pop_back();
            }
            dq.push_back(i);
        }

        for(int i=k;i<nums.size();i++){
            ans.push_back(nums[dq.front()]);

            // removal
            if(!dq.empty() && i-dq.front()>=k){
              dq.pop_front();
            }
              int element=nums[i];
                while(!dq.empty() && element>nums[dq.back()]){
                dq.pop_back();
            }
            dq.push_back(i);
        }
        // last window ka ans dekh lete hi
        ans.push_back(nums[dq.front()]);
        return ans;
    }
};


