#include <iostream>
#include<algorithm>
using namespace std;

// xor of the element jo common nhi hai array m
// int main() {
//   int arr[5]={1,5,5,4,4};
//   int flag=0;
//   for(int i=0;i<5;i++){
//    flag=flag^arr[i];
//     }
// cout<<flag;

// }






// int main(){
//     int arr[]={1,1,0,0,1,1,1,1};
//     int size=8;
//     sort(arr,arr+size);
//     for(int i=0;i<size;i++){
//         cout<<arr[i]<<endl;
//     }// 
// }

// int main(){
//     int arr[]={1,2,3,4,5,6};
//     int size=6;
//     int temp=arr[size-1];
//     int i;
//     for(i=size-1;i>=1;i--){
//         arr[i]=arr[i-1];

//     }
//     arr[0]=temp;
//     for(int i=0;i<size;i++){
//         cout<<arr[i]<<" ";
//     }
//     cout<<endl;


// }

// int main(){
//     int arr[]={1,2,3,4,5};
//     int n=5;
//     int temp=arr[0];
//     for(int i=0;i<n;i++){
//         arr[i]=arr[i+1];
//     }
//     arr[n-1]=temp;
//     for(int i=0;i<n;i++){
//         cout<<arr[i]<<endl;
//     }

// }
// int main(){
// int arr[]={1,2,3,4,5};
// int n=5;
// int temp=arr[0];
// for(int i=0;i<n;i++){
//   arr[i]=arr[i+1];
// }arr[n-1]=temp;
//   for(int i=0;i<n;i++){
//           cout<<arr[i]<<endl;
//       }

// }

// int main(){
//     int arr[5]={1,2,3,4,5};
//     int k=3;
//     int n=5;
//     int ans[n];
//     for(int i=0;i<n;i++){
//         int prod=(i+k)%n;
//         ans[prod]=arr[i];
//     }
//     for(int i=0;i<n;i++){
//         cout<<ans[i]<<" ";
//     }
// }









