#include <iostream>
using namespace std;

// yha hum int arr[] bhi likh sakte hai
void solve(int *arr,int size){
//   cout<<"size of array is 8 but in int main it is 20"<<sizeof(arr);
// }
  cout<<arr<<endl;
  cout<<&arr<<endl;
}
// int main() {
//   int arr[5]={1,2,3,4,5};
//   int *ptr=&arr;  // error in code

//   // pointer to an array
//   int (*ptr)[5]=&arr;
//   cout<<*ptr;

// }


//   // pointer as a function




//     int arr[]={1,2,3,4,5};
//     solve(arr,5);
//   cout<<arr<<endl;
//   cout<<&arr<<endl;
  
  
  
// }

// important question
// int main m array={1,2,3} cout arr-104 base adrees &arr-104
// void main cout arr-104 &arr- 104 vale dabbe ka address print hogaa

// void solve(int *arr){
//   *arr=*arr+1; // it increase at index 0
// }





// int main(){
//   int arr[]={1,2,3,4,5};
//   solve(arr);
//   for(int i=0;i<5;i++){
//     cout<<arr[i];
//   }
// }


/// pointer to pointer

// int main(){
//   int a=5;
//   int *ptr=&a;
//   int **ptr1=&ptr;
//   int ***pt3=&ptr1;
// }



// how to get access pointer to fucntion

void display(){
  cout<<"hello world";
}

int main(){

  void (*disp)()=&display;
  cout<<&disp;
  (*disp)();
  
}