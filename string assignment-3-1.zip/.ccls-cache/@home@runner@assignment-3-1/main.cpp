#include <iostream>
#include<vector>
using namespace std;

// integer to roman
string toroman(int num){
 string romansymbols[]= {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

 int values[]={1000,900,500,400,100,90,50,40,10,9,5,4,1};
  string ans="";
  for(int i=0;i<13;i++){
    while(num>=values[i]){ // hmara no value s bda hone tk dekhenge
      ans+=romansymbols[i]; // usko ans vali string m dal denge
      num-=values[i]; // ab value ko ghtana pdega kuki 1 no ka roman mil gyaa hai
    }
  }return ans;
}

// zig zag conversion -abcdefghij
//a   e       i
//b d   f   h   j  ans - aeibdfhjcg
//c       g

string convert(string s,int numrows){
  if(numrows==1) return s;
  vector<string>zigzag(numrows);
  int i=0;
  int row=0;
  bool direction=1; // starting top to bottom
  while(true){  // infinite loop chlayega
    if(direction){
      while(row<numrows && i<s.size()){
        zigzag[row].push_back(s[i++]);
        row++;
      }
      row=numrows-2; // ab ham row no 1 p chle jayenge isse
    }
    else{
      while(row>=0 && i<s.size()){
        zigzag[row].push_back(s[i++]);
        row--;
      }
      row=1;
    }
    if(i>=s.size()) break;
    direction=!direction;
  }
  string ans="";
  for(int i=0;i<zigzag.size();i++){
    ans+=zigzag[i];
  }
  return ans;
}




int main() {
 // int num=10;
 //  string a=toroman(num);
 //  cout<<a<<" ";
  string s="abcdefghij";
  int numrows=3;
  string a=convert(s,numrows);
  cout<<a;
}