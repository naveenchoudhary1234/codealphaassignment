#include <iostream>
#include<algorithm>
#include<math.h>
#include<vector>
using namespace std;


///* climbing stairs
// we can only jump 1 or 2 step for going to our target
int climbstair(int n){
  if(n==1) return 1;
  if(n==2) return 2;
  int ans=climbstair(n-1)+climbstair(n-2);
  return ans;
}

//// * array in recursion
void printarray(int arr[],int size,int index){
  if(index>=size) return;
  cout<<arr[index]<<" ";
  printarray(arr,size,index+1);
}

void printarray(int arr[],int size,int index){
  if(index>=size) return ;
  
  printarray(arr,size,index+1);
}

///* minimum no in array
void minimum(int arr[],int size,int index,int &mini){
  if(index>=size) {return;}
   mini=min(mini,arr[index]);
    minimum(arr,size,index+1,mini); 
  cout<<mini;
  
  
  
}



////*search in array
bool search(int arr[],int size,int index,int target){
  if(index>=size) return false;
  if(arr[index]==target) return true;
  bool ans=search(arr,size,index+1,target);
    
  return ans;
  
}



int main() {
  int n=2;
  int a=climbstair(n);
  cout<<a<<endl;
  int arr[]={1,2,3,4,5};
  int size=5;
  int index=0;
  int target=4;
  printarray(arr,size,index);
  bool check=search(arr,size,index,target);
  if(check) cout<<"present";
  else cout<<"nooo";
  
}



// void solve(int arr[],int size,int index,vector<int>&ans){
// if(index>=size) return ;
// if(arr[index]%2==0) ans.push_back(arr[index]);
//   solve(arr,size,index+1,ans);
 
  
// }


// void multiply(int arr[],int size,int index){
//   if(index>=size) return;
//   multiply(arr,size,index+1);
// }

// int main(){
//   int arr[]={1,2,3,4,5,6};
//   int size=6;
//   int index=0;
//   vector<int>ans;
//   solve(arr,size,index,ans);
//   for(auto num:ans){
//      cout<<num<<" ";
//    }
//   multiply(arr,size,index);
//   for(int i=0;i<size;i++){
//     cout<<2*arr[i]<<" ";
//   }
// }





// int leftoccurence(int arr[], int size, int left, int right, int target) {
//     if (left > right) return -1;

//     int mid = left + (right - left) / 2;

//     if (arr[mid] == target) {
//         int found = leftoccurence(arr, size, left, mid - 1, target);
//         if (found != -1) return found;  // Return the leftmost occurrence found in the left subarray
//         return mid;  // This is the leftmost occurrence in the current subarray
//     } else if (arr[mid] < target) {
//         return leftoccurence(arr, size, mid + 1, right, target);
//     } else {
//         return leftoccurence(arr, size, left, mid - 1, target);
//     }
// }

// int rightoccurence(int arr[], int size, int left, int right, int target) {
//     if (left > right) return -1;

//     int mid = left + (right - left) / 2;

//     if (arr[mid] == target) {
//         int found = rightoccurence(arr, size, mid + 1, right, target);
//         if (found != -1) return found;  // Return the rightmost occurrence found in the right subarray
//         return mid;  // This is the rightmost occurrence in the current subarray
//     } else if (arr[mid] < target) {
//         return rightoccurence(arr, size, mid + 1, right, target);
//     } else {
//         return rightoccurence(arr, size, left, mid - 1, target);
//     }
// }

// int alloccurence(int arr[], int size, int left, int right, int target) {
//     int leftIndex = leftoccurence(arr, size, left, right, target);
//     int rightIndex = rightoccurence(arr, size, left, right, target);
//     if (leftIndex == -1 || rightIndex == -1)
//         return 0;
//     return rightIndex - leftIndex + 1;
// }

// int main() {
//     int arr[] = {1, 1, 1, 3, 2};
//     int target = 1;
//     int size = 5;
//     int left = 0;
//     int right = size - 1;
//     int a = alloccurence(arr, size, left, right, target);
//     cout << a;

//     return 0;
// }


// void printdigit(int num,vector<int>&ans){
//   if(num==0) return ;
//   int digit=num%10;
//   num=num/10;
//   printdigit(num,ans);
//   ans.push_back(num);
// }






