#include<iostream>
using namespace std;

// int getquotient(int divisor,int dividend){
//   int left=0;
//   int right=dividend;
// int answer=-1;
//   while(left<=right){
//     int mid=left+(right-left)/2;
//     if(mid*divisor==dividend) return mid;
//     else if(mid*divisor<dividend){
//       answer=mid;
//       left=mid+1;
//     } 
//     else{
//       right=mid-1;
//     }
//   }return answer;
// }


// int main(){
//   int divisor=7;
//   int dividend=-28;
//   int ans=getquotient(abs(divisor),abs(dividend));
//   if(dividend>0&&divisor<0|| dividend<0&&divisor>0){
//     ans=0-ans;
//   }
//   cout<<ans;
// }

// int searchNearlySorted(int arr[],int n,int target){
//   int s=0;
//   int e=n-1;
//   int mid=s+(e-s)/2;
//   while(s<=e){

//     if(mid-1 >=0 && arr[mid-1] == target) {
//       return mid-1;
//     }
//      if(arr[mid] == target)
//        return mid;
//      if(mid+1 < n && arr[mid+1]==target) 
//        return mid+1;
//      else if(target>arr[mid]){ 
//        s=mid+2;
//      }// because vhi mid-1 vala no check hoga agar 1 likhenege to
//     else{
//       e=mid-2;
//     } mid=s+(e-s)/2;
//   }return -1;
  
// }

// int main(){
//   int arr[7]={20,10,30,50,40,70,60};
//   int n=7;
//   int target=60;
//   int a=searchNearlySorted(arr,n,target);

//   if(a==-1) cout<<"eleent is not prsent";
//   else cout<<"no is present"<<a;
// }
// sare  elemment even time occur kar rahe hai bs ek ko chod ke
// hmara ans even index p hi exist krega
int oddoccurence(int arr[],int n){
  int s=0;
  int e=n-1;
  int mid=(s+e)/2;
  while(s<=e){
    if(s==e) return s;
    if(mid&1){// odd vala case
      if(arr[mid-1]>=0 && arr[mid-1]==arr[mid]){
        s=mid+1;
      }
      else{
        e=mid-1;
      }
    }// even wala case 
    else{
      if(arr[mid+1]<n && arr[mid+1]==arr[mid]){
        s=mid+2;
      }
      else{
        e=mid;
      }
    }mid=(s+e)/2;
  }return -1;
}
int main(){
  int arr[]={10,10,2,2,3,3,2,5,5,6,6,7,7};
  int n=13;
  int ans=oddoccurence(arr,n);
  cout<<"final ans at index"<<arr[ans]<<endl;
}
// done by this method
// int main(){
//         vector<int> arr = {10,10,2,2,3,3,2,5,5,6,6,7,7};
//     int n=arr.size();
//     int flag=0;
//    for(int i=0;i<n;i++){
//        flag=flag^arr[i];
//    }
//    cout<<flag;

// }

