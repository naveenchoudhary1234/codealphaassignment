#include <iostream>
#include<vector>
using namespace std;

// // int search(int arr[],int n,int target){
// //   int left=0;
// //   int right=n-1;
// //   int mid=(left+right)/2;
// //   while(left<=right){
// //     if(arr[mid]==target) return mid;
// //     else if(target>arr[mid]){
// //       left=mid+1;
// //     }
// //     else if(target<arr[mid]){
// //       right=mid-1;
// //     }
// //     mid=(left+right)/2;
// //   }
// //   return -1;
// // } 
// int firstoccurence(int arr[],int n,int target){
//   int left=0;
//   int right=n-1;
//   int ans=-1;
//   int mid=(left+right)/2;
//   while(left<=right){
//     if(arr[mid]==target){
//       ans=mid;
//       right=mid-1;
//     }
//     else if(target>arr[mid]){
//       left=mid+1;
//     }
//     else if(target<arr[mid]){
//       right=mid-1;
//     }
//     mid=(left+right)/2;
//   }
//   return ans;
// } 
// int lastoccurence(int arr[],int n,int target){
//   int left=0;
//   int right=n-1;
//   int ans=-1;
//   int mid=(left+right)/2;
//   while(left<=right){
//     if(arr[mid]==target){
//       ans=mid;
//       left=mid+1;
//     }
//     else if(target>arr[mid]){
//       left=mid+1;
//     }
//     else if(target<arr[mid]){
//       right=mid-1;
//     }
//     mid=(left+right)/2;
//   }
//   return ans;
// } 
// int totaloccurence(int arr[],int n,int target){
//   int firstocc=firstoccurence(arr,n,target);
//    int lastocc=lastoccurence(arr,n,target);
//   int totalocc=lastocc-firstocc+1;
//   return totalocc;
  
// }

// int main() {
//   int arr[]={1,2,3,3,3,6,7,8};
//   int n=8;
//   int target=3;
//   // int a=search(arr,n,target);
// //   // if(a==-1) cout<<"no is not present";
// //   // else cout<<"no is present at"<<a<<endl;
//   int b=lastoccurence(arr,n,target);
//  if(b==-1) cout<<"no nhi mila";
//   else cout<<"no mil gyaa at"<<b;
// // // int ans=totaloccurence(arr,n,target);
// // //   cout<<ans;
  
  
//  }



// int findmissing(int arr[],int n){
//   int s=0;
//   int e=n-1;
//   int ans=-1;
  
//   while(s<=e){
//     int m=(s+e)/2;
//     int diff=arr[m]-m;
//     if(diff==1) {
//       s=m+1;}
//     else{
//       ans=m;
//       e=m-1;
//     }if(ans+1==0) return n+1;
   
//   }
//   return ans+1;
// }

// int main(){
//   int arr[]={1,2,3,4,5,6,7,8};
//   int n=8;
//   int a=findmissing(arr,n);
//   cout<<a;
// }  


int peakmountain(vector<int>&arr){
  int n=arr.size();
  int l=0;
  int r=n-1;
  while(l<r){
     int m=(l+r)/2;
    if(arr[m]<arr[m+1]){// condition of a
      l=m+1;
  }
    else{
      // ya to hm b p h or ya phir peak p h
      r=m;  // in condition m infinite loop p chla jata hai
    }
  
}  return l;
}
int main(){
vector<int>arr={1,2,3,5,6,7};
  int a=peakmountain(arr);
  cout<<a;
  
  
}

















