#include <iostream>
using namespace std;
//// reverse Linked List
// isme ham ek nya pointer bnake taki uska track khtm na hojae aur hmara jo prev pointer h vo abbi head p h aur curr null p chla gyaa hai isie prev return kraya hai


// class Solution {
// public:
//     ListNode* reverseList(ListNode* head) {
//         ListNode*prev=NULL;
//         ListNode*curr=head;
//         while(curr!=NULL){
//             ListNode*nextnode=curr->next;
//             curr->next=prev;
//             prev=curr;
//             curr=nextnode;

//         }
//         return prev;
//     }
// };



////MIDDLE OF LINKED LIST
// odd // even odd m to n/2+1 hojayega sidha sidha
//e evn n/2+1 

// class Solution {
// public:
// int length(ListNode*head){
//     ListNode*temp=head;
//     int count=0;
//     while(temp!=NULL){
//      count++;
//      temp=temp->next;

//     }
//     return count;
// }
//     ListNode* middleNode(ListNode* head) {
//     int len = length(head);
//     int pos = len/2+1;
//     ListNode*temp=head;
//    while(pos!=1){
//     pos--;
//     temp=temp->next;
//    }
//    return temp;
//     }
// };

// slow and fast algorithm  or // tortois algorithm
//slow vala 1 step aage bdta hai
// fast vala pointer 2 step aage bdta hai
// slow  vala pointer 1 step tbhi bd payega tb fast valka 2 chad skta hai

// ListNode* middleNode(ListNode* head) {
//   ListNode*slow=head;
//   ListNode*fast=head;

//   while(fast!=NULL){
//       fast=fast->next;
//       if(fast!=NULL){
//           fast=fast->next;
//           slow=slow->next;
//       }
//   }
//   return slow;

//   }


/// palindrome
/// break into two halves
// second list reverse krdo
// compare both linked list

Node*reverse(Node*curr,Node*prev){
  while(curr!=NULL){
      Node*newnode=curr->next;
      curr->next=prev;
      prev=curr;
      curr=newnode;
  }
  return prev;

}

Node*middle(Node*head){
  Node*slow=head;
  Node*fast=head;
  while(fast->next!=NULL){
      fast=fast->next;
      if(fast->next!=NULL){
          fast=fast->next;
          slow=slow->next;
      }
  }return slow;

}

bool iscompare(Node*head1,Node*head2){
  while(head1!=NULL && head2!=NULL){
      if(head1->data!=head2->data){
          return false;
      }
      head1=head1->next;
      head2=head2->next;
  }
  return true;
}






// bool isPalindrome(Node *head)
// {  
//   Node*mid=middle(head);
//   mid=reverse(mid,NULL);

//   Node*firsthalf=head;
//   Node*secondhalf=mid;
//   bool check=iscompare(firsthalf,secondhalf);
//   return check;
// }


// check cycle in a linked list

// ham sbhi ka address nikalnege aur agr address repeat kr jaye to loop present haii
// class Solution {
// public:
//     bool hasCycle(ListNode *head) {
//         map<ListNode*,bool>table;
//     ListNode*temp=head;
//    while(temp!=NULL){
//     if(table[temp]==false){
//         table[temp]=true;
//     }
//     else{
//         return true;
//         // cycle present;
//     }
//     temp=temp->next;
//    }    
//    return false;

//     }
// };





