#include <iostream>
using namespace std;


// delete n mode after m mode
// isme n node ko delete krna h m node ko chod kar
// void linkdelete(struct Node **head, int n, int m) {
//   if (head == NULL || *head == NULL) return;

//   Node* temp = *head;  // iterator
//   while (temp != NULL) {
//       for (int i = 1; i < m && temp != NULL; i++) {
//           temp = temp->next;
//       }

//       if (temp == NULL) return;

//       Node* mthnode = temp;
//       temp = mthnode->next;
//       for (int i = 0; i < n && temp != NULL; i++) {
//           Node* next = temp->next;
//           delete temp;
//           temp = next;
//       }

//       mthnode->next = temp;
//   }
// }


// merge two sorted list
// ListNode* mergeTwoLists(ListNode* left, ListNode* right) {
//     if (left == NULL) return right;
//     if (right == NULL) return left;

//     ListNode* ans = new ListNode(-1); // Initialize with dummy node
//     ListNode* nptr = ans; // Iterator for merged list

//     while (left != NULL && right != NULL) {
//         if (left->val <= right->val) {
//             nptr->next = left;
//             left = left->next;
//         } else {
//             nptr->next = right;
//             right = right->next;
//         }
//         nptr = nptr->next; // Move the iterator forward
//     }

//     // Append any remaining nodes
//     while (left != NULL) {
//         nptr->next = left;
//         left = left->next;
//         nptr = nptr->next; // Move the iterator forward
//     }

//     while (right != NULL) {
//         nptr->next = right;
//         right = right->next;
//         nptr = nptr->next; // Move the iterator forward
//     }

//     return ans->next; // Return the merged list, skip the dummy node
// }


// find the kth node from end
// int getKthFromLast(Node *head, int k) {
//      Node*prev=NULL;
//   Node*curr=head;
//   while(curr!=NULL){
//       Node*newnode=curr->next;
//       curr->next=prev;
//       prev=curr;
//       curr=newnode;
//   }
//   Node*temp=prev;
//  for(int i=1;i<k && temp!=NULL;i++){
//      temp=temp->next;
//  }
//  if(temp!=NULL){
//      return temp->data;
//  }
//  else{
//      return -1;
//  }
// }



/// Intersection of two list node
// ListNode *getIntersectionNode(ListNode *headA, ListNode *headB) {
//     ListNode*a=headA;
//     ListNode*b=headB;

//     // yha agar hmari length equal hai to ye uske liye loop hai
//     while(a->next!=NULL && b->next!=NULL){
//         if(a==b) return a;
//         a=a->next;
//         b=b->next;
//     }
//    if(a->next==0 && b->next==0 &&a!=b) return NULL;
//     // ab hmari length equal nhii hai to 
//     if(a->next==NULL){
//         // mtlb hmari b vali bchi hui hai abhii
//         // ab hme b vali kitni bdii hai nikalnege
//         int blen=0;
//         while(b->next!=NULL){
//             blen++;
//             b=b->next;
//         }

//         while(blen--){
//             headB=headB->next;
//         }
//     }
//      else{
//         // mtlb hmari a vali bchi hui hai abhii
//         // ab hme a vali kitni bdii hai nikalnege
//         int alen=0;
//         while(a->next!=NULL){
//             alen++;
//             a=a->next;
//         }

//         while(alen--){
//             headA=headA->next;
//         }
//     }

//     while(headA!=headB){
//         headA=headA->next;
//         headB=headB->next;
//     }
//     return headA;
// }



// sort using merge sort

// ListNode*findmid(ListNode*head){
//   ListNode*slow=head;
//   ListNode*fast=head;
//   while(fast->next!=NULL){
//       fast=fast->next;
//       if(fast->next!=NULL){
//           fast=fast->next;
//           slow=slow->next;
//       }
//   }
//   return slow;
// }

// ListNode* merge(ListNode*left,ListNode*right){
//       if (left == NULL) return right;
//   if (right == NULL) return left;

//   ListNode* ans = new ListNode(-1); // Initialize with dummy node
//   ListNode* nptr = ans; // Iterator for merged list

//   while (left != NULL && right != NULL) {
//       if (left->val <= right->val) {
//           nptr->next = left;
//           left = left->next;
//       } else {
//           nptr->next = right;
//           right = right->next;
//       }
//       nptr = nptr->next; // Move the iterator forward
//   }

//   // Append any remaining nodes
//   while (left != NULL) {
//       nptr->next = left;
//       left = left->next;
//       nptr = nptr->next; // Move the iterator forward
//   }

//   while (right != NULL) {
//       nptr->next = right;
//       right = right->next;
//       nptr = nptr->next; // Move the iterator forward
//   }

//   return ans->next; 
// }



// ListNode*sortList(ListNode*head){
//   if(head==NULL ||head->next==NULL) return head;

//   ListNode*mid=findmid(head);
//   ListNode*left=head;
//   ListNode*right=mid->next;
//   mid->next=0; // alg alg krdia
// left=sortList(left);
// right=sortList(right); 
// ListNode*mergelist=merge(left,right);
// return mergelist;
// }


/// Flatten linked list
//isme hmari jo main linked list hai vo apne next ko point kr rhi hai par jo mian list k bottom pointer h to vo sare head hai
// 1 2 3 4 5
// 3 6  6 8 9
// 6    5    4
//  9

// convert to sigle linked list in sorted manner
// sabse pehle ham apni 2 linked list choose krenge phir un dono ko merge krdenge


// Node*merge(Node*a,Node*b){

//     if(!a) return b;
//     if(!b) return a;
//     Node*ans=0;
//     if(a->data<b->data){
//         ans=a;
//         a->bottom=merge(a->bottom,b);
//     }
//     else{
//         ans=b;
//         b->bottom=merge(a,b->bottom);
//     }
//     return ans;
// }


// Node *flatten(Node *root) {
//     // reversely merge krenge
//     if(!root) return 0;
//     Node*merged=merge(root,flatten(root->next));
//     return merged;

// }


// colone list with random number
 // Node*helper(Node*head,unordered_map<Node*,Node*>&mp){
 //  if(head==NULL) return NULL;
 //  Node*newhead=new Node(head->val);
 //  mp[head]=newhead;
 //  newhead->next=helper(head->next,mp);  // copy krli sari value head vali
 //  if(head->random){
 //      newhead->random=mp[head->random];  // ab random point kradia 
 //  }
 //  return newhead;
 // }



 //  Node* copyRandomList(Node* head) {
 //     unordered_map<Node*,Node*>mp;  // store old node to new node mapping
 //    return  helper(head,mp);

 //  }




// Rotate list
// 1 2 3 4 5
// hme 5 k head bna dena hai aur 4 ko null kra denge when k=1;
 // int length(ListNode*&head){
 //  int count=0;
 //  ListNode*temp=head;
 //  while(temp!=NULL){
 //      count++;
 //      temp=temp->next;
 //  }
 //  return count;
 // }

 //  ListNode* rotateRight(ListNode* head, int k) {
 //      if(head==0) return 0;
 //      int len=length(head);
 //      // jab ham len-k-1 krte  hai to hme new last node miltihai
 //      k=k%len;
 //      int actualrotate=k;
 //      if(actualrotate==0) return head;
 //      int newlastnodepos=len-actualrotate-1;
 //      ListNode*newlastnode=head;
 //      for(int i=0;i<newlastnodepos;i++){
 //          newlastnode=newlastnode->next;
 //      }
 //      ListNode*newhead=newlastnode->next;
 //      newlastnode->next=NULL;

 //      ListNode*it=newhead;
 //      while(it->next!=NULL){
 //          it=it->next;
 //      }
 //      it->next=head;
 //      return newhead;





 //  }



// find the minimum and max no of critical point between local minima and local maxima
// vector<int> nodesBetweenCriticalPoints(ListNode* head) {
//    // prev aur next dono pointer hoge tbhi vo local minima aur local maxima honge
//    // jha hm khde hai uske piche vali aur aage vali valye ya to choti hai ya bdii hai usse tbhi vo critical point hoga   
//    vector<int>ans={-1,-1};
//    ListNode*prev=head;
//    if(!prev) return ans;
//     ListNode*curr=head->next;
//     if(!curr) return ans;
//     ListNode*next=head->next->next;
//     if(!next) return ans;

//    int firstcp=-1;
//    int lastcp=-1;
//    int mindist=INT_MAX;  //minimum distance
//    int i=1;
//    while(next){
//     bool isCP=((curr->val>prev->val && curr->val>next->val)|| curr->val<prev->val && curr->val<next->val)
//    ?true:false;

//    if(isCP&& firstcp==-1){
//     firstcp=i;
//     lastcp=i;
//    }
//    // yhaa ab dusra critical point mil gyaa hai
//    else if(isCP){
//        mindist=min(mindist,i-lastcp);
//        lastcp=i;
//    }
//    ++i;
//    prev=prev->next;
//    curr=curr->next;
//    next=next->next;
//    }
//    if(lastcp==firstcp){
//     // ek hi critical point mila hai
//     return ans;
//    }
//    else{
//     ans[0]=mindist;
//     ans[1]=lastcp-firstcp;
//    }
//    return ans;


// }

