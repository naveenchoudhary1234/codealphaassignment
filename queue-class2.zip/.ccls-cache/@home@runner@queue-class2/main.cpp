#include <iostream>
#include<mqueue.h>
#include<queue>
#include<stack>
using namespace std;
/// reverse a queuue
// sabse pehle sare elemnt m stack m dalo
// phir sare element queue k andar dalo
queue<int> rev(queue<int> q)
  {
      stack<int>s;
      while(!q.empty()){
          int frontelement=q.front();
          q.pop();
          s.push(frontelement);
      }
      while(!s.empty()){
          int element=s.top();
          s.pop();
          q.push(element);
      }
      return q;
  }

// using recursion

void reverse(queue<int>&q){
  if(q.empty()){
    return;
  }
  int element=q.front();
  q.pop();
  reverse(q);
  q.push(element);
}

// int main(){
//   queue<int>q;
//   q.push(10);
//   q.push(20);
//   q.push(30);
//   reverse(q);
//   while(!q.empty()){
//     int elem=q.front();
//     q.pop();
//     cout<<elem<<endl;
//   }
  
// }


// Revrse k elemtn in queue
void reversea(queue<int>& q, int k) {
  if(q.empty()){
    return;
  }
   int n=q.size();
  if(k>n ||k==0){
    return;
  }
 
 stack<int>st;
  for(int i=0;i<k;i++){
    int temp=q.front();
    q.pop();
    st.push(temp);
  }
  while(!st.empty()){
    int temp=st.top();
    st.pop();
    q.push(temp);
  }
// baki bche hue element daldoo
  for(int i=0;i<n-k;i++){
    int temp=q.front();
    q.pop();
    q.push(temp);
  }
  
 
}
// int main(){
//   queue<int>q;
//   q.push(10);
//   q.push(20);
//   q.push(30);
//   q.push(40);
//   q.push(50);
//   q.push(60);
//   reversea(q,4);
//   while(!q.empty()){
//     int elem=q.front();
//     q.pop();
//     cout<<elem<<endl;
//   }
// }


  //// *Interleave first and second half
  // 10 20 30 40 50 60 70 80
  // output 10 50 20 60 30 70 40 80
vector<int> rearrangeQueue(queue<int> &first){
  vector<int>ans;
  queue<int>second;
  // push first half in second
  int size=first.size();
  for(int i=0;i<size/2;i++){
      int temp=first.front();
      first.pop();
      second.push(temp);
  }
  while (!second.empty()) {
  int temp1 = second.front();
  second.pop();
  ans.push_back(temp1);

  int temp2 = first.front();
  first.pop();
  ans.push_back(temp2);
}

return ans;
  }


//// ****  first negative intger in every window of k
// 2 -5 4 -1 -2 0 5
// window are 2 5 4 , -5 4 -1,4 -1 -2,-1,-2,0,-2,0,5
// queue s solve krte hai aise question
// sabse pehle double ended queue m first window ko intitlaise krloo
// double ended queue store index of -ve element
// when we move from new window reduce of old element and addition of new wlwmnt

void printfirstnegative(int *arr,int n,int k){
  deque<int>dq;
// process first k element
  for(int i=0;i<k;i++){
    int element=arr[i];
    if(element<0){
      dq.push_back(i);
    }
  }

  // prpcess remaning other window;
  for(int i=k;i<n;i++){
    // aage bade spehlepurani winfow ka ans nikalo
    if(dq.empty()){
      cout<<0;
    }
    else{
      cout<<arr[dq.front()];
    }
    

    // removal-jo bhi index out of range h use remove kardo
    if(!dq.empty() && i-dq.front()>=k){
      dq.pop_front();
    }
  

    // addition
    if(arr[i]<0){
      dq.push_back(i);
    }
  }
    if(dq.empty()){
      cout<<0;
    }
    else{
      cout<<arr[dq.front()]<<" ";
    }
  }




int main(){
// queue<int>q;
//   q.push(2);
//   q.push(-5);
//   q.push(4);
//   q.push(-1);
//   q.push(-2);
//   q.push(0);
//   q.push(5);
  int arr[]={2,-5,4,-1,-2,0,5};
  printfirstnegative(arr,7,3);
  
  
}