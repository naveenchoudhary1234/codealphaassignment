#include <iostream>
using namespace std;


////***** MERGE SORT
// 1 BREAK THE ARRAY
// 2 SORT THE LEFT PART BY RECURSION AND RIGHT PART
// 3 MERGE THE ARRAY

void merge(int arr[],int start,int end){

// length of left part mid-start+1;
  // length of right part end-mid;
  int mid=(start+end)/2;
  int leftlength=mid-start+1;
  int rightlength=end-mid;

  int *left=new int[leftlength];
  int *right=new int[rightlength];

  // copy values from original array
  int k=start;
  for(int i=0;i<leftlength;i++){
    left[i]=arr[k];
    k++;
  }
  // right vali array m copy krenge
  k=mid+1;
  for(int i=0;i<rightlength;i++){
    right[i]=arr[k];
    k++;
    
  }

  // actual merge logic
  int leftindex=0;;
  int rightindex=0;
  int mainarrayindex=start;
  while(leftindex<leftlength && rightindex<rightlength){
    if(left[leftindex]<right[rightindex]){
      arr[mainarrayindex]=left[leftindex];
      mainarrayindex++;
      leftindex++;
    }
    else{
      arr[mainarrayindex]=right[rightindex];
      mainarrayindex++;
      rightindex++;
      
    }
  }
  // 2 more cases
  // 1 agar hmare left array ka sare elemtn khtm ho gyee right m bche huee h 
  while(rightindex<rightlength){
    arr[mainarrayindex]=right[rightindex];
    mainarrayindex++;
    rightindex++;
  }
  
  
  
  //same for right k khtm ho gyee left m bche hue h
  while(leftindex<leftlength){
    arr[mainarrayindex]=left[leftindex];
    mainarrayindex++;
    leftindex++;
    
  
  }
    delete[] left;
    delete[] right; // deaAllocate the memory
  
  
  
  
  
}



void mergesort(int arr[],int start,int end){
  if(start>=end) {
    return;
  }
  if(start==end) return;
  // break
  int mid=(start+end)/2;
// start to mid- left part array
// mid+1 to end - right part array

  // recursion ko bhulao 
  mergesort(arr,start,mid); // call for left array

  mergesort(arr,mid+1,end); // call for right array

  // merege 2 sort
  merge(arr,start,end); // merge k liye ek fuction likhna pdegaa
  
  
  
}

int main() {
int arr[]={1,2,6,4,3,5};
  int size=6;
  int start=0;
  int end=size-1;
  mergesort(arr,start,end);
  cout<<"after merge sort"<<endl;
  for(int i=0;i<size;i++){
    cout<<arr[i]<<" ";
  }

  
}




/// quck sort
// to find pivot of the elment such that the right of th pivot >a[oivot]
// left vale pivot s chote hone chaiye
// 7 2 1 8 6 3 5 4 
// hmesa pivot ko end manege 7 index
// int i=start-1; int j=start;

void quicksort(int a[],int start,int end){

  if(start>end) return;
  int pivot=end;
  int i=start-1;
  int j=start;
  while(j<pivot){
    if(a[j]<a[pivot]){
      ++i;
      swap(a[i],a[j]);
    }
    ++j;
  }
  ++i; // last vale lement ko swap krne k liye
  swap(a[i],a[pivot]);
  quicksort(a,start,i-1); // i hme middle elemnt m mil gyaa hai
  quicksort(a,i+1,end);
  
  
}


