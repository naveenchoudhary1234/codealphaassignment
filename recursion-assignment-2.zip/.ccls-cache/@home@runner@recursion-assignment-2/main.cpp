#include <iostream>
#include<vector>
#include <climits> 
using namespace std;

// remove all occurenece in a string

int main() {
string str="naveen";
string part="een";
while(str.find(part)!=string::npos){
    str.erase(str.find(part),part.length());
}

cout<<str;
}



/// buy and sell stocks
int maxProfit(vector<int>& prices) {
    if (prices.empty()) return 0; 

    int min_price = prices[0];
    int max_profit = 0;

    for (int i = 1; i < prices.size(); i++) {

        min_price = min(min_price, prices[i]);

        max_profit = std::max(max_profit, prices[i] - min_price);
    }

    return max_profit;
}




// House Robber Problem
int robhelper(vector<int>&nums,int i){
  if(i>=nums.size()) return 0;
  int robamt1=nums[i]+robhelper(nums,i+2);
  int robamt2=0+robhelper(nums,i+1);
  return max(robamt1,robamt2);
  
}

int rob(vector<int>&nums){
 
  return robhelper(nums,0);
}


// convert integer to english words

class Solution {
public:

vector<pair<int,string>>mp={
{1000000000,"Billion"},
{1000000,"Million"},
{1000,"Thousand"},
{100,"Hundred"},
{90,"Ninety"},
{80,"Eighty"},
{70,"Seventy"},
{60,"Sixty"},
{50,"Fifty"},
{40,"Forty"},
{30,"Thirty"},
{20,"Twenty"},
{19,"Nineteen"},
{18,"Eighteen"},{17,"Seventeen"},{16,"Sixteen"},{15,"Fifteen"},{14,"Fourteen"},{13,"Thirteen"},
{12,"Twelve"},{11,"Eleven"},{10,"Ten"},{9,"Nine"},{8,"Eight"},{7,"Seven"},{6,"Six"},{5,"Five"},
{4,"Four"},{3,"Three"},{2,"Two"},{1,"One"}

};


    string numberToWords(int num) {
        if(num==0) return "Zero";
       for(auto it:mp){
         if(num>=it.first){
            string a=""; // starting vale k liy eg 12 kuch
            if(num>=100){
                a=numberToWords(num/it.first)+" ";
            }
            string b=it.second; // ans 
            string c=""; // last vali digit k liye bnayii hai
            if(num%it.first!=0){
                c=" "+numberToWords(num%it.first);
            }
            return a+b+c;


         }
       } return " ";

    }
};