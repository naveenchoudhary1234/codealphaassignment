#include <iostream>
#include<queue>
using namespace std;

// tree is non linerar data structure which is basically a combination of node in heriracheily form
// binary tree k case m atmost 2 child node ho skti hain
// top node-root node
// last node-leaf node -0 child hote hain
// ancestor- upr jate jao eg child k papa 1 ancestor 2 dada 3 dada k papa
// decendent -ancestor ka ulta vo ups s aata hain
// iske 2 pointer hote hain right aur left
// sibbling- ek parent k 2 child hain to vo dono child sibling hote hain



///*** sabse pehle left subtree bnta hai pir right ki bari aati hain

class Node{
public:
int data;
Node*left;
Node*right;


Node(int val){
  this->data=val;
  this->left=NULL;
  this->right=NULL;
}


};
// it returns root node of created tree
Node*createTree(){
cout<<"enter the value for node";
  int data;
  cin>>data;
  // question m bola ki node k left m 10 lgado to hm lgadenge but agr ques m bol ki -1 lgana hai to hm  null ko point kra denge
  if(data==-1){
    return NULL;
  }
  // create Node
  Node*root=new Node(data);

  cout<<"left node"<<root->data<<endl;
  // create left subtree
 root->left=createTree();

  // create right subtree

  cout<<"right node"<<root->data<<endl;;
   root->right=createTree();

  return root;


}

// * preorder
void preOrder(Node*root){
  if(root==NULL){
    return;
  }
  // NLR
  //N
  cout<<root->data<<" ";

  // L
  preOrder(root->left);

  // R
  preOrder(root->right);


}

//* inorder
void inOrder(Node*root){
  // LNR
  if(root==NULL){
    return;
  }
  // L
  inOrder(root->left);

  // N
  cout<<root->data<<" ";
  // R
  inOrder(root->right);
}

//*post order

void postOrder(Node*root){
  // LRN
  if(root==NULL){
    return;
  }

  // L
  postOrder(root->left);

  // R
  postOrder(root->right);

  // N
  cout<<root->data<<" ";


}

void levelOrder(Node*root){
  queue<Node*>q;
  q.push(root);
  q.push(NULL); // it act as a marker mtlb ye hme bta dega ki ye level ab khtm ho chuki hain

  while(!q.empty()){
    Node*front=q.front();
    q.pop();

    if(front==NULL){
      cout<<endl;
      if(!q.empty()) q.push(NULL); // Print newline here
    }
    else{

    cout<<front->data<<" ";

    if(front->left!=NULL){
      q.push(front->left);
    }
    if(front->right!=NULL){
      q.push(front->right);
    }
  }
  }

}


int main(){
  Node*root=createTree();
  cout<<root->data<<endl;
  cout<<"preorder";
  preOrder(root);
  cout<<endl;

  cout<<"postorder";
  postOrder(root);
  cout<<endl;

  cout<<"inorder";
  inOrder(root);
  cout<<endl;


  cout<<"level order";
  levelOrder(root);
  cout<<endl;
}


/// generic child -n no of child
// class k andar hme arr bnani pdegii vector<Node*>child;
//// Traversal of tree-3
// 1 preorder- NLR -current node left part right part
// 2 INORDER-LNR 
// 3 POST ORDER-LRN


// skew tree- n in left and n in right
// timr nd space complexity -o(n)

// level order traversal- vo same line p h unko 1 level m count krnge
// fetch front eleme using queue
// push left element
// push right element

/// Height of a tree
// maximum node farthest node k bich m kitni hai
int maxDepth(TreeNode* root) {
  if(root==NULL){
    return 0;
  }  
  int leftheight=maxDepth(root->left);
  int rightheight=maxDepth(root->right);
  int height=max(leftheight,rightheight)+1;// 1 root node k liyee
  return height;
}

// diameter of treee
int height(TreeNode* root) {
  if(root==NULL){
    return 0;
  }  
  int leftheight=height(root->left);
  int rightheight=height(root->right);
  int height=max(leftheight,rightheight)+1;// 1 root node k liyee
  return height;
}

int diameterOfBinaryTree(TreeNode* root) {
    if(root==NULL) return 0;
    int option1=diameterOfBinaryTree(root->left);
    int option2=diameterOfBinaryTree(root->right);
    // combination of left and right
    int option3=height(root->left)+height(root->right);
    return max(option1,max(option2,option3));


}

// second method to find diamter of binary tree
int diameter=0;
int height(TreeNode* root) {

  if(root==NULL){
    return 0;
  }  
  int leftheight=height(root->left);
  int rightheight=height(root->right);
 int currdiameter=leftheight+rightheight;
 diameter=max(diameter,currdiameter);
  return max(leftheight,rightheight)+1;
}

int diameterOfBinaryTree(TreeNode* root) {
  height(root);
  return diameter;


}

// is tree is balanced or not
bool isbalanced=true;
int height(TreeNode*root){
    if(root==NULL){
        return 0;
    }
    int a=height(root->left);
    int b=height(root->right);
    if(isbalanced && abs(a-b)>1){
        isbalanced=false;
    }
    return max(a,b)+1;
}
bool isBalanced(TreeNode* root) {
    height(root);
    return isbalanced;
}